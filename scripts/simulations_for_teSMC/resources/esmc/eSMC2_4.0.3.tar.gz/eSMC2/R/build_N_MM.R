#' Build the exact transition matrix from sequence of genealogy
#'
#' @param genealogy : Matrix of sequence of genealogy (output of get_first_coal_time)
#' @param Tc : numerical vector containing the discretization of time
#' @param M_a : number of haplotype used for model
#' @export
#' @return a square matrix of size Tc x M_a x (M_a-1) x 0.5 counting the transition events
build_N_MM<-function(genealogy,Tc,M_a=3){
  Output=matrix(0,ncol=(length(Tc)*M_a*(M_a-1)*0.5),nrow=(length(Tc)*M_a*(M_a-1)*0.5))

  count_L=0
  for(i in 1:dim(genealogy$Coal_time)[2]){
    id=c(genealogy$id_split[(M_a-1),i],genealogy$id_create[(M_a-1),i])
    index=find_index(id,M=M_a)
    state=max(which(Tc<genealogy$Coal_time[(M_a-1),i]))+((length(Tc)*(index-1)))
    if(i==1){
      former_state=state
      length_seq=genealogy$Coal_time[M_a,i]
      if(length_seq>1){
       # Output[former_state,state]=Output[former_state,state]+1
        #count_L=count_L+1
        former_state=state
        Output[former_state,state]=Output[former_state,state]+(length_seq-1)
        count_L=count_L+(length_seq-1)
      }
    }else{
      length_seq=genealogy$Coal_time[M_a,i]
      if(length_seq>1){
        Output[former_state,state]=Output[former_state,state]+1
        count_L=count_L+1
        former_state=state
        Output[former_state,state]=Output[former_state,state]+(length_seq-1)
        count_L=count_L+(length_seq-1)
      }else{
        Output[former_state,state]=Output[former_state,state]+1
        former_state=state
        count_L=count_L+1
      }
    }
  }
  return(Output)
}
