#' Reads a reference genome file
#'
#' @param path : location of the reference genome file
#' @return Get nucleotide references
Get_vcf_ref<-function(path){
  data=Get_vcf_data(path)
  for(search_id in 1:length(data)){
    if(data[[search_id]][1]=="#CHROM"){
      start_position=search_id+1
      break()
    }
  }
  output=matrix(as.vector(unlist(data[start_position:length(data)])),nrow=(length(data)-(start_position-1)),ncol=length(data[[start_position]]),byrow = T)[,c(1,2,4)]
  return(output)
}
