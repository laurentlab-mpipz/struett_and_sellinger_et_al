#' Builds a sequence of number corresponding to the number of segregating sites per window in the sequence.
#'
#' @param DNA : Sequence of 0 and 1 (0 absence of mutations and  1 are segregating sites)
#' @param w : window length in bp
#' @return A numeric vector of number of segregating sites per window.
build_X_star_seq<-function(DNA,w){

  DNA_sum<-sapply(c(1:(floor(length(DNA)/w)-1)), function(x){ if(all(as.numeric(DNA[1+((x-1)*w):(x*w)])==2)){return(NA)}else{return(length(which(as.numeric(DNA[1+((x-1)*w):(x*w)])==1))/((w-length(which(as.numeric(DNA[1+((x-1)*w):(x*w)])==2)))/w) )}})

  return(DNA_sum)
}
