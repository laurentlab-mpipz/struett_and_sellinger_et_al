#'  Changes character symbol to numeric ones
#'
#' @param Os : original signal (sequence of 0 and 1)
#' @param Mat_symbol : matrix containing all the zipping symbol
#' @param start_symbol : numerical value to start the numerical transformation (avoiding using twice the same value)
#' @return A list with first object the ziped sequence and as second the symbol matrix#
symbol2NumMM<-function(Os,Mat_symbol,start_symbol){
  if(length(Mat_symbol)>0){
    for( i in letters){
      if(any(Mat_symbol[,1]%in%i)){
        pos=which(Os%in%i)
        x=as.numeric(which(letters%in%i))
        if(length(pos)>0){
          Os[pos]=(start_symbol+x)
        }
        Mat_symbol[x,1]=(start_symbol+x)
        sym=strsplit(Mat_symbol[x,2],"")
        sym=sym[[1]]
        if(sym[1]%in%letters){
          sym[1]=start_symbol+as.numeric(which(letters%in%sym[1]))
        }
        if(sym[2]%in%letters){
          sym[2]=start_symbol+as.numeric(which(letters%in%sym[2]))
        }
        sym=paste(sym,collapse=" ")
        Mat_symbol[x,2]=sym
      }
    }
  }
  # print(Mat_symbol)
  output=list()
  output[[1]]=Os
  output[[2]]=Mat_symbol
  return(output)
}
