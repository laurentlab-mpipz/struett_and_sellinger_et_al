#' Creates a multihetsep file from a Segregating matrix with epimutations
#'
#' @param O : Segregating matrix
#' @param name : location  and name of the file
#' @export
#' @return A multihetsep file where methylated C are annotated M and unmethylated C as D
create_realinput_meth_msmc2<-function(O,name){
  nb_meth=1
  if(nb_meth>7){
    stop("Only 7 type of methylations are currently allowed.  Sorry :/ ")

  }
  options(scipen=999)
  O=as.matrix(O)
  output=matrix(NA,nrow=dim(O)[2],ncol = 4)
  count=0
  M=dim(O)[1]-2
  vect_opti=as.numeric(O[M+2,])
  O=O[-(M+2),]
  if(nb_meth==1){
    nucleotide=c("A","T","G","C","M","D")
    for(nu in c(1,2,3,4,5,6)){
      for(m in 1:M){
        pos_nu=which(as.character(O[m,])==as.character(nu))
        if(length(pos_nu)>0){
          O[m,pos_nu]<-nucleotide[nu]
        }

      }
    }
    for(p in 1:dim(O)[2]){
      count=count+1
      output[count,1]=1
      output[count,2]=as.numeric(format(as.numeric(vect_opti[p]),scientific = F))
      output[count,3]=as.integer(O[(M+1),p])
      output[count,4]=paste(O[1:M,p],collapse="")

    }
    output=output[1:count,]
    utils::write.table(output, file=paste(name,".txt",sep=""), quote = FALSE, row.names=FALSE, col.names=FALSE)
    options(scipen=0)
  }else{
    nucleotide=c("A","T","G","C","M","D",LETTERS[15:(15+((nb_meth-1)*2))])
    for(nu in c(1,2,3,4,c(5:(4+(nb_meth*2))))){
      for(m in 1:M){
        pos_mm=which(as.character(O[m,])==as.character(nu))
        if(length(pos_mm)>0){
          O[m,pos_mm]<-nucleotide[nu]
          rm(pos_mm)
        }

      }
    }
    for(p in 1:dim(O)[2]){
      count=count+1
      output[count,1]=1
      output[count,2]=as.numeric(format(as.numeric(vect_opti[p]),scientific = F))
      if(count==1){
        output[count,3]=as.numeric((as.numeric(format(as.numeric(vect_opti[p]),scientific = F))-1),scientific = F)
      }
      if(count>1){
        output[count,3]=as.numeric(format(as.numeric(vect_opti[p])-as.numeric(output[(count-1),2]),scientific = F))
      }
      output[count,4]=paste(O[1:M,p],collapse="")

    }
    output=output[1:count,]
    utils::write.table(output, file=paste(name,".txt",sep=""), quote = FALSE, row.names=FALSE, col.names=FALSE)
    options(scipen=0)
  }

}
