#' Build signal for SMCm
#'
#' @param DNA : matrix of segregating and "episegregating" sites of the sample
#' @param n : sequence length
#' @param position_removed : list containingvectors of size 2 indicating begining and end positions to remove from the sequence.
#' @param mask_island : number of masked position in a row, 1 will give best results but slow algorithm
#' @param nb_meth : number of methylation context
#' @param Free : TRUE to estimate methylation rates from the data (i.e. ignoring what has been inputed)
#' @return : sequence of 0 and 1 (1 mutation, 0 no mutation)
seqMeth<-function(DNA,n,position_removed=NA,mask_island=10000,nb_meth=1,Free=F){
  output=list()

  DNA=as.matrix(DNA)
  pos=which(DNA[1,]!=DNA[2,])
  seq=rep(0,n)
  seq[as.numeric(DNA[4,pos])]=1
  pos_1_M=which(DNA[1,]=="M")
  pos_1_D=which(DNA[1,]=="D")

  pos_2_M=which(DNA[2,]=="M")
  pos_2_D=which(DNA[2,]=="D")

  pos_1_C=which(DNA[1,]=="C")
  pos_2_C=which(DNA[2,]=="C")

  correct_pos=unique(c(pos_1_M[which(pos_1_M%in%pos_2_C)],pos_2_M[which(pos_2_M%in%pos_1_C)],pos_1_D[which(pos_1_D%in%pos_2_C)],pos_2_D[which(pos_2_D%in%pos_1_C)]))
  if(length(correct_pos)>0){
    seq[as.numeric(DNA[4,correct_pos])]=0
  }
  pos_M=which(pos_1_M%in%pos_2_M)
  seq[as.numeric(DNA[4,pos_1_M[pos_M]])]=4

  pos_D=which(pos_1_D%in%pos_2_D)
  seq[as.numeric(DNA[4,pos_1_D[pos_D]])]=3
  rm(pos_D)
  rm(pos_M)
  pos_MD=which(pos_1_D%in%pos_2_M)
  pos_DM=which(pos_1_M%in%pos_2_D)

  if(length(pos_MD)>0){
  seq[as.numeric(DNA[4,pos_1_D[pos_MD]])]=5
  }
  if(length(pos_DM)>0){
  seq[as.numeric(DNA[4,pos_1_M[pos_DM]])]=5
  }


  if(nb_meth==2){
    rm(pos_1_M)
    rm(pos_2_M)
    rm(pos_1_D)
    rm(pos_2_D)
    rm(pos_MD)
    rm(pos_DM)

    pos_1_M=which(DNA[1,]=="O")
    pos_1_D=which(DNA[1,]=="P")

    pos_2_M=which(DNA[2,]=="O")
    pos_2_D=which(DNA[2,]=="P")

    #pos_1_C=which(DNA[1,]=="C")
    #pos_2_C=which(DNA[2,]=="C")

    correct_pos=unique(c(pos_1_M[which(pos_1_M%in%pos_2_C)],pos_2_M[which(pos_2_M%in%pos_1_C)],pos_1_D[which(pos_1_D%in%pos_2_C)],pos_2_D[which(pos_2_D%in%pos_1_C)]))
    if(length(correct_pos)>0){
      seq[as.numeric(DNA[4,correct_pos])]=0
    }
    pos_M=which(pos_1_M%in%pos_2_M)
    seq[as.numeric(DNA[4,pos_1_M[pos_M]])]=7

    pos_D=which(pos_1_D%in%pos_2_D)
    seq[as.numeric(DNA[4,pos_1_D[pos_D]])]=6
    rm(pos_D)
    rm(pos_M)
    pos_MD=which(pos_1_D%in%pos_2_M)
    pos_DM=which(pos_1_M%in%pos_2_D)

    if(length(pos_MD)>0){
      seq[as.numeric(DNA[4,pos_1_D[pos_MD]])]=8
    }
    if(length(pos_DM)>0){
      seq[as.numeric(DNA[4,pos_1_M[pos_DM]])]=8
    }

  }


  rm(pos_1_M)
  rm(pos_2_M)
  rm(pos_1_D)
  rm(pos_2_D)
  rm(pos_MD)
  rm(pos_DM)
  rm(pos_1_C)
  rm(pos_2_C)


  if(!is.na(position_removed)){
    position_to_be_removed=numeric()
    for(ii in 1:length(position_removed)){
      position_to_be_removed=c( position_to_be_removed,c(position_removed[[ii]][1]:position_removed[[ii]][2]))
    }
    position_removed=position_to_be_removed
    rm(position_to_be_removed)
  }
  if(any(is.na(seq))){
    browser()
  }
  mask_vector=(as.numeric(DNA[4,-1])-as.numeric(DNA[4,-dim(DNA)[2]]))-as.numeric(DNA[3,-1])
  masked_pos=which(mask_vector>0)+1
  if(length(masked_pos)>0){
    print("Masking sequence")
  for(cc in c(1,masked_pos)){
    if(cc==1){
      if(as.numeric(DNA[3,cc])<(as.numeric(DNA[4,cc])-1)){
        masked_number=as.numeric(DNA[4,cc])-as.numeric(DNA[3,cc])
         if(mask_island==1){
           seq[sample(c(1:(as.numeric(DNA[4,1])-1)),masked_number)]=2
         }else{

         if(masked_number>mask_island){
           nb_island=floor(masked_number/mask_island)
           pos_island=sample(1:floor((as.numeric(DNA[4,1])-1)/mask_island),nb_island)
           for(ppp in pos_island){
             seq[(1+((ppp-1)*mask_island)):(ppp*mask_island)]=2
           }
         }else{
           seq[1:masked_number]=2
         }
         }
     }
      if(any(is.na(seq))){
        browser()
      }
    }else{
      masked_number=mask_vector[(cc-1)]
      if(mask_island==1){
        seq[sample(c((as.numeric(DNA[4,(cc-1)])+1):(as.numeric(DNA[4,(cc)])-1)),masked_number)]=2
      }else{
        if(masked_number>mask_island){
          nb_island=floor(masked_number/mask_island)
          pos_island=sample(1:floor(((as.numeric(DNA[4,cc])-1)-(as.numeric(DNA[4,(cc-1)])+1))/mask_island),nb_island)
          for(ppp in pos_island){
            seq[((as.numeric(DNA[4,(cc-1)])+1)+((ppp-1)*mask_island)):((as.numeric(DNA[4,(cc-1)]))+(ppp*mask_island))]=2
          }
        }else{
          seq[(as.numeric(DNA[4,(cc-1)])+1):(as.numeric(DNA[4,(cc-1)])+masked_number)]=2
        }

      }

      if(any(is.na(seq))){
        browser()
      }
    }

  }
  }

  if(!is.na(position_removed)){
    seq[c(position_removed)]=2
    #print('Length of removed sequence:')
    #print(length(position_removed))
    rm(position_removed)
  }
  if(any(is.na(seq))){
    browser()
  }
  n=length(which(as.numeric(seq)!=2))
  theta=length(which(seq==1))/(n/length(seq))

  print("signal build")
  output$seq=as.numeric(seq)
  output$theta=as.numeric(theta)

  if(Free){

    ratio_D_over_M=(length(which(seq==3))+(0.5*length(which(seq==5))))/length(which(seq%in%c(3,4,5)))
    theta_M=((length(which(seq==5))))/length(which(seq%in%c(3,4,5)))
    output$ratio_D_over_M=ratio_D_over_M
    output$theta_M=as.numeric(theta_M)

    if(nb_meth==2){
      ratio_O_over_P=(length(which(seq==6))+(0.5*length(which(seq==8))))/length(which(seq%in%c(6,7,8)))
      theta_O=((length(which(seq==8))))/length(which(seq%in%c(6,7,8)))
      output$ratio_O_over_P=as.numeric(ratio_O_over_P)
      output$theta_O=as.numeric(theta_O)
    }

  }

  return(output)
}

