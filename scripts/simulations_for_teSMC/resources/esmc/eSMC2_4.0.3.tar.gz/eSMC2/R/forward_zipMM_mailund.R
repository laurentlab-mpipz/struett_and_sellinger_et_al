#'  Forward alagorithm
#'
#'Runs the forward alagorithm on a zipped sequences
#' @param Os : zip signal
#' @param E : emission matrix
#' @param q : equilibrium probability
#' @param  C : matrix for the zip signal
#' @param  TS_SNP : Vector of SNPs
#' @param  max_count : max number of zipped symbol
#' @return A 3 object list. First object is the result from the forward algorithm. Second is the vector containing used values for the rescaling of the forward algorithm. Third is the sum this vector.
forward_zipMM_mailund <- function(Os,E,q,C,TS_SNP,max_count){
  Os=as.numeric(as.vector(Os))
  T_prime=length(Os)
  output=list()
  yy=dim(E[[1]])[2]
  count_SNP=0
  alpha=matrix(0,ncol=T_prime,nrow=length(q))
  d=numeric(length = T_prime)
  if(as.numeric(Os[1])>9){
    alpha[,1]= diag(x=E[[(ceiling((as.numeric(Os[1])-9)/max_count))]][,1])%*%q
  }
  if(as.numeric(Os[1])<0){
    alpha[,1]=diag(x=E[[abs(Os[1])]][,1])%*%q
  }
  if(as.numeric(Os[1])>=0&as.numeric(Os[1])<=9){
    count_SNP=count_SNP+1
    alpha[,1]=diag(x=E[[TS_SNP[count_SNP]]][,(Os[1]+1)])%*%q
  }
  d_n=sum(alpha[,1])
  alpha[,1]=alpha[,1]/sum(alpha[,1])
  d[1]=log(d_n)
  i=1
  while(i<T_prime){
    i=i+1
    if(as.numeric(Os[i])>9){
      truc=C[[(ceiling((as.numeric(Os[i])-9)/max_count))]][[(-9+yy+as.numeric(Os[i])-((ceiling(as.numeric(Os[i]-9)/max_count)-1)*max_count))]]%*%alpha[,(i-1)]
    }
    if(as.numeric(Os[i])<0){
      truc=C[[abs(as.numeric(Os[i]))]][[1]]%*%alpha[,(i-1)]
    }

    if(as.numeric(Os[i])>=0&as.numeric(Os[i])<=9){
      count_SNP=count_SNP+1
      truc=C[[TS_SNP[count_SNP]]][[(as.numeric(Os[i])+1)]]%*%alpha[,(i-1)]
    }


    dn=sum(truc)
    if(dn<=0){
      stop()
    }
    alpha[,i]=truc/dn
    d[i]=log(dn)
  }
  output[[1]]=alpha
  output[[2]]=d
  output[[3]]=(sum(d))

  return(output)
}
