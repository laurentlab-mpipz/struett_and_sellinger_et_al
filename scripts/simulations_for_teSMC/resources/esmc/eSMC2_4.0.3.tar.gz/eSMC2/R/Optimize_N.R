#' Runs the ecological Sequentially Markovian Coalescent 2 on sequence of genealogy
#'
#' @param file : path to the simulated data  ( .txt )
#' @param gamma : initial ration of recombination over mutation
#' @param theta : theta used for simulation (i.e theta=1000 if command line is scrm :  -t 1000 ) or theta waterson of the observed data (if analyzing real data) or mutation rate per generation per bp if simulator is msprime
#' @param L : length of simulated sequence
#' @param n : Number of hidden states
#' @param ER : True to estimate recombination rate
#' @param Pop : True  top estimate population size
#' @param SB : True to estimate germination rate
#' @param SF : True to estimate Self-fertilization rate
#' @param BoxB : boundaries of the germination rate ( first value must be  bigger than 0)
#' @param BoxP : logarithmic boundaries in base 10 for the  demography e.g. c(3,3) means the  population size can grow up to a thousand time  and decrease up to a thousand time
#' @param Boxr : logarithmic boundaries in base 10 for the  recombination rate e.g. c(1,1) means the recombination rate can be up to ten times smaller or bigger than the initial given value
#' @param Boxs : boundaries for the self-fertilization rate e.g. c(0.5,0.9) means the selfing rate is between 0.5 and 0.9.
#' @param pop_vect : vector of hidden state sharing their population size parameter. Sum must be equal to hidden state number
#' @param window_scaling : numerical vector of size 2. Time window is divided by first value, and second value is added to time window to shift it in past or present
#' @param sigma : initial value for self-fertilization rate
#' @param beta : initial value for germination rate
#' @param Big_Window : TRUE to use MSMC2 time window (bigger)
#' @param NC : Number of scaffold to be analyzed
#' @param BW : True to use the complete implementation of the Baum-Welch algorithm (FALSE if transition matrix is given)
#' @param mu_b : ratio of muration rate in the dormant stage and during reproductive event
#' @param N : estimated transition matrix
#' @param simulator : "msprime" or "scrm" or NA if N is given
#' @param M : sample size of data
#' @export
#' @return A list containing all estimations in same format as eSMC.
Optimize_N<-function(file=NA,gamma,theta=NA,L,n=40,ER=T,Pop=T,SB=FALSE,SF=FALSE,BoxB=c(0.1,1),BoxP=c(3,3),Boxr=c(1,1),Boxs=c(0,0.97),pop_vect=NA,window_scaling=c(1,0),sigma=0,beta=1,Big_Window=F,NC=1,BW=F,mu_b=1,N=NA,simulator,M){
  FS=F
  npair=2
  SCALED=F
  M_a=2
  scale_T=1
  Correct_window=T
  mut=T
  if(simulator=='msprime'){
    mu_real=theta
  }
  if(!is.na(file)){
    if(NC==1){

      if(simulator=="scrm"){
        mu=theta
        theta=get_theta(file)
        mu_=theta/((2*sum(1/(1:(M-1))))*L)
        scale_T=mu_/mu
        Ne=NA
      }else{
        theta=get_theta(file)
        mu_=theta/((2*sum(1/(1:(M-1))))*L)
        theta=mu_*((2*sum(1/(1:(M_a-1))))*L)
        Ne=mu_/(mu_real)
      }
      mu=mu_

      #b=get_first_coal_time(file,mut)
      Popfix=!Pop
      Vect=0:(n-1)
      extra_l=M_a*(M_a-1)*0.5
      if(simulator=="scrm"){
        b=get_genealogy(file,M,mut=mut,simulator,Ne=Ne)
      }
      if(simulator=="msprime"){
        b=get_genealogy(file,M,mut=mut,simulator,Ne=Ne)
      }

      Rho=gamma*2*L*mu
      Tc= build_Tc(n=n,Beta=beta,scale=window_scaling,Sigma=sigma,Big_Window=Big_Window,npair=npair)


      if(M_a<M){
        print("extracting sub genealogies then building N")
        if(M_a==2){
          count_ind=0
          for(i in 1:(M-1)){
            possible_ind=i:M
            if(i>1){
              if(i<(M-1)){
                b_a_temp1=get_sub_genealogy(b,ind=c(possible_ind),update_index=F)
              }else{
                b_a_temp1=get_sub_genealogy(b,ind=c(possible_ind),update_index=T)
              }
            }else{
              b_a_temp1=b#get_sub_genealogy(b,ind=c(possible_ind),update_index=F)
            }
            for(j in (i+1):(M-1)){
                count_ind=count_ind+1
                ind=c(i,j)
                if(length(ind)<length(possible_ind)){
                  b_a=get_sub_genealogy(b_a_temp1,ind,update_index=T)
                }else{
                  b_a=b_a_temp1
                }
                if(count_ind==1){
                  N=build_N(b_a,Tc)
                }else{
                  N=N+build_N(b_a,Tc)
                }
            }
          }
        }

      }else{
        print("building N")
        N=build_N(b,Tc)
      }


      if(BW){
        a=Get_sim_data(file,L,2,1)
        res=build_M(a[[1]],b,Tc)
        print("M is built")
        M=res$M
        print(sum(M))
        q_=res$q
      }
    }else{

      if(length(theta)==1){
        theta=rep(theta,NC)
      }
      if(length(L)==1){
        L=rep(L,NC)
      }


      if(simulator=="scrm"){
        mu=theta
        mu_=c()
        for(chr in 1:NC){
          theta=get_theta(file[chr])
          mu_=c(mu_,theta/((2*sum(1/(1:(M-1))))*L[chr]))
        }
        scale_T=mean(mu_/mu)
        Ne=NA
      }else{
        mu_=c()
        for(chr in 1:NC){
          theta=get_theta(file[chr])
          mu_=c(mu_,theta/((2*sum(1/(1:(M-1))))*L[chr]))
        }
        theta=mu_*((2*sum(1/(1:(M_a-1))))*L)
        Ne=mean(mu_/(mu_real))
      }
      mu=mu_

      #b=get_first_coal_time(file,mut)
      Popfix=!Pop
      Vect=0:(n-1)
      extra_l=M_a*(M_a-1)*0.5

      Rho=gamma*2*L*mu
      Tc= window_scaling[2] -(0.5*(2-sigma)*log(1-(Vect/n))/(extra_l*(beta^2)*window_scaling[1]))
      Tc=Tc*scale_T
      N_total=list()
      M_total=list()
      for(chr in 1:NC){

        b=get_genealogy(file[chr],M,mut=mut,simulator,Ne=Ne)

        if(M_a<M){
          print("extracting sub genealogies then building N")
          if(M_a==2){
            count_ind=0
            for(i in 1:(M-1)){
              possible_ind=i:M
              if(i>1){
                if(i<(M-1)){
                  b_a_temp1=get_sub_genealogy(b,ind=c(possible_ind),update_index=F)
                }else{
                  b_a_temp1=get_sub_genealogy(b,ind=c(possible_ind),update_index=T)
                }
              }else{
                b_a_temp1=b#get_sub_genealogy(b,ind=c(possible_ind),update_index=F)
              }
              for(j in (i+1):(M-1)){
                count_ind=count_ind+1
                ind=c(i,j)
                if(length(ind)<length(possible_ind)){
                  b_a=get_sub_genealogy(b_a_temp1,ind,update_index=T)
                }else{
                  b_a=b_a_temp1
                }
                if(count_ind==1){
                  N=build_N(b_a,Tc)
                }else{
                  N=N+build_N(b_a,Tc)
                }
              }
            }
          }

        }else{
          print("building N")
          N=build_N(b,Tc)
        }

        if(BW){
          a=Get_sim_data(file,L,2,1)
          res=build_M(a[[1]],b,Tc)
          print("M is built")
          M=res$M
          print(sum(M))
          q_=res$q
          M_total[[chr]]=M
        }

        N_total[[chr]]=N
      }
      N=N_total
      M=M_total
    }
    print("N is built")


  }else{
    if(!is.na(N)){
      Popfix=!Pop
      scale_T=1
      Tc= build_Tc(n=n,Beta=beta,scale=window_scaling,Sigma=sigma,Big_Window=Big_Window,npair=npair)

    }else{
      stop("Must give file to read or a transition matrix")
    }
  }

  if(SCALED){
    corrector_N=rowSums(N)
    N=diag(1/corrector_N)%*%N
    if(BW){
      corrector_M=rowSums(M)
      M=diag(1/corrector_M)%*%M
    }
  }
  Tc=Tc/scale_T
  scale_T=1
  test.env <- new.env()
  test.env$L <- L
  test.env$k <- n
  test.env$Rho <- Rho
  test.env$window_scaling <- window_scaling
  test.env$Pop<-!Pop
  test.env$NC<-NC
  test.env$FS<-FS
  test.env$Big_Window <- Big_Window
  test.env$npair <- npair
  test.env$Beta <- beta
  test.env$Self <- sigma
  test.env$BoxB <- BoxB
  test.env$Boxs <- Boxs
  test.env$Big_Xi <- N
  test.env$mu_b <- mu_b
  test.env$BW <- BW
  test.env$scale_T <- scale_T
  if(BW){
    test.env$Big_M <- M
    test.env$q_ <- q_
  }
  lr=length(Rho)
  test.env$lr<-lr
  if(any(!is.na(pop_vect))){
    Klink=length(pop_vect)
  }
  if((all(is.na(pop_vect))|sum(pop_vect)!=n)){
    Klink=0.5*n
    pop_vect=rep(2, Klink)
    print("Default pop vector")
  }
  test.env$pop_vect <- pop_vect
  if(SB){
    oldbeta=(sqrt(beta)-BoxB[1])/(BoxB[2]-BoxB[1])
  }
  if(SF){
    oldsigma=(sigma-Boxs[1])/(Boxs[2]-Boxs[1])
  }
  if(!SB){
    test.env$beta <- beta
  }
  if(!SF){
    test.env$sigma <- sigma
  }
  if(Pop){
    oldXi_=rep((BoxP[1]/sum(BoxP)),Klink)
    oldXi=vector()
    xx=0
    for(ix in 1:Klink){
      x=xx+1
      xx = xx + pop_vect[ix]
      oldXi[x:xx]=oldXi_[ix]
    }
    Xi_=oldXi*sum(BoxP)
    Xi_=Xi_-(BoxP[1])
    Xi_=10^Xi_
  }

  if(!ER){
    oldrho=0
    if(NC>1){
      oldrho=rep(0,NC)
    }

  }
  if(ER){
    oldrho=(Boxr[1]/sum(Boxr))
    if(NC>1){
      oldrho=rep((Boxr[1]/sum(Boxr)),NC)
    }

  }

  if(NC==1){
    if(ER){
      if(SB){
        if(SF){
          if(Popfix){
            function_to_minimize <-function(param){
              Boxr=get('Boxr', envir=test.env)
              mu_b=get('mu_b', envir=test.env)
              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)
              FS=get('FS', envir=test.env)
              rho_=param[1]
              rho_=rho_*sum(Boxr)
              rho_=rho_-(Boxr[1])
              rho_=10^(rho_)
              Rho=get('Rho', envir=test.env)
              rho_=rho_*Rho
              BoxB=get('BoxB', envir=test.env)
              beta=((param[2]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              BW=get('BW', envir=test.env)
              if(BW){
                Big_M=get('Big_M', envir=test.env)
                q_=get('q_', envir=test.env)
              }
              Beta=get('Beta', envir=test.env)
              Boxs=get('Boxs', envir=test.env)
              Self=get('Self', envir=test.env)
              sigma=param[3]
              sigma=sigma*(Boxs[2]-Boxs[1])
              sigma=sigma+Boxs[1]

              window_scaling=get('window_scaling', envir=test.env)

              Pop=get('Pop', envir=test.env)
              builder=build_HMM_matrix(n,rho_,beta,Pop = Pop,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,Big_Window=Big_Window,npair=npair) #
              Q=builder[[1]]
              Q=t(Q)
              A=as.vector(Q)
              keep=which(A>0&as.vector(Big_Xi)>0)
              A=A[keep]
              Big_Xi=as.vector(Big_Xi)
              Big_Xi=Big_Xi[keep]

              Tc=builder[[3]]
              scale_T=get('scale_T', envir=test.env)
              Tc=Tc*scale_T


              if(!BW){
                LH=-sum(log(A)*Big_Xi)
              }
              if(BW){
                g=matrix(0,nrow=length(Tc),ncol=2)
                g[,2]=1-exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                g[,1]=exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                x=as.vector(g)
                keep=which(x>0&as.vector(Big_M)>0)
                x=x[keep]
                m=as.vector(Big_M)
                m=m[keep]
                nu=builder[[2]]
                LH=-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
              }
              return(LH)
            }
            sol= BB::BBoptim(c(oldrho,oldbeta,oldsigma),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldrho,oldbeta,oldsigma)),M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:3,1])
            rho=sol[1]
            beta_=sol[2]
            sigma_=sol[3]
            print(paste(" new Complete likelihood : ", LH ))
            diff=max(abs(c(rho- oldrho,oldbeta-beta_,oldsigma-sigma_)))
            oldrho=rho
            oldbeta=beta_
            oldsigma=sigma_

          }
          if(!Popfix){
            function_to_minimize<-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)
              mu_b=get('mu_b', envir=test.env)
              FS=get('FS', envir=test.env)
              rho_=param[1]
              rho_=rho_*sum(Boxr)
              rho_=rho_-(Boxr[1])
              rho_=10^(rho_)
              Rho=get('Rho', envir=test.env)
              rho_=rho_*Rho
              BoxB=get('BoxB', envir=test.env)
              Boxs=get('Boxs', envir=test.env)
              beta=((param[2]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
              BoxP=get('BoxP', envir=test.env)
              sigma=param[3]
              sigma=sigma*(Boxs[2]-Boxs[1])
              sigma=sigma+Boxs[1]

              Xi_=param[4:length(param)]
              Xi=vector()
              pop_vect=get('pop_vect', envir=test.env)
              xx=0
              for(ix in 1:length(Xi_)){
                x=xx+1
                xx = xx + pop_vect[ix]
                Xi[x:xx]=Xi_[ix]
              }
              Xi=Xi*sum(BoxP)
              Xi=Xi-(BoxP[1])
              Xi=10^Xi
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              BW=get('BW', envir=test.env)
              if(BW){
                Big_M=get('Big_M', envir=test.env)
                q_=get('q_', envir=test.env)
              }
              Beta=get('Beta', envir=test.env)
              Self=get('Self', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)

              builder=build_HMM_matrix(n,rho_,beta,Pop = Pop,Xi=Xi,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
              Q=builder[[1]]
              Q=t(Q)
              A=as.vector(Q)
              keep=which(A>0&as.vector(Big_Xi)>0)
              A=A[keep]
              Big_Xi=as.vector(Big_Xi)
              Big_Xi=Big_Xi[keep]

              Tc=builder[[3]]
              scale_T=get('scale_T', envir=test.env)
              Tc=Tc*scale_T
              if(!BW){
                LH=-sum(log(A)*Big_Xi)
              }
              if(BW){
                g=matrix(0,nrow=length(Tc),ncol=2)
                g[,2]=1-exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                g[,1]=exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                x=as.vector(g)
                keep=which(x>0&as.vector(Big_M)>0)
                x=x[keep]
                m=as.vector(Big_M)
                m=m[keep]
                nu=builder[[2]]
                LH=-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
              }

              return(LH)
            }
            sol= BB::BBoptim(c(oldrho,oldbeta,oldsigma,oldXi_),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldrho,oldbeta,oldsigma,oldXi_)),M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:(3+(Klink)),1])
            rho=sol[1]
            beta_=sol[2]
            sigma_=sol[3]
            Xi_=sol[4:length(sol)]
            diff=max(abs(c(rho- oldrho,oldbeta-beta_,oldsigma-sigma_,Xi_-oldXi_)))
            oldrho=rho
            oldbeta=beta_
            oldXi_=Xi_
            oldsigma=sigma_

            print(paste(" new Complete likelihood : ",  -LH ))
            print(paste("Xi:",oldXi_))
          }
        }
        if(!SF){
          if(Popfix){
            function_to_minimize <-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)
              mu_b=get('mu_b', envir=test.env)
              FS=get('FS', envir=test.env)
              sigma=get('sigma',envir = test.env)
              Self=get('Self',envir = test.env)
              rho_=param[1]
              rho_=rho_*sum(Boxr)
              rho_=rho_-(Boxr[1])
              rho_=10^(rho_)
              Rho=get('Rho', envir=test.env)
              rho_=rho_*Rho
              BoxB=get('BoxB', envir=test.env)
              beta=((param[2]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              BW=get('BW', envir=test.env)
              if(BW){
                Big_M=get('Big_M', envir=test.env)
                q_=get('q_', envir=test.env)
              }
              Beta=get('Beta', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)

              builder=build_HMM_matrix(n,rho_,beta,Pop = Pop,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
              Q=builder[[1]]
              Q=t(Q)
              A=as.vector(Q)
              keep=which(A>0&as.vector(Big_Xi)>0)
              A=A[keep]
              Big_Xi=as.vector(Big_Xi)
              Big_Xi=Big_Xi[keep]

              Tc=builder[[3]]
              scale_T=get('scale_T', envir=test.env)
              Tc=Tc*scale_T

              if(!BW){
                LH=-sum(log(A)*Big_Xi)
              }
              if(BW){
                g=matrix(0,nrow=length(Tc),ncol=2)
                g[,2]=1-exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                g[,1]=exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                x=as.vector(g)
                                keep=which(x>0&as.vector(Big_M)>0)
                x=x[keep]
                m=as.vector(Big_M)
                m=m[keep]
                nu=builder[[2]]
                LH=-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
              }

              return(LH)
            }
            sol= BB::BBoptim(c(oldrho,oldbeta), function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldrho,oldbeta)),M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:2,1])
            rho=sol[1]
            beta_=sol[2]
            print(paste(" new Complete likelihood : ", LH ))
            diff=max(abs(c(rho- oldrho,oldbeta-beta_)))
            oldrho=rho
            oldbeta=beta_

          }
          if(!Popfix){
            function_to_minimize<-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)
              mu_b=get('mu_b', envir=test.env)
              FS=get('FS', envir=test.env)
              sigma=get('sigma',envir = test.env)
              rho_=param[1]
              rho_=rho_*sum(Boxr)
              rho_=rho_-(Boxr[1])
              rho_=10^(rho_)
              Rho=get('Rho', envir=test.env)
              rho_=rho_*Rho
              BoxB=get('BoxB', envir=test.env)
              beta=((param[2]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
              BETA=get('BETA',envir=test.env)
              BoxP=get('BoxP', envir=test.env)
              Xi_=param[3:length(param)]
              Xi=vector()
              pop_vect=get('pop_vect', envir=test.env)
              xx=0
              for(ix in 1:length(Xi_)){
                x=xx+1
                xx = xx + pop_vect[ix]
                Xi[x:xx]=Xi_[ix]
              }
              Xi=Xi*sum(BoxP)
              Xi=Xi-(BoxP[1])
              Xi=10^Xi
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              Beta=get('Beta', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)
              BW=get('BW', envir=test.env)
              if(BW){
                Big_M=get('Big_M', envir=test.env)
                q_=get('q_', envir=test.env)
              }

              Pop=get('Pop', envir=test.env)
              Self=get('Self', envir=test.env)

              builder=build_HMM_matrix(n,(rho_),beta,Pop = Pop,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
              Q=builder[[1]]
              Q=t(Q)
              A=as.vector(Q)
              keep=which(A>0&as.vector(Big_Xi)>0)
              A=A[keep]
              Big_Xi=as.vector(Big_Xi)
              Big_Xi=Big_Xi[keep]

              Tc=builder[[3]]
              scale_T=get('scale_T', envir=test.env)
              Tc=Tc*scale_T
              if(!BW){
                LH=-sum(log(A)*Big_Xi)
              }
              if(BW){
                g=matrix(0,nrow=length(Tc),ncol=2)
                g[,2]=1-exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                g[,1]=exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                x=as.vector(g)
                                keep=which(x>0&as.vector(Big_M)>0)
                x=x[keep]
                m=as.vector(Big_M)
                m=m[keep]
                nu=builder[[2]]
                LH=-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
              }
              return(LH)
            }
            sol= BB::BBoptim(c(oldrho,oldbeta,oldXi_),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldrho,oldbeta,oldXi_)),M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:(2+(Klink)),1])
            rho=sol[1]
            beta_=sol[2]
            Xi_=sol[3:length(sol)]
            diff=max(abs(c(rho- oldrho,oldbeta-beta_,Xi_-oldXi_)))
            oldrho=rho
            oldbeta=beta_
            oldXi_=Xi_

            print(paste(" new Complete likelihood : ",  -LH ))
            print(paste("Xi:",oldXi_))
          }
        }
      }
      if(!SB){
        if(SF){
          if(Popfix){
            function_to_minimize <-function(param){
              Boxr=get('Boxr', envir=test.env)
              mu_b=get('mu_b', envir=test.env)
              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)
              mu_b=get('mu_b', envir=test.env)
              FS=get('FS', envir=test.env)
              rho_=param[1]
              rho_=rho_*sum(Boxr)
              rho_=rho_-(Boxr[1])
              rho_=10^(rho_)
              Rho=get('Rho', envir=test.env)
              rho_=rho_*Rho
              beta=get('beta', envir=test.env)
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              BW=get('BW', envir=test.env)
              if(BW){
                Big_M=get('Big_M', envir=test.env)
                q_=get('q_', envir=test.env)
              }
              Beta=get('Beta', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)
              Boxs=get('Boxs', envir=test.env)
              Self=get('Self', envir=test.env)
              sigma=param[2]
              sigma=sigma*(Boxs[2]-Boxs[1])
              sigma=sigma+Boxs[1]

              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)

              builder=build_HMM_matrix(n,(rho_),beta,Pop = Pop,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
              Q=builder[[1]]
              Q=t(Q)
              A=as.vector(Q)
              keep=which(A>0&as.vector(Big_Xi)>0)
              A=A[keep]
              Big_Xi=as.vector(Big_Xi)
              Big_Xi=Big_Xi[keep]

              Tc=builder[[3]]
              scale_T=get('scale_T', envir=test.env)
              Tc=Tc*scale_T
              if(!BW){
                LH=-sum(log(A)*Big_Xi)
              }
              if(BW){
                g=matrix(0,nrow=length(Tc),ncol=2)
                g[,2]=1-exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                g[,1]=exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                x=as.vector(g)
                                keep=which(x>0&as.vector(Big_M)>0)
                x=x[keep]
                m=as.vector(Big_M)
                m=m[keep]
                nu=builder[[2]]
                LH=-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
              }

              return(LH)
            }
            sol= BB::BBoptim(c(oldrho,oldsigma), function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldrho,oldsigma)),M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:2,1])
            rho=sol[1]
            sigma_=sol[2]
            print(paste(" new Complete likelihood : ", LH ))
            diff=max(abs(c(rho- oldrho,oldsigma-sigma_)))
            oldrho=rho
            oldsigma=sigma_

          }
          if(!Popfix){
            function_to_minimize<-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)
              mu_b=get('mu_b', envir=test.env)
              FS=get('FS', envir=test.env)
              rho_=param[1]
              rho_=rho_*sum(Boxr)
              rho_=rho_-(Boxr[1])
              rho_=10^(rho_)
              Rho=get('Rho', envir=test.env)
              rho_=rho_*Rho
              beta=get('beta', envir=test.env)
              BoxP=get('BoxP', envir=test.env)
              Xi_=param[3:length(param)]
              Xi=vector()
              pop_vect=get('pop_vect', envir=test.env)
              xx=0
              for(ix in 1:length(Xi_)){
                x=xx+1
                xx = xx + pop_vect[ix]
                Xi[x:xx]=Xi_[ix]
              }
              Xi=Xi*sum(BoxP)
              Xi=Xi-(BoxP[1])
              Xi=10^Xi
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              BW=get('BW', envir=test.env)
              if(BW){
                Big_M=get('Big_M', envir=test.env)
                q_=get('q_', envir=test.env)
              }
              Beta=get('Beta', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)
              Boxs=get('Boxs', envir=test.env)
              Self=get('Self', envir=test.env)
              sigma=param[2]
              sigma=sigma*(Boxs[2]-Boxs[1])
              sigma=sigma+Boxs[1]

              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)

              builder=build_HMM_matrix(n,(rho_),beta,Pop = Pop,Xi=Xi,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
              Q=builder[[1]]
              Q=t(Q)
              A=as.vector(Q)
              keep=which(A>0&as.vector(Big_Xi)>0)
              A=A[keep]
              Big_Xi=as.vector(Big_Xi)
              Big_Xi=Big_Xi[keep]

              Tc=builder[[3]]
              scale_T=get('scale_T', envir=test.env)
              Tc=Tc*scale_T
              if(!BW){
                LH=-sum(log(A)*Big_Xi)
              }
              if(BW){
                g=matrix(0,nrow=length(Tc),ncol=2)
                g[,2]=1-exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                g[,1]=exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                x=as.vector(g)
                                keep=which(x>0&as.vector(Big_M)>0)
                x=x[keep]
                m=as.vector(Big_M)
                m=m[keep]
                nu=builder[[2]]
                LH=-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
              }

              return(LH)
            }
            sol= BB::BBoptim(c(oldrho,oldsigma,oldXi_),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldrho,oldsigma,oldXi_)),M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:(2+(Klink)),1])
            rho=sol[1]
            sigma_=sol[2]
            Xi_=sol[3:length(sol)]
            diff=max(abs(c(rho- oldrho,Xi_-oldXi_,oldsigma-sigma_)))
            oldrho=rho
            oldXi_=Xi_
            oldsigma=sigma_

            print(paste(" new Complete likelihood : ",  -LH ))
            print(paste("Xi:",oldXi_))
          }
        }
        if(!SF){
          if(Popfix){
            function_to_minimize <-function(param){
              Boxr=get('Boxr', envir=test.env)
              mu_b=get('mu_b', envir=test.env)
              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)
              mu_b=get('mu_b', envir=test.env)
              FS=get('FS', envir=test.env)
              sigma=get('sigma', envir=test.env)
              rho_=param[1]
              rho_=rho_*sum(Boxr)
              rho_=rho_-(Boxr[1])
              rho_=10^(rho_)
              Rho=get('Rho', envir=test.env)
              rho_=rho_*Rho
              beta=get('beta', envir=test.env)
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              BW=get('BW', envir=test.env)
              if(BW){
                Big_M=get('Big_M', envir=test.env)
                q_=get('q_', envir=test.env)
              }
              Beta=get('Beta', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)
              Self=get('Self', envir=test.env)
              sigma=get('sigma', envir=test.env)

              builder=build_HMM_matrix(n,(rho_),beta,Pop = Pop,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
              Q=builder[[1]]
              Q=t(Q)
              A=as.vector(Q)
              keep=which(A>0&as.vector(Big_Xi)>0)
              A=A[keep]
              Big_Xi=as.vector(Big_Xi)
              Big_Xi=Big_Xi[keep]

              Tc=builder[[3]]
              scale_T=get('scale_T', envir=test.env)
              Tc=Tc*scale_T
              if(!BW){
                LH=-sum(log(A)*Big_Xi)
              }
              if(BW){
                g=matrix(0,nrow=length(Tc),ncol=2)
                g[,2]=1-exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                g[,1]=exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                x=as.vector(g)
                                keep=which(x>0&as.vector(Big_M)>0)
                x=x[keep]
                m=as.vector(Big_M)
                m=m[keep]
                nu=builder[[2]]
                LH=-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
              }

              return(LH)
            }
            sol= BB::BBoptim(c(oldrho),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldrho)),M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1,1])
            rho=sol[1]
            print(paste(" new Complete likelihood : ", LH ))
            diff=max(abs(c(rho- oldrho)))
            oldrho=rho

          }

          if(!Popfix){

            function_to_minimize<-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)
              mu_b=get('mu_b', envir=test.env)
              FS=get('FS', envir=test.env)
              sigma=get('sigma', envir=test.env)
              rho_=param[1]
              rho_=rho_*sum(Boxr)
              rho_=rho_-(Boxr[1])
              rho_=10^(rho_)
              Rho=get('Rho', envir=test.env)
              rho_=rho_*Rho
              beta=get('beta', envir=test.env)
              BoxP=get('BoxP', envir=test.env)
              Xi_=param[2:length(param)]
              Xi=vector()
              pop_vect=get('pop_vect', envir=test.env)
              xx=0
              for(ix in 1:length(Xi_)){
                x=xx+1
                xx = xx + pop_vect[ix]
                Xi[x:xx]=Xi_[ix]
              }
              Xi=Xi*sum(BoxP)
              Xi=Xi-(BoxP[1])
              Xi=10^Xi
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              BW=get('BW', envir=test.env)
              if(BW){
                Big_M=get('Big_M', envir=test.env)
                q_=get('q_', envir=test.env)
              }
              Beta=get('Beta', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)
              Self=get('Self', envir=test.env)

              builder=build_HMM_matrix(n,(rho_),beta,Pop = Pop,Xi=Xi,L=L,Beta=Beta,scale=window_scaling,Big_Window=Big_Window,npair=npair)
              Q=builder[[1]]
              Q=t(Q)
              A=as.vector(Q)
              keep=which(A>0&as.vector(Big_Xi)>0)
              A=A[keep]
              Big_Xi=as.vector(Big_Xi)
              Big_Xi=Big_Xi[keep]

              Tc=builder[[3]]
              scale_T=get('scale_T', envir=test.env)
              Tc=Tc*scale_T
              if(!BW){
                LH=-sum(log(A)*Big_Xi)
              }
              if(BW){
                g=matrix(0,nrow=length(Tc),ncol=2)
                g[,2]=1-exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                g[,1]=exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                x=as.vector(g)
                keep=which(x>0&as.vector(Big_M)>0)
                x=x[keep]
                m=as.vector(Big_M)
                m=m[keep]
                nu=builder[[2]]
                LH=-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
              }

              return(LH)
            }
            sol= BB::BBoptim(c(oldrho,oldXi_),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldrho,oldXi_)),M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:(1+(Klink)),1])
            rho=sol[1]
            Xi_=sol[2:length(sol)]
            diff=max(abs(c(rho- oldrho,Xi_-oldXi_)))
            oldrho=rho
            oldXi_=Xi_

            print(paste(" new Complete likelihood : ",  -LH ))
            print(paste("Xi:",oldXi_))
          }
        }
      }
    }
    if(!ER){
      if(SB){
        if(SF){
          if(Popfix){
            function_to_minimize <-function(param){
              Boxr=get('Boxr', envir=test.env)
              mu_b=get('mu_b', envir=test.env)
              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)

              FS=get('FS', envir=test.env)
              Rho=get('Rho', envir=test.env)
              rho_=Rho
              BoxB=get('BoxB', envir=test.env)
              beta=((param[1]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              BW=get('BW', envir=test.env)
              if(BW){
                Big_M=get('Big_M', envir=test.env)
                q_=get('q_', envir=test.env)
              }
              Beta=get('Beta', envir=test.env)
              Boxs=get('Boxs', envir=test.env)
              Self=get('Self', envir=test.env)
              sigma=param[2]
              sigma=sigma*(Boxs[2]-Boxs[1])
              sigma=sigma+Boxs[1]

              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)

              builder=build_HMM_matrix(n,(rho_),beta,Pop = Pop,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
              Q=builder[[1]]
              Q=t(Q)
              A=as.vector(Q)
              keep=which(A>0&as.vector(Big_Xi)>0)
              A=A[keep]
              Big_Xi=as.vector(Big_Xi)
              Big_Xi=Big_Xi[keep]

              Tc=builder[[3]]

              scale_T=get('scale_T', envir=test.env)
              Tc=Tc*scale_T
              if(!BW){
                LH=-sum(log(A)*Big_Xi)
              }
              if(BW){
                g=matrix(0,nrow=length(Tc),ncol=2)
                g[,2]=1-exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                g[,1]=exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                x=as.vector(g)
                                keep=which(x>0&as.vector(Big_M)>0)
                x=x[keep]
                m=as.vector(Big_M)
                m=m[keep]
                nu=builder[[2]]
                LH=-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
              }

              return(LH)
            }
            sol= BB::BBoptim(c(oldbeta,oldsigma),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldbeta,oldsigma)),M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:2,1])
            beta_=sol[1]
            sigma_=sol[2]
            print(paste(" new Complete likelihood : ", LH ))
            diff=max(abs(c(oldbeta-beta_,oldsigma-sigma_)))
            oldbeta=beta_
            oldsigma=sigma_

          }
          if(!Popfix){
            function_to_minimize<-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)
              mu_b=get('mu_b', envir=test.env)
              FS=get('FS', envir=test.env)
              Rho=get('Rho', envir=test.env)
              rho_=Rho
              BoxB=get('BoxB', envir=test.env)
              Boxs=get('Boxs', envir=test.env)
              beta=((param[1]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
              BoxP=get('BoxP', envir=test.env)
              sigma=param[2]
              sigma=sigma*(Boxs[2]-Boxs[1])
              sigma=sigma+Boxs[1]

              Xi_=param[3:length(param)]
              Xi=vector()
              pop_vect=get('pop_vect', envir=test.env)
              xx=0
              for(ix in 1:length(Xi_)){
                x=xx+1
                xx = xx + pop_vect[ix]
                Xi[x:xx]=Xi_[ix]
              }
              Xi=Xi*sum(BoxP)
              Xi=Xi-(BoxP[1])
              Xi=10^Xi
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              Beta=get('Beta', envir=test.env)
              Self=get('Self', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)
              BW=get('BW', envir=test.env)
              if(BW){
                Big_M=get('Big_M', envir=test.env)
                q_=get('q_', envir=test.env)
              }

              Pop=get('Pop', envir=test.env)

              builder=build_HMM_matrix(n,(rho_),beta,Pop = Pop,Xi=Xi,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
              Q=builder[[1]]
              Q=t(Q)
              A=as.vector(Q)
              keep=which(A>0&as.vector(Big_Xi)>0)
              A=A[keep]
              Big_Xi=as.vector(Big_Xi)
              Big_Xi=Big_Xi[keep]

              Tc=builder[[3]]
              scale_T=get('scale_T', envir=test.env)
              Tc=Tc*scale_T
              if(!BW){
                LH=-sum(log(A)*Big_Xi)
              }
              if(BW){
                g=matrix(0,nrow=length(Tc),ncol=2)
                g[,2]=1-exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                g[,1]=exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                x=as.vector(g)
                                keep=which(x>0&as.vector(Big_M)>0)
                x=x[keep]
                m=as.vector(Big_M)
                m=m[keep]
                nu=builder[[2]]
                LH=-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
              }

              return(LH)
            }
            sol= BB::BBoptim(c(oldbeta,oldsigma,oldXi_),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldbeta,oldsigma,oldXi_)),M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:(2+(Klink)),1])
            beta_=sol[1]
            sigma_=sol[2]
            Xi_=sol[3:length(sol)]
            diff=max(abs(c(oldbeta-beta_,oldsigma-sigma_,Xi_-oldXi_)))
            oldbeta=beta_
            oldXi_=Xi_
            oldsigma=sigma_

            print(paste(" new Complete likelihood : ",  -LH ))
            print(paste("Xi:",oldXi_))
          }
        }
        if(!SF){
          if(Popfix){
            function_to_minimize <-function(param){
              Boxr=get('Boxr', envir=test.env)
              sigma=get('sigma', envir=test.env)
              mu_b=get('mu_b', envir=test.env)
              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)

              FS=get('FS', envir=test.env)
              Rho=get('Rho', envir=test.env)
              rho_=Rho
              BoxB=get('BoxB', envir=test.env)
              beta=((param[1]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              BW=get('BW', envir=test.env)
              if(BW){
                Big_M=get('Big_M', envir=test.env)
                q_=get('q_', envir=test.env)
              }
              Beta=get('Beta', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)
              Self=get('Self', envir=test.env)

              builder=build_HMM_matrix(n,(rho_),beta,Pop = Pop,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
              Q=builder[[1]]
              Q=t(Q)
              A=as.vector(Q)
              keep=which(A>0&as.vector(Big_Xi)>0)
              A=A[keep]
              Big_Xi=as.vector(Big_Xi)
              Big_Xi=Big_Xi[keep]

              Tc=builder[[3]]
              scale_T=get('scale_T', envir=test.env)
              Tc=Tc*scale_T

              if(!BW){
                LH=-sum(log(A)*Big_Xi)
              }
              if(BW){
                g=matrix(0,nrow=length(Tc),ncol=2)
                g[,2]=1-exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                g[,1]=exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                x=as.vector(g)
                                keep=which(x>0&as.vector(Big_M)>0)
                x=x[keep]
                m=as.vector(Big_M)
                m=m[keep]
                nu=builder[[2]]
                LH=-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
              }

              return(LH)
            }
            sol= BB::BBoptim(c(oldbeta),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldbeta)),M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1,1])
            beta_=sol[1]
            print(paste(" new Complete likelihood : ", LH ))

            diff=max(abs(c(oldbeta-beta_)))
            oldbeta=beta_

          }
          if(!Popfix){
            function_to_minimize<-function(param){

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)
              mu_b=get('mu_b', envir=test.env)
              FS=get('FS', envir=test.env)
              Rho=get('Rho', envir=test.env)
              sigma=get('sigma', envir=test.env)
              rho_=Rho
              BoxB=get('BoxB', envir=test.env)
              beta=((param[1]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
              BoxP=get('BoxP', envir=test.env)
              Xi_=param[2:length(param)]
              Xi=vector()
              pop_vect=get('pop_vect', envir=test.env)
              xx=0
              for(ix in 1:length(Xi_)){
                x=xx+1
                xx = xx + pop_vect[ix]
                Xi[x:xx]=Xi_[ix]
              }
              Xi=Xi*sum(BoxP)
              Xi=Xi-(BoxP[1])
              Xi=10^Xi
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              Beta=get('Beta', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)
              BW=get('BW', envir=test.env)
              if(BW){
                Big_M=get('Big_M', envir=test.env)
                q_=get('q_', envir=test.env)
              }

              Pop=get('Pop', envir=test.env)
              Self=get('Self', envir=test.env)

              builder=build_HMM_matrix(n,(rho_),beta,Pop = Pop,Xi=Xi,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,Big_Window=Big_Window,npair=npair) #
              Q=builder[[1]]
              Q=t(Q)
              A=as.vector(Q)
              keep=which(A>0&as.vector(Big_Xi)>0)
              A=A[keep]
              Big_Xi=as.vector(Big_Xi)
              Big_Xi=Big_Xi[keep]

              Tc=builder[[3]]
              scale_T=get('scale_T', envir=test.env)
              Tc=Tc*scale_T
              if(!BW){
                LH=-sum(log(A)*Big_Xi)
              }
              if(BW){
                g=matrix(0,nrow=length(Tc),ncol=2)
                g[,2]=1-exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                g[,1]=exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                x=as.vector(g)
                                keep=which(x>0&as.vector(Big_M)>0)
                x=x[keep]
                m=as.vector(Big_M)
                m=m[keep]
                nu=builder[[2]]
                LH=-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
              }

              return(LH)
            }
            sol= BB::BBoptim(c(oldbeta,oldXi_),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldbeta,oldXi_)),M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:(1+(Klink)),1])
            beta_=sol[1]
            Xi_=sol[2:length(sol)]

            diff=max(abs(c(oldbeta-beta_,Xi_-oldXi_)))
            oldbeta=beta_
            oldXi_=Xi_

            print(paste(" new Complete likelihood : ",  -LH ))
            print(paste("Xi:",oldXi_))
          }
        }
      }
      if(!SB){
        if(SF){
          if(Popfix){
            function_to_minimize <-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)
              mu_b=get('mu_b', envir=test.env)
              FS=get('FS', envir=test.env)
              Rho=get('Rho', envir=test.env)
              rho_=Rho
              beta=get('beta', envir=test.env)
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              BW=get('BW', envir=test.env)
              if(BW){
                Big_M=get('Big_M', envir=test.env)
                q_=get('q_', envir=test.env)
              }
              Beta=get('Beta', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)
              Boxs=get('Boxs', envir=test.env)
              Self=get('Self', envir=test.env)
              sigma=param[1]
              sigma=sigma*(Boxs[2]-Boxs[1])
              sigma=sigma+Boxs[1]

              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)

              builder=build_HMM_matrix(n,(rho_),beta,Pop = Pop,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
              Q=builder[[1]]
              Q=t(Q)
              A=as.vector(Q)
              keep=which(A>0&as.vector(Big_Xi)>0)
              A=A[keep]
              Big_Xi=as.vector(Big_Xi)
              Big_Xi=Big_Xi[keep]

              Tc=builder[[3]]

              scale_T=get('scale_T', envir=test.env)
              Tc=Tc*scale_T
              if(!BW){
                LH=-sum(log(A)*Big_Xi)
              }
              if(BW){
                g=matrix(0,nrow=length(Tc),ncol=2)
                g[,2]=1-exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                g[,1]=exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                x=as.vector(g)
                                keep=which(x>0&as.vector(Big_M)>0)
                x=x[keep]
                m=as.vector(Big_M)
                m=m[keep]
                nu=builder[[2]]
                LH=-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
              }

              return(LH)
            }
            sol= BB::BBoptim(c(oldsigma),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldsigma)),M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1,1])
            sigma_=sol[1]
            print(paste(" new Complete likelihood : ", LH ))
            diff=max(abs(c(oldsigma-sigma_)))
            oldsigma=sigma_

          }

          if(!Popfix){

            function_to_minimize<-function(param){
              Boxr=get('Boxr', envir=test.env)
              Rho=get('Rho', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)
              mu_b=get('mu_b', envir=test.env)
              FS=get('FS', envir=test.env)
              rho_=Rho
              beta=get('beta', envir=test.env)
              BoxP=get('BoxP', envir=test.env)
              Xi_=param[2:length(param)]
              Xi=vector()
              pop_vect=get('pop_vect', envir=test.env)
              xx=0
              for(ix in 1:length(Xi_)){
                x=xx+1
                xx = xx + pop_vect[ix]
                Xi[x:xx]=Xi_[ix]
              }
              Xi=Xi*sum(BoxP)
              Xi=Xi-(BoxP[1])
              Xi=10^Xi
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              BW=get('BW', envir=test.env)
              if(BW){
                Big_M=get('Big_M', envir=test.env)
                q_=get('q_', envir=test.env)
              }
              Beta=get('Beta', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)
              Boxs=get('Boxs', envir=test.env)
              Self=get('Self', envir=test.env)
              sigma=param[1]
              sigma=sigma*(Boxs[2]-Boxs[1])
              sigma=sigma+Boxs[1]

              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)

              builder=build_HMM_matrix(n,(rho_),beta,Pop = Pop,Xi=Xi,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
              Q=builder[[1]]
              Q=t(Q)
              A=as.vector(Q)
              keep=which(A>0&as.vector(Big_Xi)>0)
              A=A[keep]
              Big_Xi=as.vector(Big_Xi)
              Big_Xi=Big_Xi[keep]

              Tc=builder[[3]]
              scale_T=get('scale_T', envir=test.env)
              Tc=Tc*scale_T
              if(!BW){
                LH=-sum(log(A)*Big_Xi)
              }
              if(BW){
                g=matrix(0,nrow=length(Tc),ncol=2)
                g[,2]=1-exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                g[,1]=exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                x=as.vector(g)
                                keep=which(x>0&as.vector(Big_M)>0)
                x=x[keep]
                m=as.vector(Big_M)
                m=m[keep]
                nu=builder[[2]]
                LH=-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
              }

              return(LH)
            }
            sol= BB::BBoptim(c(oldsigma,oldXi_),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldsigma,oldXi_)),M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:(1+(Klink)),1])
            sigma_=sol[1]
            Xi_=sol[2:length(sol)]
            diff=max(abs(c(Xi_-oldXi_,oldsigma-sigma_)))
            oldXi_=Xi_
            oldsigma=sigma_

            print(paste(" new Complete likelihood : ",  -LH ))
            print(paste("Xi:",oldXi_))
          }
        }
        if(!SF){
          if(!Popfix){
            function_to_minimize<-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)
              mu_b=get('mu_b', envir=test.env)
              FS=get('FS', envir=test.env)
              sigma=get('sigma', envir=test.env)
              Rho=get('Rho', envir=test.env)
              rho_=Rho
              beta=get('beta', envir=test.env)
              BoxP=get('BoxP', envir=test.env)
              Xi_=param[1:length(param)]
              Xi=vector()
              pop_vect=get('pop_vect', envir=test.env)
              xx=0
              for(ix in 1:length(Xi_)){
                x=xx+1
                xx = xx + pop_vect[ix]
                Xi[x:xx]=Xi_[ix]
              }
              Xi=Xi*sum(BoxP)
              Xi=Xi-(BoxP[1])
              Xi=10^Xi
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              Beta=get('Beta', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)
              BW=get('BW', envir=test.env)
              if(BW){
                Big_M=get('Big_M', envir=test.env)
                q_=get('q_', envir=test.env)
              }

              Pop=get('Pop', envir=test.env)
              Self=get('Self', envir=test.env)

              builder=build_HMM_matrix(n,(rho_),beta,Pop = Pop,Xi=Xi,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
              Q=builder[[1]]
              Q=t(Q)
              A=as.vector(Q)
              keep=which(A>0&as.vector(Big_Xi)>0)
              A=A[keep]
              Big_Xi=as.vector(Big_Xi)
              Big_Xi=Big_Xi[keep]

              Tc=builder[[3]]

              scale_T=get('scale_T', envir=test.env)
              Tc=Tc*scale_T
              if(!BW){
                LH=-sum(log(A)*Big_Xi)
              }
              if(BW){
                g=matrix(0,nrow=length(Tc),ncol=2)
                g[,2]=1-exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                g[,1]=exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                x=as.vector(g)
                                  keep=which(x>0&as.vector(as.vector(Big_M))>0)
                x=x[keep]
                m=as.vector(Big_M)
                m=m[keep]
                nu=builder[[2]]
                LH=-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
              }
              return(LH)
            }
            sol= BB::BBoptim(c(oldXi_),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldXi_)),M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:((Klink)),1])
            Xi_=sol[1:length(sol)]
            diff=max(abs(c(rho- oldrho,Xi_-oldXi_)))
            oldXi_=Xi_

            print(paste(" new Complete likelihood : ",  -LH ))
            print(paste("Xi:",oldXi_))
          }
        }


      }
    }
  }
  if(NC>1){
    if(ER){
      if(SB){
        if(SF){
          if(Popfix){
            function_to_minimize <-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)
              mu_b=get('mu_b', envir=test.env)
              FS=get('FS', envir=test.env)
              NC=get('NC', envir=test.env)
              lr=get('lr', envir=test.env)
              rho_=param[1:lr]
              rho_=rho_*sum(Boxr)
              rho_=rho_-(Boxr[1])
              rho_=10^(rho_)
              Rho=get('Rho', envir=test.env)
              rho_=rho_*Rho
              BoxB=get('BoxB', envir=test.env)
              beta=((param[(lr+1)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              BW=get('BW', envir=test.env)
              if(BW){
                Big_M=get('Big_M', envir=test.env)
                q_=get('q_', envir=test.env)
              }
              Beta=get('Beta', envir=test.env)
              Boxs=get('Boxs', envir=test.env)
              Self=get('Self', envir=test.env)
              sigma=param[lr+2]
              sigma=sigma*(Boxs[2]-Boxs[1])
              sigma=sigma+Boxs[1]

              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)

              LH=0
              for(chr in 1:NC){
                builder=build_HMM_matrix(n,(rho_[chr]),beta,Pop = Pop,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
                Q=builder[[1]]
                Q=t(Q)
                A=as.vector(Q)
                keep=which(A>0&as.vector(Big_Xi[[chr]])>0)
                A=A[keep]
                Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                Tc=builder[[3]]
                scale_T=get('scale_T', envir=test.env)
                Tc=Tc*scale_T

                if(!BW){
                  LH=LH-sum(log(A)*Big_Xi[[chr]])
                }
                if(BW){
                  g=matrix(0,nrow=length(Tc),ncol=2)
                  g[,2]=1-exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                  g[,1]=exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                  x=as.vector(g)
                  keep=which(x>0&as.vector(as.vector(Big_M[[chr]]))>0)
                  x=x[keep]
                  m=as.vector(Big_M[[chr]])
                  m=m[keep]
                  nu=builder[[2]]
                  LH=-sum(log(A)*Big_Xi[[chr]])-sum(log(x)*m)-sum(log(nu)*q_[[chr]])
                }

              }
              return(LH)
            }
            sol= BB::BBoptim(c(oldrho,oldbeta,oldsigma),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:(length(oldrho)+2),1])
            rho=sol[1:length(oldrho)]
            beta_=sol[length(oldrho)+1]
            sigma_=sol[length(oldrho)+2]
            diff=max(abs(c(rho- oldrho,oldbeta-beta_,oldsigma-sigma_)))
            oldrho=rho
            oldbeta=beta_
            oldsigma=sigma_
          }
          if(!Popfix){
            function_to_minimize_optim<-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)
              mu_b=get('mu_b', envir=test.env)
              FS=get('FS', envir=test.env)
              NC=get('NC', envir=test.env)
              lr=get('lr', envir=test.env)
              rho_=param[1:lr]
              rho_=rho_*sum(Boxr)
              rho_=rho_-(Boxr[1])
              rho_=10^(rho_)
              Rho=get('Rho', envir=test.env)
              rho_=rho_*Rho
              BoxB=get('BoxB', envir=test.env)
              Boxs=get('Boxs', envir=test.env)
              beta=((param[(lr+1)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
              BoxP=get('BoxP', envir=test.env)
              sigma=param[lr+2]
              sigma=sigma*(Boxs[2]-Boxs[1])
              sigma=sigma+Boxs[1]

              Xi_=param[3+lr:length(param)]
              Xi=vector()
              pop_vect=get('pop_vect', envir=test.env)
              xx=0
              for(ix in 1:length(Xi_)){
                x=xx+1
                xx = xx + pop_vect[ix]
                Xi[x:xx]=Xi_[ix]
              }
              Xi=Xi*sum(BoxP)
              Xi=Xi-(BoxP[1])
              Xi=10^Xi
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              Beta=get('Beta', envir=test.env)
              Self=get('Self', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)
              BW=get('BW', envir=test.env)
              if(BW){
                Big_M=get('Big_M', envir=test.env)
                q_=get('q_', envir=test.env)
              }

              Pop=get('Pop', envir=test.env)
              LH=0


              for(chr in 1:NC){
                builder=build_HMM_matrix(n,(rho_[chr]),beta,Pop = Pop,Xi=Xi,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
                Q=builder[[1]]
                Q=t(Q)
                A=as.vector(Q)
                keep=which(A>0&as.vector(Big_Xi[[chr]])>0)
                A=A[keep]
                Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                Tc=builder[[3]]
                scale_T=get('scale_T', envir=test.env)
                Tc=Tc*scale_T

                if(!BW){
                  LH=LH-sum(log(A)*Big_Xi[[chr]])
                }
                if(BW){
                  g=matrix(0,nrow=length(Tc),ncol=2)
                  g[,2]=1-exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                  g[,1]=exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                  x=as.vector(g)
                                    keep=which(x>0&as.vector(as.vector(Big_M[[chr]]))>0)
                  x=x[keep]
                  m=as.vector(Big_M[[chr]])
                  m=m[keep]
                  nu=builder[[2]]
                  LH=-sum(log(A)*Big_Xi[[chr]])-sum(log(x)*m)-sum(log(nu)*q_[[chr]])
                }

              }
              return(LH)
            }
            sol= BB::BBoptim(c(oldrho,oldbeta,oldsigma,oldXi_),function_to_minimize_optim,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:(2+length(oldrho)+(Klink)),1])
            rho=sol[1:length(oldrho)]
            beta_=sol[length(oldrho)+1]
            sigma_=sol[length(oldrho)+2]
            Xi_=sol[(length(oldrho)+3):length(sol)]
            diff=max(abs(c(rho- oldrho,oldbeta-beta_,oldsigma-sigma_,Xi_-oldXi_)))
            oldrho=rho
            oldbeta=beta_
            oldXi_=Xi_
            oldsigma=sigma_
            print(paste("Xi:",oldXi_))
          }
        }
        if(!SF){
          if(Popfix){
            function_to_minimize <-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)
              mu_b=get('mu_b', envir=test.env)
              FS=get('FS', envir=test.env)
              NC=get('NC', envir=test.env)
              lr=get('lr', envir=test.env)
              rho_=param[1:lr]
              rho_=rho_*sum(Boxr)
              rho_=rho_-(Boxr[1])
              rho_=10^(rho_)
              Rho=get('Rho', envir=test.env)
              rho_=rho_*Rho
              BoxB=get('BoxB', envir=test.env)
              beta=((param[(lr+1)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              BW=get('BW', envir=test.env)
              if(BW){
                Big_M=get('Big_M', envir=test.env)
                q_=get('q_', envir=test.env)
              }
              Beta=get('Beta', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)

              LH=0
              Self=get('Self', envir=test.env)
              sigma=get('sigma', envir=test.env)

              for(chr in 1:NC){
                builder=build_HMM_matrix(n,(rho_[chr]),beta,Pop = Pop,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
                Q=builder[[1]]
                Q=t(Q)
                A=as.vector(Q)
                keep=which(A>0&as.vector(Big_Xi[[chr]])>0)
                A=A[keep]
                Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                Tc=builder[[3]]

                scale_T=get('scale_T', envir=test.env)
                Tc=Tc*scale_T
                if(!BW){
                  LH=LH-sum(log(A)*Big_Xi[[chr]])
                }
                if(BW){
                  g=matrix(0,nrow=length(Tc),ncol=2)
                  g[,2]=1-exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                  g[,1]=exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                  x=as.vector(g)
                                    keep=which(x>0&as.vector(as.vector(Big_M[[chr]]))>0)
                  x=x[keep]
                  m=as.vector(Big_M[[chr]])
                  m=m[keep]
                  nu=builder[[2]]
                  LH=-sum(log(A)*Big_Xi[[chr]])-sum(log(x)*m)-sum(log(nu)*q_[[chr]])
                }


              }
              return(LH)
            }
            sol= BB::BBoptim(c(oldrho,oldbeta),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:(length(oldrho)+1),1])
            rho=sol[1:length(oldrho)]
            beta_=sol[length(oldrho)+1]
            diff=max(abs(c(rho- oldrho,oldbeta-beta_)))
            oldrho=rho
            oldbeta=beta_
          }
          if(!Popfix){
            function_to_minimize_optim<-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)
              mu_b=get('mu_b', envir=test.env)
              FS=get('FS', envir=test.env)
              NC=get('NC',envir=test.env)
              lr=get('lr', envir=test.env)
              rho_=param[1:lr]
              rho_=rho_*sum(Boxr)
              rho_=rho_-(Boxr[1])
              rho_=10^(rho_)
              Rho=get('Rho', envir=test.env)
              rho_=rho_*Rho
              BoxB=get('BoxB', envir=test.env)
              beta=((param[(lr+1)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
              BoxP=get('BoxP', envir=test.env)
              Xi_=param[(lr+2):length(param)]
              Xi=vector()
              pop_vect=get('pop_vect', envir=test.env)
              xx=0
              for(ix in 1:length(Xi_)){
                x=xx+1
                xx = xx + pop_vect[ix]
                Xi[x:xx]=Xi_[ix]
              }
              Xi=Xi*sum(BoxP)
              Xi=Xi-(BoxP[1])
              Xi=10^Xi
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              BW=get('BW', envir=test.env)
              if(BW){
                Big_M=get('Big_M', envir=test.env)
                q_=get('q_', envir=test.env)
              }
              Beta=get('Beta', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)
              LH=0
              Self=get('Self', envir=test.env)
              sigma=get('sigma', envir=test.env)

              for( chr in 1:chr){
                builder=build_HMM_matrix(n,(rho_[chr]),beta,Pop = Pop,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
                Q=builder[[1]]
                Q=t(Q)
                A=as.vector(Q)
                keep=which(A>0&as.vector(Big_Xi[[chr]])>0)
                A=A[keep]
                Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                Tc=builder[[3]]
                scale_T=get('scale_T', envir=test.env)
                Tc=Tc*scale_T

                if(!BW){
                  LH=LH-sum(log(A)*Big_Xi[[chr]])
                }
                if(BW){
                  g=matrix(0,nrow=length(Tc),ncol=2)
                  g[,2]=1-exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                  g[,1]=exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                  x=as.vector(g)
                                    keep=which(x>0&as.vector(as.vector(Big_M[[chr]]))>0)
                  x=x[keep]
                  m=as.vector(Big_M[[chr]])
                  m=m[keep]
                  nu=builder[[2]]
                  LH=-sum(log(A)*Big_Xi[[chr]])-sum(log(x)*m)-sum(log(nu)*q_[[chr]])
                }


              }
              return(LH)
            }
            sol= BB::BBoptim(c(oldrho,oldbeta,oldXi_),function_to_minimize_optim,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:(1+length(oldrho)+(Klink)),1])
            rho=sol[1:length(oldrho)]
            beta_=sol[1+length(oldrho)]
            Xi_=sol[(2+length(oldrho)):length(sol)]
            diff=max(abs(c(rho- oldrho,oldbeta-beta_,Xi_-oldXi_)))
            oldrho=rho
            oldbeta=beta_
            oldXi_=Xi_
            print(paste("Xi:",oldXi_))
          }
        }
      }

      if(!SB){
        if(SF){
          if(Popfix){
            function_to_minimize <-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)
              mu_b=get('mu_b', envir=test.env)
              FS=get('FS', envir=test.env)
              NC=get('NC', envir=test.env)
              lr=get('lr', envir=test.env)
              rho_=param[1:lr]
              rho_=rho_*sum(Boxr)
              rho_=rho_-(Boxr[1])
              rho_=10^(rho_)
              Rho=get('Rho', envir=test.env)
              rho_=rho_*Rho
              beta=get('beta', envir=test.env)
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              Beta=get('Beta', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)
              Boxs=get('Boxs', envir=test.env)
              Self=get('Self', envir=test.env)
              BW=get('BW', envir=test.env)
              if(BW){
                Big_M=get('Big_M', envir=test.env)
                q_=get('q_', envir=test.env)
              }
              sigma=param[1+lr]
              sigma=sigma*(Boxs[2]-Boxs[1])
              sigma=sigma+Boxs[1]

              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)

              LH=0
              for(chr in 1:NC){
                builder=build_HMM_matrix(n,(rho_[chr]),beta,Pop = Pop,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
                Q=builder[[1]]
                Q=t(Q)
                A=as.vector(Q)
                keep=which(A>0&as.vector(Big_Xi[[chr]])>0)
                A=A[keep]
                Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                Tc=builder[[3]]
                scale_T=get('scale_T', envir=test.env)
                Tc=Tc*scale_T
                if(!BW){
                  LH=LH-sum(log(A)*Big_Xi[[chr]])
                }
                if(BW){
                  g=matrix(0,nrow=length(Tc),ncol=2)
                  g[,2]=1-exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                  g[,1]=exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                  x=as.vector(g)
                                    keep=which(x>0&as.vector(as.vector(Big_M[[chr]]))>0)
                  x=x[keep]
                  m=as.vector(Big_M[[chr]])
                  m=m[keep]
                  nu=builder[[2]]
                  LH=-sum(log(A)*Big_Xi[[chr]])-sum(log(x)*m)-sum(log(nu)*q_[[chr]])
                }


              }
              return(LH)
            }
            sol= BB::BBoptim(c(oldrho,oldsigma),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:(length(oldrho)+1),1])
            rho=sol[1:length(oldrho)]
            sigma_=sol[length(oldrho)+1]
            diff=max(abs(c(rho- oldrho,oldsigma-sigma_)))
            oldrho=rho
            oldsigma=sigma_
          }
          if(!Popfix){
            function_to_minimize_optim<-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)
              mu_b=get('mu_b', envir=test.env)
              FS=get('FS', envir=test.env)
              NC=get('NC', envir=test.env)
              lr=get('lr', envir=test.env)
              rho_=param[1:lr]
              rho_=rho_*sum(Boxr)
              rho_=rho_-(Boxr[1])
              rho_=10^(rho_)
              Rho=get('Rho', envir=test.env)
              rho_=rho_*Rho
              beta=get('beta', envir=test.env)
              BoxP=get('BoxP', envir=test.env)
              Xi_=param[(2+lr):length(param)]
              Xi=vector()
              pop_vect=get('pop_vect', envir=test.env)
              xx=0
              for(ix in 1:length(Xi_)){
                x=xx+1
                xx = xx + pop_vect[ix]
                Xi[x:xx]=Xi_[ix]
              }
              Xi=Xi*sum(BoxP)
              Xi=Xi-(BoxP[1])
              Xi=10^Xi
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              BW=get('BW', envir=test.env)
              if(BW){
                Big_M=get('Big_M', envir=test.env)
                q_=get('q_', envir=test.env)
              }
              Beta=get('Beta', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)
              Boxs=get('Boxs', envir=test.env)
              Self=get('Self', envir=test.env)
              sigma=param[1+lr]
              sigma=sigma*(Boxs[2]-Boxs[1])
              sigma=sigma+Boxs[1]

              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)


              LH=0
              for( chr in 1:NC){
                builder=build_HMM_matrix(n,(rho_[chr]),beta,Pop = Pop,Xi=Xi,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
                Q=builder[[1]]
                Q=t(Q)
                A=as.vector(Q)
                keep=which(A>0&as.vector(Big_Xi[[chr]])>0)
                A=A[keep]
                Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                Tc=builder[[3]]
                scale_T=get('scale_T', envir=test.env)
                Tc=Tc*scale_T
                if(!BW){
                  LH=LH-sum(log(A)*Big_Xi[[chr]])
                }
                if(BW){
                  g=matrix(0,nrow=length(Tc),ncol=2)
                  g[,2]=1-exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                  g[,1]=exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                  x=as.vector(g)
                                    keep=which(x>0&as.vector(as.vector(Big_M[[chr]]))>0)
                  x=x[keep]
                  m=as.vector(Big_M[[chr]])
                  m=m[keep]
                  nu=builder[[2]]
                  LH=-sum(log(A)*Big_Xi[[chr]])-sum(log(x)*m)-sum(log(nu)*q_[[chr]])
                }


              }
              return(LH)
            }
            sol= BB::BBoptim(c(oldrho,oldsigma,oldXi_),function_to_minimize_optim,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:(1+length(oldrho)+(Klink)),1])
            rho=sol[1:length(oldrho)]
            sigma_=sol[1+length(oldrho)]
            Xi_=sol[(2+length(oldrho)):length(sol)]
            diff=max(abs(c(rho- oldrho,Xi_-oldXi_,oldsigma-sigma_)))
            oldrho=rho
            oldXi_=Xi_
            oldsigma=sigma_
            print(paste("Xi:",oldXi_))
          }
        }
        if(!SF){
          if(Popfix){
            function_to_minimize <-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)
              mu_b=get('mu_b', envir=test.env)
              FS=get('FS', envir=test.env)
              NC=get('NC', envir=test.env)
              lr=get('lr', envir=test.env)
              rho_=param[1:lr]
              rho_=rho_*sum(Boxr)
              rho_=rho_-(Boxr[1])
              rho_=10^(rho_)
              Rho=get('Rho', envir=test.env)
              rho_=rho_*Rho
              beta=get('beta', envir=test.env)
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              BW=get('BW', envir=test.env)
              if(BW){
                Big_M=get('Big_M', envir=test.env)
                q_=get('q_', envir=test.env)
              }
              Beta=get('Beta', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)

              LH=0
              Self=get('Self', envir=test.env)
              sigma=get('sigma', envir=test.env)

              for( chr in 1:NC){
                builder=build_HMM_matrix(n,(rho_[chr]),beta,Pop = Pop,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
                Q=builder[[1]]
                Q=t(Q)
                A=as.vector(Q)
                keep=which(A>0&as.vector(Big_Xi[[chr]])>0)
                A=A[keep]
                Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                Tc=builder[[3]]
                scale_T=get('scale_T', envir=test.env)
                Tc=Tc*scale_T
                if(!BW){
                  LH=LH-sum(log(A)*Big_Xi[[chr]])
                }
                if(BW){
                  g=matrix(0,nrow=length(Tc),ncol=2)
                  g[,2]=1-exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                  g[,1]=exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                  x=as.vector(g)
                                    keep=which(x>0&as.vector(as.vector(Big_M[[chr]]))>0)
                  x=x[keep]
                  m=as.vector(Big_M[[chr]])
                  m=m[keep]
                  nu=builder[[2]]
                  LH=-sum(log(A)*Big_Xi[[chr]])-sum(log(x)*m)-sum(log(nu)*q_[[chr]])
                }


              }
              return(LH)
            }
            sol= BB::BBoptim(c(oldrho),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:(length(oldrho)),1])
            rho=sol[1:length(oldrho)]
            diff=max(abs(c(rho- oldrho)))
            oldrho=rho
          }
          if(!Popfix){
            function_to_minimize_optim<-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)
              mu_b=get('mu_b', envir=test.env)
              FS=get('FS', envir=test.env)
              NC=get('NC', envir=test.env)
              lr=get('lr', envir=test.env)
              rho_=param[1:lr]
              rho_=rho_*sum(Boxr)
              rho_=rho_-(Boxr[1])
              rho_=10^(rho_)
              Rho=get('Rho', envir=test.env)
              rho_=rho_*Rho
              beta=get('beta', envir=test.env)
              BoxP=get('BoxP', envir=test.env)
              Xi_=param[(1+lr):length(param)]
              Xi=vector()
              pop_vect=get('pop_vect', envir=test.env)
              xx=0
              for(ix in 1:length(Xi_)){
                x=xx+1
                xx = xx + pop_vect[ix]
                Xi[x:xx]=Xi_[ix]
              }
              Xi=Xi*sum(BoxP)
              Xi=Xi-(BoxP[1])
              Xi=10^Xi
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              BW=get('BW', envir=test.env)
              if(BW){
                Big_M=get('Big_M', envir=test.env)
                q_=get('q_', envir=test.env)
              }
              Beta=get('Beta', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)

              LH=0
              Self=get('Self', envir=test.env)
              sigma=get('sigma', envir=test.env)

              for( chr in 1:NC){
                builder=build_HMM_matrix(n,(rho_[chr]),beta,Pop = Pop,Xi=Xi,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
                Q=builder[[1]]
                Q=t(Q)
                A=as.vector(Q)
                keep=which(A>0&as.vector(Big_Xi[[chr]])>0)
                A=A[keep]
                Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                Tc=builder[[3]]
                scale_T=get('scale_T', envir=test.env)
                Tc=Tc*scale_T
                if(!BW){
                  LH=LH-sum(log(A)*Big_Xi[[chr]])
                }
                if(BW){
                  g=matrix(0,nrow=length(Tc),ncol=2)
                  g[,2]=1-exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                  g[,1]=exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                  x=as.vector(g)
                                    keep=which(x>0&as.vector(as.vector(Big_M[[chr]]))>0)
                  x=x[keep]
                  m=as.vector(Big_M[[chr]])
                  m=m[keep]
                  nu=builder[[2]]
                  LH=-sum(log(A)*Big_Xi[[chr]])-sum(log(x)*m)-sum(log(nu)*q_[[chr]])
                }


              }
              return(LH)
            }
            sol= BB::BBoptim(c(oldrho,oldXi_),function_to_minimize_optim,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:(length(oldrho)+(Klink)),1])
            rho=sol[1:length(oldrho)]
            Xi_=sol[(1+length(oldrho)):length(sol)]
            diff=max(abs(c(rho- oldrho,Xi_-oldXi_)))
            oldrho=rho
            oldXi_=Xi_
            print(paste("Xi:",oldXi_))
          }
        }
      }
    }
    if(!ER){
      if(SB){
        if(SF){
          if(Popfix){
            function_to_minimize <-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)
              mu_b=get('mu_b', envir=test.env)
              FS=get('FS', envir=test.env)
              Rho=get('Rho', envir=test.env)
              NC=get('NC', envir=test.env)
              rho_=Rho
              BoxB=get('BoxB', envir=test.env)
              beta=((param[1]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              BW=get('BW', envir=test.env)
              if(BW){
                Big_M=get('Big_M', envir=test.env)
                q_=get('q_', envir=test.env)
              }
              Beta=get('Beta', envir=test.env)
              Boxs=get('Boxs', envir=test.env)
              Self=get('Self', envir=test.env)
              sigma=param[2]
              sigma=sigma*(Boxs[2]-Boxs[1])
              sigma=sigma+Boxs[1]

              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)

              LH=0
              for(chr in 1:NC){
                builder=build_HMM_matrix(n,(rho_[chr]),beta,Pop = Pop,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
                Q=builder[[1]]
                Q=t(Q)
                A=as.vector(Q)
                keep=which(A>0&as.vector(Big_Xi[[chr]])>0)
                A=A[keep]
                Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                Tc=builder[[3]]
                scale_T=get('scale_T', envir=test.env)
                Tc=Tc*scale_T
                if(!BW){
                  LH=LH-sum(log(A)*Big_Xi[[chr]])
                }
                if(BW){
                  g=matrix(0,nrow=length(Tc),ncol=2)
                  g[,2]=1-exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                  g[,1]=exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                  x=as.vector(g)
                                    keep=which(x>0&as.vector(as.vector(Big_M[[chr]]))>0)
                  x=x[keep]
                  m=as.vector(Big_M[[chr]])
                  m=m[keep]
                  nu=builder[[2]]
                  LH=-sum(log(A)*Big_Xi[[chr]])-sum(log(x)*m)-sum(log(nu)*q_[[chr]])
                }


              }
              return(LH)
            }
            sol= BB::BBoptim(c(oldbeta,oldsigma),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:2,1])
            beta_=sol[1]
            sigma_=sol[2]
            diff=max(abs(c(oldbeta- beta,oldsigma-sigma)))
            oldbeta=sol[1]
            oldsigma=sol[2]
          }
          if(!Popfix){
            function_to_minimize_optim<-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)
              mu_b=get('mu_b', envir=test.env)
              FS=get('FS', envir=test.env)
              Rho=get('Rho', envir=test.env)
              NC=get('NC',envir = test.env)
              rho_=Rho
              BoxB=get('BoxB', envir=test.env)
              Boxs=get('Boxs', envir=test.env)
              beta=((param[1]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
              BoxP=get('BoxP', envir=test.env)
              sigma=param[2]
              sigma=sigma*(Boxs[2]-Boxs[1])
              sigma=sigma+Boxs[1]

              Xi_=param[3:length(param)]
              Xi=vector()
              pop_vect=get('pop_vect', envir=test.env)
              xx=0
              for(ix in 1:length(Xi_)){
                x=xx+1
                xx = xx + pop_vect[ix]
                Xi[x:xx]=Xi_[ix]
              }
              Xi=Xi*sum(BoxP)
              Xi=Xi-(BoxP[1])
              Xi=10^Xi
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              Beta=get('Beta', envir=test.env)
              Self=get('Self', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)
              BW=get('BW', envir=test.env)
              if(BW){
                Big_M=get('Big_M', envir=test.env)
                q_=get('q_', envir=test.env)
              }

              Pop=get('Pop', envir=test.env)
              LH=0


              for(chr in 1:NC){
                builder=build_HMM_matrix(n,(rho_[chr]),beta,Pop = Pop,Xi=Xi,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
                Q=builder[[1]]
                Q=t(Q)
                A=as.vector(Q)
                keep=which(A>0&as.vector(Big_Xi[[chr]])>0)
                A=A[keep]
                Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                Tc=builder[[3]]
                scale_T=get('scale_T', envir=test.env)
                Tc=Tc*scale_T
                if(!BW){
                  LH=LH-sum(log(A)*Big_Xi[[chr]])
                }
                if(BW){
                  g=matrix(0,nrow=length(Tc),ncol=2)
                  g[,2]=1-exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                  g[,1]=exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                  x=as.vector(g)
                                    keep=which(x>0&as.vector(as.vector(Big_M[[chr]]))>0)
                  x=x[keep]
                  m=as.vector(Big_M[[chr]])
                  m=m[keep]
                  nu=builder[[2]]
                  LH=-sum(log(A)*Big_Xi[[chr]])-sum(log(x)*m)-sum(log(nu)*q_[[chr]])
                }


              }
              return(LH)
            }
            sol= BB::BBoptim(c(oldbeta,oldsigma,oldXi_),function_to_minimize_optim,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:(2+(Klink)),1])
            beta_=sol[1]
            sigma_=sol[2]
            Xi_=sol[3:length(sol)]
            diff=max(abs(c(oldbeta-beta_,oldsigma-sigma_,Xi_-oldXi_)))
            oldbeta=beta_
            oldXi_=Xi_
            oldsigma=sigma_
            print(paste("Xi:",oldXi_))
          }
        }
        if(!SF){
          if(Popfix){
            function_to_minimize <-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)
              mu_b=get('mu_b', envir=test.env)
              FS=get('FS', envir=test.env)
              NC=get('NC',envir = test.env)
              Rho=get('Rho', envir=test.env)
              rho_=Rho
              BoxB=get('BoxB', envir=test.env)
              beta=((param[1]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              BW=get('BW', envir=test.env)
              if(BW){
                Big_M=get('Big_M', envir=test.env)
                q_=get('q_', envir=test.env)
              }
              Beta=get('Beta', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)
              LH=0
              Self=get('Self', envir=test.env)
              sigma=get('sigma', envir=test.env)

              for(chr in 1:NC){
                builder=build_HMM_matrix(n,(rho_[chr]),beta,Pop = Pop,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
                Q=builder[[1]]
                Q=t(Q)
                A=as.vector(Q)
                keep=which(A>0&as.vector(Big_Xi[[chr]])>0)
                A=A[keep]
                Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                Tc=builder[[3]]
                scale_T=get('scale_T', envir=test.env)
                Tc=Tc*scale_T
                if(!BW){
                  LH=LH-sum(log(A)*Big_Xi[[chr]])
                }
                if(BW){
                  g=matrix(0,nrow=length(Tc),ncol=2)
                  g[,2]=1-exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                  g[,1]=exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                  x=as.vector(g)
                                    keep=which(x>0&as.vector(as.vector(Big_M[[chr]]))>0)
                  x=x[keep]
                  m=as.vector(Big_M[[chr]])
                  m=m[keep]
                  nu=builder[[2]]
                  LH=-sum(log(A)*Big_Xi[[chr]])-sum(log(x)*m)-sum(log(nu)*q_[[chr]])
                }


              }
              return(LH)
            }
            sol= BB::BBoptim(c(oldbeta),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1,1])
            beta_=sol[1]
            diff=max(abs(c(oldbeta-beta_)))
            oldbeta=beta_
          }
          if(!Popfix){
            function_to_minimize_optim<-function(param){

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)
              mu_b=get('mu_b', envir=test.env)
              FS=get('FS', envir=test.env)
              Rho=get('Rho', envir=test.env)
              NC=get('NC',envir = test.env)
              rho_=Rho
              BoxB=get('BoxB', envir=test.env)
              beta=((param[1]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
              BoxP=get('BoxP', envir=test.env)
              Xi_=param[2:length(param)]
              Xi=vector()
              pop_vect=get('pop_vect', envir=test.env)
              xx=0
              for(ix in 1:length(Xi_)){
                x=xx+1
                xx = xx + pop_vect[ix]
                Xi[x:xx]=Xi_[ix]
              }
              Xi=Xi*sum(BoxP)
              Xi=Xi-(BoxP[1])
              Xi=10^Xi
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              Beta=get('Beta', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)
              BW=get('BW', envir=test.env)
              if(BW){
                Big_M=get('Big_M', envir=test.env)
                q_=get('q_', envir=test.env)
              }

              Pop=get('Pop', envir=test.env)
              LH=0

              Self=get('Self', envir=test.env)
              sigma=get('sigma', envir=test.env)

              for(chr in 1:NC){
                builder=build_HMM_matrix(n,(rho_[chr]),beta,Pop = Pop,Xi=Xi,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
                Q=builder[[1]]
                Q=t(Q)
                A=as.vector(Q)
                keep=which(A>0&as.vector(Big_Xi[[chr]])>0)
                A=A[keep]
                Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                Tc=builder[[3]]
                scale_T=get('scale_T', envir=test.env)
                Tc=Tc*scale_T
                if(!BW){
                  LH=LH-sum(log(A)*Big_Xi[[chr]])
                }
                if(BW){
                  g=matrix(0,nrow=length(Tc),ncol=2)
                  g[,2]=1-exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                  g[,1]=exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                  x=as.vector(g)
                                    keep=which(x>0&as.vector(as.vector(Big_M[[chr]]))>0)
                  x=x[keep]
                  m=as.vector(Big_M[[chr]])
                  m=m[keep]
                  nu=builder[[2]]
                  LH=-sum(log(A)*Big_Xi[[chr]])-sum(log(x)*m)-sum(log(nu)*q_[[chr]])
                }

              }
              return(LH)
            }
            sol= BB::BBoptim(c(oldbeta,oldXi_),function_to_minimize_optim,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:(1+(Klink)),1])
            beta_=sol[1]
            Xi_=sol[2:length(sol)]
            diff=max(abs(c(oldbeta-beta_,Xi_-oldXi_)))
            oldbeta=beta_
            oldXi_=Xi_
            print(paste("Xi:",oldXi_))
          }
        }
      }
      if(!SB){
        if(SF){
          if(Popfix){
            function_to_minimize <-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)
              mu_b=get('mu_b', envir=test.env)
              FS=get('FS', envir=test.env)
              NC=get('NC',envir=test.env)
              Rho=get('Rho', envir=test.env)
              rho_=Rho
              beta=get('beta', envir=test.env)
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              BW=get('BW', envir=test.env)
              if(BW){
                Big_M=get('Big_M', envir=test.env)
                q_=get('q_', envir=test.env)
              }
              Beta=get('Beta', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)
              Boxs=get('Boxs', envir=test.env)
              Self=get('Self', envir=test.env)
              sigma=param[1]
              sigma=sigma*(Boxs[2]-Boxs[1])
              sigma=sigma+Boxs[1]

              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)
              LH=0

              for(chr in 1:NC){
                builder=build_HMM_matrix(n,(rho_[chr]),beta,Pop = Pop,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
                Q=builder[[1]]
                Q=t(Q)
                A=as.vector(Q)
                keep=which(A>0&as.vector(Big_Xi[[chr]])>0)
                A=A[keep]
                Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                Tc=builder[[3]]
                scale_T=get('scale_T', envir=test.env)
                Tc=Tc*scale_T
                if(!BW){
                  LH=LH-sum(log(A)*Big_Xi[[chr]])
                }
                if(BW){
                  g=matrix(0,nrow=length(Tc),ncol=2)
                  g[,2]=1-exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                  g[,1]=exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                  x=as.vector(g)
                                    keep=which(x>0&as.vector(as.vector(Big_M[[chr]]))>0)
                  x=x[keep]
                  m=as.vector(Big_M[[chr]])
                  m=m[keep]
                  nu=builder[[2]]
                  LH=-sum(log(A)*Big_Xi[[chr]])-sum(log(x)*m)-sum(log(nu)*q_[[chr]])
                }


              }
              return(LH)
            }
            sol= BB::BBoptim(c(oldsigma),function_to_minimize_optim,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1,1])
            sigma_=sol[1]
            diff=max(abs(c(oldsigma-sigma_)))
            oldsigma=sigma_
          }
          if(!Popfix){
            function_to_minimize_optim<-function(param){
              Boxr=get('Boxr', envir=test.env)
              Rho=get('Rho', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)
              mu_b=get('mu_b', envir=test.env)
              FS=get('FS', envir=test.env)
              NC=get('NC',envir = test.env)
              rho_=Rho
              beta=get('beta', envir=test.env)
              BoxP=get('BoxP', envir=test.env)
              Xi_=param[2:length(param)]
              Xi=vector()
              pop_vect=get('pop_vect', envir=test.env)
              xx=0
              for(ix in 1:length(Xi_)){
                x=xx+1
                xx = xx + pop_vect[ix]
                Xi[x:xx]=Xi_[ix]
              }
              Xi=Xi*sum(BoxP)
              Xi=Xi-(BoxP[1])
              Xi=10^Xi
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              BW=get('BW', envir=test.env)
              if(BW){
                Big_M=get('Big_M', envir=test.env)
                q_=get('q_', envir=test.env)
              }
              Beta=get('Beta', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)
              Boxs=get('Boxs', envir=test.env)
              Self=get('Self', envir=test.env)
              sigma=param[1]
              sigma=sigma*(Boxs[2]-Boxs[1])
              sigma=sigma+Boxs[1]

              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)
              LH=0


              for(chr in 1:NC){
                builder=build_HMM_matrix(n,(rho_[chr]),beta,Pop = Pop,Xi=Xi,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
                Q=builder[[1]]
                Q=t(Q)
                A=as.vector(Q)
                keep=which(A>0&as.vector(Big_Xi[[chr]])>0)
                A=A[keep]
                Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                Tc=builder[[3]]
                scale_T=get('scale_T', envir=test.env)
                Tc=Tc*scale_T
                if(!BW){
                  LH=LH-sum(log(A)*Big_Xi[[chr]])
                }
                if(BW){
                  g=matrix(0,nrow=length(Tc),ncol=2)
                  g[,2]=1-exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                  g[,1]=exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                  x=as.vector(g)
                                    keep=which(x>0&as.vector(as.vector(Big_M[[chr]]))>0)
                  x=x[keep]
                  m=as.vector(Big_M[[chr]])
                  m=m[keep]
                  nu=builder[[2]]
                  LH=-sum(log(A)*Big_Xi[[chr]])-sum(log(x)*m)-sum(log(nu)*q_[[chr]])
                }

              }
              return(LH)
            }
            sol= BB::BBoptim(c(oldsigma,oldXi_),function_to_minimize_optim,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:(1+(Klink)),1])
            sigma_=sol[1]
            Xi_=sol[2:length(sol)]
            diff=max(abs(c(Xi_-oldXi_,oldsigma-sigma_)))
            oldXi_=Xi_
            oldsigma=sigma_
            print(sigma_)
            print(paste("Xi:",oldXi_))
          }
        }
        if(!SF){
          if(!Popfix){
            function_to_minimize_optim<-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)
              mu_b=get('mu_b', envir=test.env)
              FS=get('FS', envir=test.env)
              Rho=get('Rho', envir=test.env)
              NC=get('NC',envir=test.env)
              rho_=Rho
              beta=get('beta', envir=test.env)
              BoxP=get('BoxP', envir=test.env)
              Xi_=param[1:length(param)]
              Xi=vector()
              pop_vect=get('pop_vect', envir=test.env)
              xx=0
              for(ix in 1:length(Xi_)){
                x=xx+1
                xx = xx + pop_vect[ix]
                Xi[x:xx]=Xi_[ix]
              }
              Xi=Xi*sum(BoxP)
              Xi=Xi-(BoxP[1])
              Xi=10^Xi
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              BW=get('BW', envir=test.env)
              if(BW){
                Big_M=get('Big_M', envir=test.env)
                q_=get('q_', envir=test.env)
              }
              Beta=get('Beta', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)
              LH=0

              Self=get('Self', envir=test.env)
              sigma=get('sigma', envir=test.env)

              for(chr in 1:NC){
                builder=build_HMM_matrix(n,(rho_[chr]),beta,Pop = Pop,Xi=Xi,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
                Q=builder[[1]]
                Q=t(Q)
                A=as.vector(Q)
                keep=which(A>0&as.vector(Big_Xi[[chr]])>0)
                A=A[keep]
                Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                Tc=builder[[3]]
                scale_T=get('scale_T', envir=test.env)
                Tc=Tc*scale_T
                if(!BW){
                  LH=LH-sum(log(A)*Big_Xi[[chr]])
                }
                if(BW){
                  g=matrix(0,nrow=length(Tc),ncol=2)
                  g[,2]=1-exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                  g[,1]=exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
                  x=as.vector(g)
                                    keep=which(x>0&as.vector(as.vector(Big_M[[chr]]))>0)
                  x=x[keep]
                  m=as.vector(Big_M[[chr]])
                  m=m[keep]
                  nu=builder[[2]]
                  LH=-sum(log(A)*Big_Xi[[chr]])-sum(log(x)*m)-sum(log(nu)*q_[[chr]])
                }


              }
              return(LH)
            }
            sol= BB::BBoptim(c(oldXi_),function_to_minimize_optim,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:((Klink)),1])
            Xi_=sol[1:length(sol)]
            diff=max(abs(Xi_-oldXi_))
            oldXi_=Xi_
            print(paste("Xi:",oldXi_))

          }
        }
      }
    }
  }

  if(SB){
    beta=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1] )^2
  }
  if(SF){
    sigma=oldsigma*(Boxs[2]-Boxs[1])
    sigma=sigma+Boxs[1]
  }
  rho_=oldrho*sum(Boxr)
  rho_=rho_-(Boxr[1])
  rho_=10^(rho_)
  rho_=rho_*Rho
  rho_=rho_/(2*L)
  if(Pop){
    xx=0
    for(ix in 1:Klink){
      x=xx+1
      xx = xx + pop_vect[ix]
      oldXi[x:xx]=oldXi_[ix]
    }
    Xi_=oldXi*sum(BoxP)
    Xi_=Xi_-(BoxP[1])
    Xi_=10^Xi_
  }
  res<-list()
  res$beta=beta
  res$sigma=sigma
  res$rho=rho_
  if(Pop){
    res$Xi=Xi_
  }else{
    res$Xi=rep(1,n)
  }
  Beta=get('Beta', envir=test.env)
  Self=get('Self', envir=test.env)
  res$scale_T=scale_T
  res$mu=mu
  res$Tc=Tc
  res$N=N
  res$Ne=Ne
  return(res)
}

