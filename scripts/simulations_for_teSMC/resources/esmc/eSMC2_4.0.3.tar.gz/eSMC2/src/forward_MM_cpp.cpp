#include <Rcpp.h>


using namespace Rcpp;
//' Forward Algorithm to compute likelihood
//'
//' @param xx : pointers of the integer vector of observation
//' @param E : Emission matrix
//' @param q : equilibrium probability
//' @param yy :  pointers of tge Numeric Matrix containing all pre calculated probabilities from zipped observation
//' @param TS_SNP :  Vector of observed SNPs
//' @param M_a :  number of simultaneously analyzed haploid genome
// [[Rcpp::export]]


Rcpp::List forward_MM_cpp(SEXP xx, Rcpp::NumericMatrix const& E, Rcpp::NumericVector const& q, SEXP yy, Rcpp::NumericVector const& TS_SNP, int const& M_a) {
  Rcpp::IntegerVector Os(xx);
  int T_prime = Os.size();
  Rcpp::NumericMatrix C(yy);
  int n = q.size();
  Rcpp::NumericMatrix alpha(n, T_prime);
  int NA_ob;
  int x;
  if( M_a == 3 ){
  int NA_ob = 4;
  }
  if( M_a == 4 ){
    int NA_ob = 8;
  }
  Rcpp::List out(3);
  int count_SNP = 0;
  double LH  = 0.0 ;
  double dn  = 0.0;
  Rcpp::NumericVector d(T_prime);
  int i=0;
  for(int l = 0; l < n; l++){
    if(Os(i)<0 ){
      x=((-Os(i))*n)+l;
      alpha(l,i) = E(x,(-Os(i)))*q(l);
    } else {
      if( Os(i) == NA_ob ){
        alpha(l,i) = (E(1,Os(i)))*q(l);
      }else{
        x=((TS_SNP(count_SNP))*n)+l;
        alpha(l,i) = E(x,Os(i))*q(l);
      }
    }
    dn+=alpha(l,i);
  }
  if( Os(i) > 0 && Os(i)< NA_ob){
    count_SNP++;
  }

  d(i)=log(dn);
  LH+=log(dn);
  for(int l = 0; l < n; l++){
    alpha(l,i)=(alpha(l,i)/dn);
  }
  for(int i = 1; i < T_prime; i++){
    dn=0.0;
    if( Os(i) > 0 && Os(i)< NA_ob ){
      count_SNP++;
    }
    for(int l = 0; l < n; l++){
      for(int k = 0; k < n ; k++){

        if( Os(i) < 0 ){
        x=((-Os(i))*n)+l;
        alpha(l,i) +=((C(x,k))*alpha(k,(i-1)));
        }else{
          if( Os(i) == NA_ob ){
            alpha(l,i) = (E(1,Os(i)))*q(l);
          }else{
            x=((TS_SNP(count_SNP))*n)+l;
            alpha(l,i) = E(x,Os(i))*q(l);
          }
        }
      }
      dn+=alpha(l,i);
    }
    d(i)=log(dn);
    LH+=log(dn);
    for(int l = 0; l < n; l++){
      alpha(l,i)=(alpha(l,i)/dn);
    }
    if( Os(i) > 0 && Os(i)< NA_ob){
      count_SNP++;
    }
  }
  out(0)=alpha;
  out(1)=d;
  out(2)=LH;

  return out ;
}
