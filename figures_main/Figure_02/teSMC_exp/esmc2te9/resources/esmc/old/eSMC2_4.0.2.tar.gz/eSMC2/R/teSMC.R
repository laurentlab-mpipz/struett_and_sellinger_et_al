#' Runs the time ecological Sequentially Markovian Coalescent

#' @param n : Number of hidden states
#' @param rho : prior ratio of recombination over mutation
#' @param O : Segregating site matrix (or list of segregating site matrix to use more than one chromosome/scaffold)
#' @param model : character vector describing the models tested, selected and used to estimation variation of rates in time, "Constant" to assume constant rate in time, "Given Transition" to estimate transition time assuming the inputted current and ancestral rates, "One transition" to estimate current, ancestral and transition time given priors, "Free" to freely estimate variation of rate with no prior model.
#' @param maxit : maximum number of iteration for the baum_welch algorithm
#' @param BoxP : logarithmic boundaries in base 10 for the  demography e.g. c(3,3) means the  population size can grow up to a thousand time  and decrease up to a thousand time
#' @param Boxr : list of the vector model size. Each element of list sets the logarithmic boundaries in base 10 for the recombination rate e.g. c(1,1) means the recombination rate can be up to ten times smaller or bigger than the initial given value. For model "Given Transition", element must be vector of size 2 indicating the current ratio of recombination rate over mutation rate followed by the ancestral one ,e.g. c(0.5,1) for a current r/mu=0.5 with ancestral state being r/mu=1. For model "One Transition", element must be a list of size two, with the first element indication the current boundaries and the second element the ancestral boundaries of the recombination rate.
#' @param Boxs : list of the vector model size. Each element of list sets the boundaries for the self-fertilization rate e.g. c(0.5,0.9) means the selfing rate is between 0.5 and 0.9.  For model "Given Transition", element must be vector of size 2 indicating the current selfing rate and the ancestral one ,e.g. c(0.99,0) for a current selfing rate of 99\% gwith ancestral state being outcrossing. For model "One Transition", element must be a list of size two, with the first element indication the current selfing rate boundaries and the second element the ancestral boundaries of the selfing rates.
#' @param BoxB : list of the vector model size. Each element of list sets boundaries of the germination rates for each model (first value must be  bigger than 0). For model "Given Transition", element must be vector of size 2 indicating the current dormancy rate and the ancestral one ,e.g. c(0.1,1) for a current seed bank of 10 generation with ancestral state being absence of dormancy. For model "One Transition", element must be a list of size two, with the first element indication the current germination rate boundaries and the second element the ancestral boundaries of the germination rates.
#' @param Constant_Pop : True if population size is assumed constant
#' @param estimate : character vector, "ER" to estimate recombination rate, "SF" to estimate self-fertilization rate and "SB" to estimate dormancy
#' @param BW : True to use the complete implementation of the Baum-Welch algorithm
#' @param NC : Number of chromosome or scaffold (must be equal of the size of the list is O is a list of Segregating site matrix)
#' @param pop_vect : vector of hidden state sharing their population size parameter. Sum must be equal to hidden state number
#' @param mu_b : ratio of muation rate in seed bank  over mutation rate during sexual event (per generation)
#' @param sigma : initial value for self-fertilization rate
#' @param beta : initial value for germination rate
#' @param Big_Window : TRUE to use MSMC2 time window (bigger), 2 for an extremely big time window, 3 for a window focusing the past and 4 for a time window focusing on recent time.
#' @param window_scaling : numerical vector of size 2. Time window is divided by first value, and second value is added to time window to shift it in past or present
#' @param extra_matrix : list of vector size 2 indicating the relative weight of the matrix compare to the likelihood and the window length. The list length correspond to the number of extra matrices added.
#' @param position_removed : list of length NC (one for each scaffold) of a list of vector of size 2 indicating begining and end positions to remove from the sequence.
#' @param LH_opt : To use the forward algorithm to maximize likelihood
#' @export
#' @return A list containing all estimations. List of results contain:LH the likelihood, Tc the expected coalescent time,L length of the sequence, rho the recombination rate,mu the mutation rate, beta the germination rate, sigma the self-fertilization rate, Xi the vector of change of population size (population size at time t is  Xi[t]*Ne/ploidy).
teSMC<-function(n=40,rho=1,O,model=c("Free"),maxit =20,BoxP=c(3,3),Boxr=list(c(1,1)),Boxs=list(c(0,0.99)),BoxB=list(c(0.05,1)),Constant_Pop=F,estimate="ER",BW=F,NC=1,mu_b=1,pop_vect=NA,sigma=0,beta=1,Big_Window=F,window_scaling=c(1,0),extra_matrix=NA,position_removed=NA,LH_opt=F){
  gamma=rho
  pop=Constant_Pop
  Os_zip=NA
  hs_list=NA

  if(is.na(pop_vect)){
    pop_vect=rep(2,(n*0.5))
  }
  if(NC==1){
    M=dim(O)[1]-2
    L=as.numeric(O[(M+2),dim(O)[2]])
    Os=list()
    count=0
    theta_W=0
    s=dim(O)[1]

    if(!is.na(extra_matrix)){
      X_star=list()
      for(nb_matrix in 1:length(extra_matrix)){
        X_star[[nb_matrix]]=list()
      }
    }else{
      X_star_f=NA
    }

    for(k in 1:(M-1)){
      for(l in (k+1):M){
        print("Creating seq")
        Os_=seqSNP2_MH(O[c(k,l,(s-1),s),],L,position_removed[[1]])
        if((Os_$theta)>=2){
          print((Os_$theta))
          theta_W=theta_W+((Os_$theta))
          print(count)

          if(count==0){
            if(length(Os_$seq)>10^6){
              print("Finding symbol")
              if(!LH_opt){
                Os_temporary=Build_zip_ID_2seq(Os_$seq[1:1000000])
              }else{
                Os_temporary=Build_zip_2seq(Os_$seq[1:1000000],25)
              }

              if(!LH_opt&!("Constant"%in%model)){
                Os_zip=list()
                Os_temporary_zip=Build_zip_2seq(Os_$seq[1:1000000],25)
                Mat_symbol_zip=Os_temporary_zip[[2]]
                #browser()
                rm(Os_temporary_zip)
              }

              Mat_symbol=Os_temporary[[2]]
              rm(Os_temporary)
              if((Os_$theta)>=2){
                count=count+1
                print("Ziping")
                n_it=floor(L/10^6)
                zipped_seq=c()
                print("Original Sequence length:")
                print(L)
                for(seq_id in 1:n_it){
                  x_id=1+((seq_id-1)*10^6)
                  y_id=((seq_id)*10^6)
                  obj_temp=Zip_seq(Os_$seq[x_id:y_id],Mat_symbol)
                  zipped_seq=c(zipped_seq,obj_temp[[1]])
                  Os[[count]]=obj_temp
                  rm(obj_temp)
                }
                seq_id=seq_id+1
                obj_temp=Zip_seq(Os_$seq[x_id:y_id],Mat_symbol)

                zipped_seq=c(zipped_seq,obj_temp[[1]])
                Os[[count]][[1]]=zipped_seq
                rm(obj_temp)

                print("Zipped Sequence length:")
                print(length(zipped_seq))
                rm(zipped_seq)
                if(!LH_opt&!("Constant"%in%model)){

                  n_it=floor(L/10^6)
                  zipped_seq=c()
                  for(seq_id in 1:n_it){
                    x_id=1+((seq_id-1)*10^6)
                    y_id=((seq_id)*10^6)
                    obj_temp=Zip_seq(Os_$seq[x_id:y_id],Mat_symbol_zip)
                    zipped_seq=c(zipped_seq,obj_temp[[1]])
                    Os_zip[[count]]=obj_temp
                    rm(obj_temp)
                  }
                  seq_id=seq_id+1
                  obj_temp=Zip_seq(Os_$seq[x_id:y_id],Mat_symbol_zip)

                  zipped_seq=c(zipped_seq,obj_temp[[1]])
                  Os_zip[[count]][[1]]=zipped_seq
                  rm(obj_temp)
                  rm(zipped_seq)
                }
                rm(Os_)
              }
            }else{
              print("Finding symbol")
              if(!LH_opt){
                temp=Build_zip_ID_2seq(Os_$seq)
              }else{
                temp=Build_zip_2seq(Os_$seq,25)
              }
              if(!LH_opt&!("Constant"%in%model)){
                Os_zip=list()
                temp_zip=Build_zip_2seq(Os_$seq,25)
                Mat_symbol_zip=temp_zip[[2]]
                rm(temp_zip)
              }
              Mat_symbol=temp[[2]]
              rm(temp)
              if((Os_$theta)>=2){
                count=count+1
                print("Ziping")
                Os[[count]]=Zip_seq(Os_$seq,Mat_symbol)
                if(!LH_opt&!("Constant"%in%model)){
                  Os_zip[[count]]=Zip_seq(Os_$seq,Mat_symbol_zip)
                }
                rm(Os_)
              }
            }

          }else{
            if(L<10^6){
              if((Os_$theta)>=2){
                count=count+1
                print("Ziping")
                Os[[count]]=Zip_seq(Os_$seq,Mat_symbol)
                if(!LH_opt&!("Constant"%in%model)){
                  Os_zip[[count]]=Zip_seq(Os_$seq,Mat_symbol_zip)
                }
                rm(Os_)
              }
            }else{
              if((Os_$theta)>=2){
                count=count+1
                print("Ziping")
                n_it=floor(L/10^6)
                zipped_seq=c()
                print("Original Sequence length:")
                print(L)
                for(seq_id in 1:n_it){
                  x_id=1+((seq_id-1)*10^6)
                  y_id=((seq_id)*10^6)
                  obj_temp=Zip_seq(Os_$seq[x_id:y_id],Mat_symbol)
                  zipped_seq=c(zipped_seq,obj_temp[[1]])
                  Os[[count]]=obj_temp
                  rm(obj_temp)
                }
                seq_id=seq_id+1
                obj_temp=Zip_seq(Os_$seq[x_id:y_id],Mat_symbol)
                zipped_seq=c(zipped_seq,obj_temp[[1]])
                Os[[count]][[1]]=zipped_seq
                rm(obj_temp)

                print("Zipped Sequence length:")
                print(length(zipped_seq))
                rm(zipped_seq)
                if(!LH_opt&!("Constant"%in%model)){

                  n_it=floor(L/10^6)
                  zipped_seq=c()

                  for(seq_id in 1:n_it){
                    x_id=1+((seq_id-1)*10^6)
                    y_id=((seq_id)*10^6)
                    obj_temp=Zip_seq(Os_$seq[x_id:y_id],Mat_symbol_zip)
                    zipped_seq=c(zipped_seq,obj_temp[[1]])
                    Os_zip[[count]]=obj_temp
                    rm(obj_temp)
                  }
                  seq_id=seq_id+1
                  obj_temp=Zip_seq(Os_$seq[x_id:y_id],Mat_symbol_zip)
                  zipped_seq=c(zipped_seq,obj_temp[[1]])
                  Os_zip[[count]][[1]]=zipped_seq
                  rm(obj_temp)
                  rm(zipped_seq)

                }

                rm(Os_)
              }
            }


          }
          print("Symbol to number")
          Os[[count]]=symbol2Num(Os[[count]][[1]],Os[[count]][[2]])
          if(!LH_opt&!("Constant"%in%model)){
            Os_zip[[count]]=symbol2Num(Os_zip[[count]][[1]],Os_zip[[count]][[2]])
          }


        }
      }
    }
    rm(O)


    if(length(Os)>=1){
      theta_W=theta_W/length(Os)
      LH=0
      for(mm in 1:length(model)){

        param=set_parameters(estimate,model[[mm]])
        ER=param[1]
        SF=param[2]
        SB=param[3]
        Boxr_t=Boxr[[mm]]
        Boxs_t=Boxs[[mm]]
        BoxB_t=BoxB[[mm]]
        if(SF!=3){
          sigma_p=max(Boxs_t[1],sigma)
          sigma_p=min(Boxs_t[2],sigma)
        }else{
          sigma_p=min(Boxs_t[[1]])
        }

        if(SB!=3){
          beta_p=min(BoxB_t[2],beta)
          beta_p=max(BoxB_t[1],beta)
        }else{
          beta_p=max(BoxB_t[[1]])
        }
        if(ER==2){
          rho_p=Boxr_t[1]
        }else{
          rho_p=gamma
        }



      theta=theta_W*(beta_p*beta_p)*2/((2-sigma_p)*(beta_p+((1-beta_p)*mu_b)))
      mu=theta/(2*L)

      rho=rho_p*theta

      if(!is.na(extra_matrix)){
        X_star_f=list()
        Tc=build_Tc(n,Beta=beta,scale=window_scaling,Sigma=sigma,Big_Window=Big_Window,npair= length(Os))
        for(nb_matrix in 1:length(extra_matrix)){

          Tc_SNP=extra_matrix[[nb_matrix]][2]*(1-exp(-2*mu*Tc))
          print(Tc_SNP)
          if(Tc_SNP[2]<1&Tc_SNP[3]<2){

              hs_list=list()
              not_good=T
              while(not_good){
                if(any(c(floor(Tc_SNP[1:(length(Tc_SNP)-1)])-floor(Tc_SNP[2:(length(Tc_SNP))]))==0)){
                  t_1=max(which(c(floor(Tc_SNP[1:(length(Tc_SNP)-1)])-floor(Tc_SNP[2:(length(Tc_SNP))]))==0))
                  nb_SNP=floor(Tc_SNP[t_1])
                  hs_vect=which(floor(Tc_SNP)==nb_SNP)
                  print(hs_vect)

                  hs_list[[(1+length(hs_list))]]=hs_vect
                  rm_v=sort(hs_vect)[-1]
                  Tc_SNP=Tc_SNP[-rm_v]
                }else{
                  not_good=F
                }
              }

          }
          print(Tc_SNP)
          X_star_f[[nb_matrix]]=matrix(0,length(Tc_SNP),length(Tc_SNP))
          for(oo in 1: length(Os)){
            X_star_f[[nb_matrix]]=X_star_f[[nb_matrix]]+build_X_star(X_star[[nb_matrix]][[oo]],Tc_SNP)
          }
        }
      }

      if(model=="Constant"){
        results_temp=Baum_Welch_algo(Os=Os, maxIt =maxit,L=L,mu=mu,theta_W =theta_W,Rho=rho,beta=beta_p,sigma=sigma_p,Popfix=pop,SB=SB,SF=SF,k=n,BoxB=BoxB_t,BoxP=BoxP,Boxr=Boxr_t,Boxs = Boxs_t,maxBit = 2,pop_vect=pop_vect,ER=ER,NC=NC,BW=BW,mu_b=mu_b,Big_Window=Big_Window,window_scaling=window_scaling)
      }else{

        results_temp=Baum_Welch_algo_t(Os=Os, maxIt =maxit,L=L,mu=mu,theta_W =theta_W,Rho=rho,beta=beta_p,sigma=sigma_p,Popfix=pop,SB=SB,SF=SF,k=n,BoxB=BoxB_t,BoxP=BoxP,Boxr=Boxr_t,Boxs = Boxs_t,maxBit = 1,pop_vect=pop_vect,ER=ER,NC=NC,BW=BW,mu_b=mu_b,Big_Window=Big_Window,window_scaling=window_scaling,matrix_param=extra_matrix,X_star= X_star_f,hs_vect=hs_list,LH_opt=LH_opt,Os_zip=Os_zip)
      }
        if(LH!=0){
        if(results_temp$LH>=results$LH){
          results=results_temp
          LH=results$LH
        }
      }
      if(LH==0){
        results=results_temp
        LH=results$LH
       }
     rm(results_temp)
      }

      }else{
      stop("data too poor")
    }

  }

  if(NC>1){
    X_star=NA
    if(length(O)!=NC){
      stop("Not good number of chromosome given")
    }
    Os=list()
    theta_W_V=vector(length=NC)
    L_total=vector()
    X_star_l=list()
    start_zip=T
    for(chr in 1:NC){

      if(!is.na(extra_matrix)){
        X_star=list()
        for(nb_matrix in 1:length(extra_matrix)){
          X_star[[nb_matrix]]=list()
        }
      }else{
        X_star_f=NA
      }

      theta_W=0
      count=0
      OST_=list()
      if(!LH_opt&!("Constant"%in%model)){
        OST_zip=list()
        }
      M=(dim(O[[chr]])[1]-2)
      L=as.numeric(O[[chr]][(M+2),dim(O[[chr]])[2]])
      L_total=c(L_total,L)
      for(k in 1:(M-1)){
        for(l in (k+1):M){
          s=dim(O[[chr]])[1]
          Os_=seqSNP2_MH(O[[chr]][c(k,l,(s-1),s),],L,position_removed[[1]])
          if(as.numeric(Os_$theta)>=2){
            count=count+1
            theta_W=theta_W+as.numeric(Os_$theta)
            if(count==1&start_zip){
              if(L<=10^6){

                if(!LH_opt){
                  OST_[[count]]=Build_zip_ID_2seq(Os_$seq)

                }else{
                  OST_[[count]]=Build_zip_2seq(Os_$seq,25)
                }

                if(!LH_opt&!("Constant"%in%model)){
                  Os_zip=list()

                  OST_zip[[count]]=Build_zip_2seq(Os_$seq,25)
                  Mat_symbol_zip=OST_zip[[count]][[2]]
                }

                Mat_symbol=OST_[[count]][[2]]



              }else{

                if(!LH_opt){
                  Os_temp=Build_zip_ID_2seq(Os_$seq[1:(10^6)])

                }else{
                  Os_temp=Build_zip_2seq(Os_$seq[1:(10^6)],25)
                }
                if(!LH_opt&!("Constant"%in%model)){
                  Os_temp_zip=Build_zip_2seq(Os_$seq[1:(10^6)],25)
                  Mat_symbol_zip=Os_temp_zip[[2]]
                }
                Mat_symbol=Os_temp[[2]]
                rm(Os_temp)
                OST_[[count]]=Zip_seq(Os_$seq,Mat_symbol)
                if(!LH_opt&!("Constant"%in%model)){
                  OST_zip[[count]]=Zip_seq(Os_$seq,Mat_symbol_zip)
                }
              }
              start_zip=F
            }
            if(count>1|chr>1){
              OST_[[count]]=Zip_seq(Os_$seq,Mat_symbol)
              if(!LH_opt&!("Constant"%in%model)){
                OST_zip[[count]]=Zip_seq(Os_$seq,Mat_symbol_zip)
              }
            }
            OST_[[count]]=symbol2Num(OST_[[count]][[1]],OST_[[count]][[2]])
            if(!LH_opt&!("Constant"%in%model)){
              OST_zip[[count]]=symbol2Num(OST_zip[[count]][[1]],OST_zip[[count]][[2]])
            }
          }
        }
      }
      X_star_l[[chr]]=X_star
      rm(Os_)
      Os[[chr]]=OST_
      if(!LH_opt&!("Constant"%in%model)){
        Os_zip[[chr]]=OST_zip
      }


      theta_W=theta_W/length(OST_)
      theta_W_V[chr]=theta_W
      rm(OST_)
    }
    rm(O)

    LH=0
    for(mm in 1:length(model)){

      param=set_parameters(estimate,model[[mm]])
      ER=param[1]
      SF=param[2]
      SB=param[3]
      Boxr_t=Boxr[[mm]]
      Boxs_t=Boxs[[mm]]
      BoxB_t=BoxB[[mm]]
      if(SF!=3){
        sigma_p=max(Boxs_t[1],sigma)
        sigma_p=min(Boxs_t[2],sigma)
      }else{
        sigma_p=min(Boxs_t[[1]])
      }

      if(SB!=3){
        beta_p=min(BoxB_t[2],beta)
        beta_p=max(BoxB_t[1],beta)
      }else{
        beta_p=max(BoxB_t[[1]])
      }
      if(ER==2){
        rho_p=Boxr_t[1]
      }else{
        rho_p=gamma
      }



      theta=theta_W_V*(beta_p*beta_p)*2/((2-sigma_p)*(beta_p+((1-beta_p)*mu_b)))


      mu=theta/(2*L_total)
      rho=rho_p*theta

      L=L_total

      theta_W=theta_W_V

      if(!is.na(extra_matrix)){
        X_star_f=list()
        for(chr in 1:NC){
          X_star_chr=list()
          Tc=build_Tc(n,Beta=beta,scale=window_scaling,Sigma=sigma,Big_Window=Big_Window,npair= length(Os))
          for(nb_matrix in 1:length(extra_matrix)){

            Tc_SNP=extra_matrix[[nb_matrix]][2]*(1-exp(-2*mu*Tc))
            print(Tc_SNP)
            if(Tc_SNP[2]<1&Tc_SNP[3]<2){

              hs_list=list()
              not_good=T
              while(not_good){
                if(any(c(floor(Tc_SNP[1:(length(Tc_SNP)-1)])-floor(Tc_SNP[2:(length(Tc_SNP))]))==0)){
                  t_1=max(which(c(floor(Tc_SNP[1:(length(Tc_SNP)-1)])-floor(Tc_SNP[2:(length(Tc_SNP))]))==0))
                  nb_SNP=floor(Tc_SNP[t_1])
                  hs_vect=which(floor(Tc_SNP)==nb_SNP)
                  print(hs_vect)

                  hs_list[[(1+length(hs_list))]]=hs_vect
                  rm_v=sort(hs_vect)[-1]
                  Tc_SNP=Tc_SNP[-rm_v]
                }else{
                  not_good=F
                }
              }

            }

            X_star_chr[[nb_matrix]]=matrix(0,length(Tc_SNP),length(Tc_SNP))
            for(oo in 1: length()){
              X_star_chr[[nb_matrix]]=X_star_chr[[nb_matrix]]+build_X_star(X_star_l[[chr]][[nb_matrix]][[oo]],Tc_SNP)
            }
          }
          X_star_f[[chr]]=X_star_chr

        }
        rm(X_star_l)
      }


      if(model=="Constant"){
         results_temp=Baum_Welch_algo(Os=Os, maxIt =maxit,L=L,mu=mu,theta_W =theta_W,Rho=rho,beta=beta_p,sigma=sigma_p,Popfix=pop,SB=SB,SF=SF,k=n,BoxB=BoxB_t,BoxP=BoxP,Boxr=Boxr_t,Boxs = Boxs_t,maxBit = 1,pop_vect=pop_vect,ER=ER,NC=NC,BW=BW,mu_b=mu_b,Big_Window=Big_Window,window_scaling=window_scaling,Share_r=T)
      }else{
        results_temp=Baum_Welch_algo_t(Os=Os, maxIt =maxit,L=L,mu=mu,theta_W =theta_W,Rho=rho,beta=beta_p,sigma=sigma_p,Popfix=pop,SB=SB,SF=SF,k=n,BoxB=BoxB_t,BoxP=BoxP,Boxr=Boxr_t,Boxs = Boxs_t,maxBit = 1,pop_vect=pop_vect,ER=ER,NC=NC,BW=BW,mu_b=mu_b,Big_Window=Big_Window,window_scaling=window_scaling,matrix_param=extra_matrix,X_star= X_star_f,hs_vect=hs_list,LH_opt=LH_opt,Os_zip=Os_zip)
      }
      if(LH!=0){
        if(results_temp$LH>=results$LH){
          results=results_temp
          LH=results$LH
        }
      }
      if(LH==0){
        results=results_temp
        LH=results$LH
      }
      rm(results_temp)
    }




  }

  return(results)
}
