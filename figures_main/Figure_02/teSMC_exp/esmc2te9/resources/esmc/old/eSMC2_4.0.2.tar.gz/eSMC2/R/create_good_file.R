#' Creates a file from a multihetsep file
#'
#' @param path : location of the file
#' @param M : number of  haplotypes
#' @param filename : name of the file
#' @param delim : delimitation in the multihetsep file
#' @return A file similar to ms output
create_good_file<-function(path,M,filename,delim=" "){
  old_wd=getwd()
  if(!is.na(path)){
    setwd(path)
  }
  DNAseqfile=readr::read_delim(filename,delim,col_names = F)
  DNAseqfile=as.matrix(DNAseqfile)

  if(length(unique(DNAseqfile[,1]))==1){
    L=as.numeric(DNAseqfile[dim(DNAseqfile)[1],2])
    DNAseqfile=DNAseqfile[,-1]
    output=matrix(NA,ncol=dim(DNAseqfile)[1],nrow=(2+M))
    for(i in 1:dim(DNAseqfile)[1]){
      output[c(1:M),i]=as.vector(unlist(strsplit(DNAseqfile[i,3],"")))[1:M]
      output[(M+1),i]=as.numeric(DNAseqfile[i,2])
      output[(M+2),i]=as.numeric(DNAseqfile[i,1])
    }

  }else{
    output=list()
    L=vector()
    count_chr=0
    for(chr in sort(unique(DNAseqfile[,1])) ){
      count_chr=count_chr+1
      data=DNAseqfile[which(as.character(DNAseqfile[,1])==as.character(chr)),c(2,3,4)]
      output_chr=matrix(NA,ncol=dim(data)[1],nrow=(2+M))
      L_chr=as.numeric(data[dim(data)[1],2])
      for(i in 1:dim(data)[1]){
        output_chr[c(1:M),i]=as.vector(unlist(strsplit(data[i,3],"")))[1:M]
        output_chr[(M+1),i]=as.numeric(data[i,2])
        output_chr[(M+2),i]=as.numeric(data[i,1])
      }
      output[[count_chr]]=output_chr
      L[chr]=L_chr
    }
  }
  res=list()
  res$L=L
  res$output=output
  setwd(old_wd)
  return(res)
}
