#' Runs the ecological Sequentially Markovian Coalescent 2 accounting for methylation
#'
#' @param n : Number of hidden states
#' @param rho : numeric vector of prior ratio of recombination over mutation
#' @param O : Segregating site matrix (or list of segregating site matrix to use more than one chromosome/scaffold)
#' @param methylation : vector of size two, respectively containing the absolute values of methylation and demethylation in log10 (i.e. c(abs(log10(methylation_rate))),abs(log10(demethylation_rate))))
#' @param BoxM : vector of size two which are bounderies of methylation rates. First value gives the -log10 of lower bondery and second value the log10 of upper bondery.
#' @param BoxU : vector of size two which are bounderies of demethylation rates.  First value gives the -log10 of lower bondery and second value the log10 of upper bondery.
#' @param mu_r : numeric value corresponding to real mutation rate (for scaling purposes)
#' @param maxit : maximum number of iteration for the baum_welch algorithm
#' @param BoxB : boundaries of the germination rate ( first value must be  bigger than 0)
#' @param BoxP : logarithmic boundaries in base 10 for the  demography e.g. c(3,3) means the  population size can grow up to a thousand time  and decrease up to a thousand time
#' @param Boxr : logarithmic boundaries in base 10 for the  recombination rate e.g. c(1,1) means the recombination rate can be up to ten times smaller or bigger than the initial given value
#' @param Boxs : boundaries for the self-fertilization rate e.g. c(0.5,0.9) means the selfing rate is between 0.5 and 0.9
#' @param pop : True if population size is assumed constant
#' @param SB : True to estimate germination rate
#' @param SF : True to estimate Self-fertilization rate
#' @param Rho : True to estimate recombination rate
#' @param BW : True to use the complete implementation of the Baum-Welch algorithm
#' @param NC : Number of chromosome or scaffold (must be equal of the size of the list is O is a list of Segregating site matrix)
#' @param pop_vect : vector of hidden state sharing their population size parameter. Sum must be equal to hidden state number
#' @param mu_b : ratio of muation rate in seed bank  over mutation rate during sexual event (per generation)
#' @param sigma : initial value for self-fertilization rate
#' @param beta : initial value for germination rate
#' @param Big_Window : TRUE to use MSMC2 time window (bigger), user can also put numerical value if a window has been defined in Build_HMM_matrix.R
#' @param Max_G : Maximum ammount of memory in Gb available for the analysis (minimum 1 Gb)
#' @param position_removed : list of length NC ( one for each scaffold) of a list of vector of size 2 indicating begining and end positions to remove from the sequence.
#' @param LH_opt : TRUE to maximize likelihood (not through the Baum-Welch)
#' @param Free : TRUE to estimate methylation rates from the data (i.e. ignoring what has been inputed)
#' @export
#' @return A list containing all estimations (first list contains estimation based on the data second on the pseudo-observed data). List of results contain:LH the likelihood, Tc the expected coalescent time,L length of the sequence, rho the recombination rate,mu the mutation rate, beta the germination rate, sigma the self-fertilization rate, Xi the vector of change of population size (population size at time t is  Xi[t]*Ne/ploidy).
SMCm<-function(n=40,rho=1,O,methylation=c(5,4),BoxM=c(1,1),BoxU=c(1,1),mu_r,maxit =20,BoxB=c(0.05,1),BoxP=c(3,3),Boxr=c(1,1),Boxs=c(0,0.99),pop=F,SB=F,SF=F,Rho=T,BW=F,NC=1,pop_vect=NA,mu_b=1,sigma=0,beta=1,Big_Window=F,Max_G=100,position_removed=NA,LH_opt=F,Free=F){
  nb_methylation_context=1
  Check=F
  FS=F
  EM=F
  SCALED=F
   if(Max_G<1){
    print("Max_G must be bigger than 1 ! If your computer has less then 1 Gb of memroy you should probably not use this methond on your machine. Hence it is set back to 1 and will try to run. Sorry :/")
    Max_G=1
  }

  parallel=1
  if(nb_methylation_context==1){
    mu_m=10^-methylation
    p=(mu_m[2]/(sum(mu_m)))
    print("Expected probability to be unmethylation")
    print(p)

  }else{
    mu_m=matrix(0,nb_methylation_context,2)
    p=c()
    for(context in 1:nb_methylation_context){
      mu_m=10^-methylation[context,]
      p=c(p,(mu_m[2]/(sum(mu_m))))
    }

    print(p)
  }


  gamma=rho
  sigma=max(Boxs[1],sigma)
  sigma=min(Boxs[2],sigma)
  beta=min(BoxB[2],beta)
  beta=max(BoxB[1],beta)

  if(SF|SB){
    BaWe=2
  }else{
    BaWe=1
  }
  if(is.na(pop_vect)){
    pop_vect=rep(2,(n*0.5))
  }

    if(NC==1){
      M=dim(O)[1]-2
      L=as.numeric(O[dim(O)[1],dim(O)[2]])
      Os=list()
      count=0
      M_o=0
      theta_W=0
      scale_meth=c()
      if(nb_methylation_context==2){
        scale_meth_2=c()
      }
       if(Free){
   p_estimated=c()
   ps=c()
   if(nb_methylation_context==2){
    p_estimated_2=c()
    ps2=c()
   }
 }
      s_t=Sys.time()
      for(k in 1:(M-1)){
        for(l in (k+1):M){
          Os_=seqMeth(O[c(k,l,(M+1),(M+2)),],L,position_removed[[1]],nb_meth=nb_methylation_context,Free=Free)
          theta_W=theta_W+as.numeric(Os_$theta)
          if(Free){
            p_estimated=c(p_estimated,Os_$ratio_D_over_M)
            ps=c(ps,Os_$theta_M)
          }
          scale_meth=c(scale_meth,(length(which(Os_$seq<2))/L))
          if(nb_methylation_context==2){
            scale_meth_2=c(scale_meth_2,(length(which(Os_$seq>5))/L))
            scale_meth[length(scale_meth)]=1-(scale_meth[length(scale_meth)]+scale_meth_2[length(scale_meth_2)])

            if(Free){
              p_estimated2=c(p_estimated,Os_$ratio_O_over_P)
              ps2=c(ps,Os_$theta_O)
            }

          }
          M_o=M_o+1
          if(count==0){
            if(length(Os_$seq)>10^6){
              if(!LH_opt){
                Os_temporary=Build_zip_ID_2seq_m(Os_$seq[1:1000000],nb_methylation_context)
                Mat_symbol=Os_temporary[[2]]
              }else{
                Os_temporary=Build_zip_2seq_m(Os_$seq[1:1000000],20)
                Mat_symbol=Os_temporary[[2]]

              }

              #Os_temporary=Build_zip_2seq_m(Os_temporary[[1]])
              #Super_Mat_symbol=Os_temporary[[2]]
              rm(Os_temporary)
              L10=length(Os_$seq)/10^6
              if(L10*parallel>=Max_G){
                for(xx in seq(1,floor(L10),max(1,floor(Max_G)))){
                  xx=1+((xx-1)*10^6)
                  if(length(which(Os_$seq[xx:(xx-1+(Max_G*10^6))]==1))>1&(xx-1+(Max_G*10^6))<=length(Os_$seq)){
                    yy=xx-1+(Max_G*10^6)
                    count=count+1
                   if(!LH_opt){
                     Os[[count]]=Zip_seq_m(Os_$seq[xx:yy],Mat_symbol,nb_methylation_context)
                   }else{
                     Os[[count]]=Zip_seq(Os_$seq[xx:yy],Mat_symbol)
                   }

                    #Os[[count]][[3]]=Mat_symbol
                    #Os[[count]][[4]]=length(Os_$seq[xx:yy])
                  }
                }
                if(((length(Os_$seq)-yy)/10^6)>=0.9){
                  xx=1+yy
                  yy=length(Os_$seq)
                  count=count+1
                  print(xx)
                  print(yy)
                  if(!LH_opt){
                    Os[[count]]=Zip_seq_m(Os_$seq[xx:yy],Mat_symbol,nb_methylation_context)
                  }else{
                    Os[[count]]=Zip_seq(Os_$seq[xx:yy],Mat_symbol)
                  }
                  #Os[[count]][[3]]=Mat_symbol
                  #Os[[count]][[4]]=length(Os_$seq[xx:yy])
                }
              }else{
                count=count+1
                if(!LH_opt){
                  Os[[count]]=Zip_seq_m(Os_$seq,Mat_symbol,nb_methylation_context)
                }else{
                  Os[[count]]=Zip_seq(Os_$seq,Mat_symbol)
                }
                #Os[[count]]=Zip_seq(Zip_seq_m(Os_$seq,Mat_symbol,nb_methylation_context)[[1]],Super_Mat_symbol)
                #Os[[count]][[3]]=Mat_symbol
                #Os[[count]][[4]]=length(Os_$seq)

              }
            }else{
              count=count+1
              if(!LH_opt){
                Os_temporary=Build_zip_ID_2seq_m(Os_$seq,nb_methylation_context)
                Mat_symbol=Os_temporary[[2]]
                Os[[count]]=Zip_seq_m(Os_$seq,Mat_symbol,nb_methylation_context)
                rm(Os_temporary)
              }else{
                Os[[count]]=Build_zip_2seq_m(Os_$seq,20)
                Mat_symbol=Os[[count]][[2]]
                Os[[count]]=Zip_seq(Os_$seq,Mat_symbol)
              }




              #Os[[count]][[3]]=Mat_symbol
              #Os[[count]][[4]]=length(Os_$seq)

            }
          }else{
            if(L10*parallel>=Max_G){
              for(xx in seq(1,floor(L10),max(1,floor(Max_G)))){
                xx=1+((xx-1)*10^6)
                if((xx-1+(Max_G*10^6))<=length(Os_$seq)){
                  yy=xx-1+(Max_G*10^6)
                  count=count+1

                  if(!LH_opt){
                    Os[[count]]=Zip_seq_m(Os_$seq[xx:yy],Mat_symbol,nb_methylation_context)
                  }else{
                    Os[[count]]=Zip_seq(Os_$seq[xx:yy],Mat_symbol)
                  }


                  #Os[[count]][[3]]=Mat_symbol
                  #Os[[count]][[4]]=length(Os_$seq[xx:yy])
                }
              }
              if(((length(Os_$seq)-yy)/10^6)>=1){
                count=count+1
                xx=1+yy
                yy=length(Os_$seq)

                if(!LH_opt){
                  Os[[count]]=Zip_seq_m(Os_$seq[xx:yy],Mat_symbol,nb_methylation_context)
                }else{
                  Os[[count]]=Zip_seq(Os_$seq[xx:yy],Mat_symbol)
                }

                #Os[[count]]=Zip_seq(Zip_seq_m(Os_$seq[xx:yy],Mat_symbol,nb_methylation_context)[[1]],Super_Mat_symbol)
                #Os[[count]][[3]]=Mat_symbol
                #Os[[count]][[4]]=length(Os_$seq[xx:yy])
              }
            }else{
              count=count+1
              if(!LH_opt){
                Os[[count]]=Zip_seq_m(Os_$seq,Mat_symbol,nb_methylation_context)
              }else{
                Os[[count]]=Zip_seq(Os_$seq,Mat_symbol)
              }

              #Os[[count]]=Zip_seq(Zip_seq_m(Os_$seq,Mat_symbol,nb_methylation_context)[[1]],Super_Mat_symbol)
              #Os[[count]][[3]]=Mat_symbol
              #Os[[count]][[4]]=length(Os_$seq)

            }
          }
        }
      }
      e_t=Sys.time()
      print("Time to Zip sequences")
      print(e_t-s_t)
      rm(O)
      rm(Os_)


      if(length(Os)>=1){
        for(oo in 1:length(Os)){
              Os[[oo]]=symbol2Num_m(Os[[oo]],nb_methylation_context)




        }
        theta_W=theta_W/M_o

        theta=theta_W*(beta*beta)*2/((2-sigma)*(beta+((1-beta)*mu_b)))
        Ne=(log((1+((log((1-(theta/(L*0.75))))/2))))/(log(1-(mu_r*4/3))))
        mu=(-(log((1-(theta/(L*0.75))))/2))
        scale_meth=mean(scale_meth)
        if(nb_methylation_context==2){
          scale_meth_2=mean(scale_meth_2)
        }
        if(Free){
          print("estimated equilibrium probability")
          p=mean(p_estimated)
          print(p)
          ps=mean(ps)
          mu_m=c(1,(p/(1-p)))*log(sqrt((1-(ps/(2*p*(1-p))))))*(1-p)/(-1)

          if(nb_methylation_context==2){
            print("estimated equilibrium probability in second methylation context")
            p=mean(p_estimated2)
            print(p)
            ps=mean(ps2)
            mu_m=rbind(mu_m,c(1,(p/(1-p)))*log(sqrt((1-(ps/(2*p*(1-p))))))*(1-p)/(-1))
          }
        }


        #print(scale_meth)
        rho=rho*theta

      }else{
        stop("data too poor")
      }

      if(Free){
        methylation=mu_m
      }else{
        methylation=mu_m*Ne
      }

    }

    if(NC>1){
      if(Free){
      mu_m=list()
      }
      if(length(O)!=NC){
        stop("Not good number of chromosome given")
      }
      Os=list()
      theta_W_V=vector(length=NC)
      L_total=vector()
      scale_meth_v=numeric(NC)
      if(nb_methylation_context==2){
        scale_meth_v_2=c()
      }

      for(chr in 1:NC){
        if(Free){
          p_estimated=c()
          ps=c()
          if(nb_methylation_context==2){
            p_estimated_2=c()
            ps2=c()
          }
        }
        M=dim(O[[chr]])[1]-2
        L=as.numeric(O[[chr]][dim(O[[chr]])[1],dim(O[[chr]])[2]])
        L_total=c(L_total,L)
        Ost=list()
        count=0
        M_o=0
        theta_W=0
        scale_meth=c()
        if(nb_methylation_context==2){
          scale_meth_2=c()
        }
        for(k in 1:(M-1)){
          for(l in (k+1):M){
            Os_=seqMeth(O[[chr]][c(k,l,(M+1),(M+2)),],L,position_removed[[1]],nb_meth=nb_methylation_context,Free=Free)
            theta_W=theta_W+as.numeric(Os_$theta)
            scale_meth=c(scale_meth,(length(which(Os_$seq<2))/L))
            if(Free){
              p_estimated=c(p_estimated,Os_$ratio_D_over_M)
              ps=c(ps,Os_$theta_M)
            }

            if(nb_methylation_context==2){
              scale_meth_2=c(scale_meth_2,(length(which(Os_$seq>5))/L))
              scale_meth[length(scale_meth)]=1-(scale_meth[length(scale_meth)]+scale_meth_2[length(scale_meth_2)])
              if(Free){
                p_estimated2=c(p_estimated,Os_$ratio_O_over_P)
                ps2=c(ps,Os_$theta_O)
              }
            }
            M_o=M_o+1
            if(count==0){
              if(length(Os_$seq)>10^6){

                if(!LH_opt){
                  Os_temporary=Build_zip_ID_2seq_m(Os_$seq[1:1000000],nb_methylation_context)
                  Mat_symbol=Os_temporary[[2]]
                }else{
                  Os_temporary=Build_zip_2seq_m(Os_$seq[1:1000000],20)
                  Mat_symbol=Os_temporary[[2]]
                }


                #Os_temporary=Build_zip_2seq_m(Os_temporary[[1]])
                #Super_Mat_symbol=Os_temporary[[2]]
                rm(Os_temporary)
                L10=length(Os_$seq)/10^6
                if(L10*parallel>=Max_G){
                  for(xx in seq(1,floor(L10),max(1,floor(Max_G/parallel)))){
                    xx=1+((xx-1)*10^6)

                    if(length(which(Os_$seq[xx:(xx-1+(Max_G*10^6))]==1))>1&(xx-1+(Max_G*10^6))<=length(Os_$seq)){
                      yy=xx-1+(Max_G*10^6)
                      count=count+1

                      if(!LH_opt){
                        Ost[[count]]=Zip_seq_m(Os_$seq[xx:yy],Mat_symbol,nb_methylation_context)
                      }else{
                        Ost[[count]]=Zip_seq(Os_$seq[xx:yy],Mat_symbol)
                      }


                      #Ost[[count]][[3]]=Mat_symbol
                      #Ost[[count]][[4]]=length(Os_$seq[xx:yy])
                    }
                  }
                  if(((length(Os_$seq)-yy)/10^6)>=1){
                    xx=1+yy
                    yy=length(Os_$seq)



                    count=count+1
                    if(!LH_opt){
                      Ost[[count]]=Zip_seq_m(Os_$seq[xx:yy],Mat_symbol,nb_methylation_context)
                    }else{
                      Ost[[count]]=Zip_seq(Os_$seq[xx:yy],Mat_symbol)
                    }

                    #Ost[[count]][[3]]=Mat_symbol
                    #Ost[[count]][[4]]=length(Os_$seq[xx:yy])
                  }
                }else{
                  count=count+1


                  if(!LH_opt){
                    Ost[[count]]=Zip_seq_m(Os_$seq,Mat_symbol,nb_methylation_context)
                  }else{
                    Ost[[count]]=Zip_seq(Os_$seq,Mat_symbol)
                  }

                  #Ost[[count]]=Zip_seq(Zip_seq_m(Os_$seq,Mat_symbol,nb_methylation_context)[[1]],Super_Mat_symbol)
                  #Ost[[count]][[3]]=Mat_symbol
                  #Ost[[count]][[4]]=length(Os_$seq)

                }
              }else{
                #Os_temporary=Build_zip_ID_2seq_m(Os_$seq,nb_methylation_context)
                #Mat_symbol=Os_temporary[[2]]
                count=count+1

                if(!LH_opt){
                  Ost[[count]]=Build_zip_ID_2seq_m(Os_$seq,nb_methylation_context)
                  Mat_symbol=Ost[[count]][[2]]
                }else{
                  Ost[[count]]=Build_zip_2seq_m(Os_$seq,20)
                  Mat_symbol=Ost[[count]]
                }
                #Super_Mat_symbol=Ost[[count]][[2]]
                #Ost[[count]][[3]]=Mat_symbol
                #Ost[[count]][[4]]=length(Os_$seq)
                rm(Os_temporary)
              }
            }else{
              if(L10*parallel>=Max_G){
                for(xx in seq(1,floor(L10),max(1,floor(Max_G/parallel)))){
                  xx=1+(Max_G*(xx-1)*10^6)
                  if((xx-1+(Max_G*10^6))<=length(Os_$seq)){
                    yy=xx-1+(Max_G*10^6)
                    count=count+1

                    if(!LH_opt){
                      Ost[[count]]=Zip_seq_m(Os_$seq[xx:yy],Mat_symbol,nb_methylation_context)
                    }else{
                      Ost[[count]]=Zip_seq(Os_$seq[xx:yy],Mat_symbol)
                    }


                    #Ost[[count]][[3]]=Mat_symbol
                    #Ost[[count]][[4]]=length(Os_$seq[xx:yy])
                  }
                }
                if(((length(Os_$seq)-yy)/10^6)>=1){
                  count=count+1
                  xx=1+yy
                  yy=length(Os_$seq)

                  if(!LH_opt){
                    Ost[[count]]=Zip_seq_m(Os_$seq[xx:yy],Mat_symbol,nb_methylation_context)
                  }else{
                    Ost[[count]]=Zip_seq(Os_$seq[xx:yy],Mat_symbol)
                  }
                  #Ost[[count]][[3]]=Mat_symbol
                  #Ost[[count]][[4]]=length(Os_$seq[xx:yy])
                }
              }else{
                count=count+1

                if(!LH_opt){
                  Ost[[count]]=Zip_seq_m(Os_$seq,Mat_symbol,nb_methylation_context)
                }else{
                  Ost[[count]]=Zip_seq(Os_$seq,Mat_symbol)
                }


                #Ost[[count]][[3]]=Mat_symbol
                #Ost[[count]][[4]]=length(Os_$seq)

              }
            }
          }
        }
        Os[[chr]]=Ost
        theta_W_V[chr]=theta_W/M_o
        scale_meth_v[chr]=mean(scale_meth)
        if(nb_methylation_context==2){
          scale_meth_v_2[chr]=mean(scale_meth_2)
        }
        if(Free){
          print("estimated equilibrium probability")
          p=mean(p_estimated)
          print(p)
          ps=mean(ps)
          mu_m[[chr]]=c(1,(p/(1-p)))*log(sqrt((1-(ps/(2*p*(1-p))))))*(1-p)/(-1)

          if(nb_methylation_context==2){
            print("estimated equilibrium probability in second methylation context")
            p=mean(p_estimated2)
            print(p)
            ps=mean(ps2)
            mu_m[[chr]]=rbind(mu_m[[chr]],c(1,(p/(1-p)))*log(sqrt((1-(ps/(2*p*(1-p))))))*(1-p)/(-1))
          }

        }
      }
      scale_meth=scale_meth_v
      if(nb_methylation_context==2){
        scale_meth_2=scale_meth_v_2
      }

      print(L_total)
      L=L_total
      rm(O)
      rm(Ost)
      rm(scale_meth_v)
      if(length(Os)>=1){
        for(oo in 1:length(Os)){
          for(cc in 1:length(Os[[oo]])){

              Os[[oo]][[cc]]=symbol2Num_m(Os[[oo]][[cc]],nb_methylation_context)


          }
        }


        theta=theta_W_V*(beta*beta)*2/((2-sigma)*(beta+((1-beta)*mu_b)))
        Ne=log((1+((log((1-(theta/(L_total*0.75))))/2))))/(log(1-(mu_r*4/3)))
        mu=-(log((1-(theta/(L*0.75))))/2)

        rho=rho*theta
        rm(Os_)
      }else{
        stop("data too poor")
      }
      theta_W=theta_W_V
      methylation=list()
      for(chr in 1:NC){
        if(Free){
          methylation[[chr]]=mu_m[[chr]]
        }else{
          methylation[[chr]]=mu_m*Ne[chr]
        }
      }


    }

  if(length(Os)>=1){
    print("Observed theta:")
    print(theta_W)
    print("Estimated effective population size:")
    print(Ne)
    print("Estimated theta:")
    print(theta)
    print("Estimated rho:")
    print(rho)

    if(nb_methylation_context==2){
      scale_meth=rbind(scale_meth,scale_meth_2)
      print(scale_meth)
    }
    if(BaWe==1){
      results=Baum_Welch_algo_m(Os=Os, maxIt =maxit,L=L,mu=mu,Ne=Ne,theta_W =theta_W,Rho=rho,beta=beta,sigma=sigma,Popfix=pop,SB=SB,SF=SF,k=n,BoxB=BoxB,BoxP=BoxP,Boxr=Boxr,Boxs = Boxs,maxBit = 1,pop_vect=pop_vect,ER=Rho,NC=NC,BW=BW,redo_R=T,mu_b=mu_b,SCALED=SCALED,Big_Window=Big_Window,methylation=methylation,BoxM=BoxM,BoxU=BoxU,scale_meth=scale_meth,nb_methylation_context=nb_methylation_context,LH_opt=LH_opt)
    }
    if(BaWe==2){
      results=Baum_Welch_algo_m(Os=Os, maxIt =maxit,L=L,mu=mu,Ne=Ne,theta_W=theta_W,Rho=theta,beta=beta,sigma=sigma,Popfix=pop,SB=F,SF=F,k=n,BoxB=BoxB,BoxP=BoxP,Boxr=c(1,1),Boxs = Boxs,maxBit = 1,pop_vect=pop_vect,ER=T,NC=NC,BW=BW,mu_b=mu_b,SCALED=SCALED,Big_Window=Big_Window,methylation=methylation,BoxM=BoxM,BoxU=BoxU,scale_meth=scale_meth,nb_methylation_context=nb_methylation_context,LH_opt=LH_opt)
      r=results$rho[1:NC]
      mu_=results$mu
      gamma_=r/mu_
      print(r)
      print(mu_)
      print(gamma_)

      effect=mean(gamma_/gamma)
      if(SF&!SB){
        sigma=1-effect
        sigma=max(Boxs[1],sigma)
        sigma=min(Boxs[2],sigma)
        if(sigma>=Boxs[1]&sigma<=Boxs[2]){
          Boxs[1]=sigma
        }
      }
      if(SB&!SF){
        beta=effect
        beta=min(BoxB[2],beta)
        beta=max(BoxB[1],beta)
        if(beta>=BoxB[1]&beta<=BoxB[2]){
          BoxB[2]=beta
        }
      }
      if(SF&SB){
        if(min(BoxB)>(1-max(Boxs))){
          sigma=(1-(effect/beta))
          sigma=max(Boxs[1],sigma)
          sigma=min(Boxs[2],sigma)
          beta=effect/(1-sigma)
          beta=max(BoxB[1],beta)
          beta=min(BoxB[2],beta)
        }
        if(min(BoxB)<=(1-max(Boxs))){
          sigma=(1-(effect/beta))
          sigma=max(Boxs[1],sigma)
          sigma=min(Boxs[2],sigma)
          beta=effect/(1-sigma)
          beta=max(BoxB[1],beta)
          beta=min(BoxB[2],beta)
        }
        if(gamma_!=(gamma*beta*(1-sigma))){
          print("Prior might disagree with results.")
        }
      }
      theta=theta_W*(beta*beta)*2/((2-sigma)*(beta+((1-beta)*mu_b)))
      mu=(-(log((1-(theta/(L*0.75))))/2))
      rho=gamma*theta
      results=Baum_Welch_algo_m(Os=Os, maxIt =maxit,L=L,mu=mu,Ne=Ne,theta_W =theta_W,Rho=rho,beta=beta,sigma=sigma,Popfix=pop,SB=SB,SF=SF,k=n,BoxB=BoxB,BoxP=BoxP,Boxr=Boxr,Boxs = Boxs,maxBit = 1,pop_vect=pop_vect,ER=Rho,NC=NC,BW=BW,mu_b=mu_b,SCALED=SCALED,Big_Window=Big_Window,methylation=methylation,BoxM=BoxM,BoxU=BoxU,scale_meth=scale_meth,nb_methylation_context=nb_methylation_context,LH_opt=LH_opt)
    }
  }
  return(results)
}
