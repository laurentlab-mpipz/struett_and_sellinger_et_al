#' Build requirements such as the transition matrix with variation of selfing and dormancy through time to define the hidden markov model
#'
#' @param n : number of  hidden states
#' @param rho : vector of recombination rates
#' @param beta : vector of  germination rates
#' @param L : sequence length
#' @param Pop : True if population size is assumed constant
#' @param Xi : vector of scaling value for population size
#' @param Beta : germination rate to build hidden states
#' @param scale : vector containing as first value a numeric value to rescale hidden states and as second a numeric value to shift the time windows of hidden states
#' @param sigma : vector of self-fertilization rates
#' @param Sigma : self-fertilization rate to build hidden states
#' @param Big_Window : TRUE to use MSMC2 time window (bigger), user can also put numerical value if a window has been defined in Build_HMM_matrix.R
#' @param npair : number of pairewise analysis
#' @param tmax : numerical value parametrizing the time window, the bigger it is, the further in time goes the time window
#' @param alpha_t : numerical value parametrizing the time window, the smaller it is, the more recent in time is defined the time window
#' @return List of size four containing respectively, transition matrix, equilibrium probabilities, expected coalescent time and hidden states
build_HMM_matrix_t<-function(n=40,rho,L,Pop=T,Xi=NA,scale=c(1,0),beta=1,sigma=0,Beta=1,Sigma=0,Big_Window=F,tmax=15,alpha_t=0.1,npair=2){

  if(as.numeric(Big_Window)==0){
    Vect=0:(n-1)
    Tc= scale[2] -(0.5*(2-Sigma)*log(1-(Vect/n))/((Beta^2)*scale[1]))
  }
  if(as.numeric(Big_Window)==1){
    Vect=1:(n-1)
    tmax=15
    alpha_t=0.1
    alpha_t=alpha_t/(npair)
    tmax=tmax*npair
    Tc= c(0,scale[2] + (0.5*(2-Sigma)*(alpha_t*exp((Vect/n)*log(1+(tmax/alpha_t))-1))/((Beta^2)*scale[1])))

  }
  if(as.numeric(Big_Window)==2){
    tmax=50
    Vect=1:(n-1)
    alpha_t=0.001
    Tc= c(0,scale[2] + (0.5*(2-Sigma)*(alpha_t*exp((Vect/n)*log(1+(tmax/alpha_t))-1))/((Beta^2)*scale[1])) )
  }
  if(as.numeric(Big_Window)==3){
    tmax=20
    Vect=1:(n-1)
    alpha_t=0.1
    Tc= c(0,scale[2] + (0.5*(2-Sigma)*(alpha_t*exp((Vect/n)*log(1+(tmax/alpha_t))-1))/((Beta^2)*scale[1])) )
  }

  if(as.numeric(Big_Window)==4){
    tmax=20
    alpha_t=0.005
    Vect=1:(n-1)
    Tc= c(0,scale[2] + (0.5*(2-Sigma)*(alpha_t*exp((Vect/n)*log(1+(tmax/alpha_t))-1))/((Beta^2)*scale[1])) )
  }

  t=vector()
  q=vector()
  p_gamma=vector()
  Pi_gamma=vector()
  pi=vector()
  if(length(beta)==1){
    beta=rep(beta,n)
  }
  if(length(sigma)==1){
    sigma=rep(sigma,n)
  }

  r=rho/(2*(L-1))
  if(length(r)==1){
    r=rep(r,n)
  }
  D=Tc[2:n]-Tc[1:(n-1)]
  if(Pop){
    Xi=rep(1,n)
  }
  Lambda=D*beta[1:(n-1)]*beta[1:(n-1)]*4/(Xi[1:(n-1)]*(2-sigma[1:(n-1)]))
  lambda=beta*beta*4/(Xi*(2-sigma))

  t[1:(n-1)]=(2/lambda[1:(n-1)])+ (Tc[1:(n-1)]-(Tc[2:n]*(exp(-Lambda[1:(n-1)]/2))))/(1-exp(-Lambda[1:(n-1)]/2))
  t[n]=(Xi[n]*(2-sigma[n])/(beta[n]*beta[n]*2)) +Tc[n]
  q[1]=(1-exp(-D[1]*2*beta[1]*beta[1]/(Xi[1]*(2-sigma[1]))))
  for(alpha in 2:(n-1)){q[alpha]=exp(-sum((2*beta[1:(alpha-1)]*beta[1:(alpha-1)]/(2-sigma[1:(alpha-1)]))*D[1:(alpha-1)]/Xi[1:(alpha-1)]))*(1-exp(-D[alpha]*2*beta[alpha]*beta[alpha]/(Xi[alpha]*(2-sigma[alpha]))))}
  q[n]=exp(-sum((2*beta[1:(n-1)]*beta[1:(n-1)]/(2-sigma[1:(n-1)]))*D[1:(n-1)]/Xi[1:(n-1)]))

  for(ii in 1:n){
    if(ii>1){
      p_gamma[ii]=(1-exp(-2*(sum(D[1:(ii-1)]*r[1:(ii-1)]*beta[1:(ii-1)]*2*(1-sigma[1:(ii-1)])/(2-sigma[1:(ii-1)]))+ ( (t[ii]-Tc[ii])*r[ii]*beta[ii]*2*(1-sigma[ii])/(2-sigma[ii]) ) )))
      Pi_gamma[ii]=(sum(D[1:(ii-1)]*r[1:(ii-1)]*beta[1:(ii-1)]*2*(1-sigma[1:(ii-1)])/(2-sigma[1:(ii-1)]))+( (t[ii]-Tc[ii])*r[ii]*beta[ii]*2*(1-sigma[ii])/(2-sigma[ii]) ))
    }
    if(ii==1){
      p_gamma[ii]=(1-exp(-2*(( (t[ii]-Tc[ii])*r[ii]*beta[ii]*2*(1-sigma[ii])/(2-sigma[ii]) ) )))
      Pi_gamma[ii]=( (t[ii]-Tc[ii])*r[ii]*beta[ii]*2*(1-sigma[ii])/(2-sigma[ii]) )
    }
    pi[ii]=r[ii]*beta[ii]*2*(1-sigma[ii])/(2-sigma[ii])

  }
  Q=matrix(0,ncol = n, nrow = n)



  for(i in 1:(n-1)){
    if(i==1){
      Q[1,(2:n)]=p_gamma[(2:n)]*(pi[1]/(2*Pi_gamma[(2:n)]))*( D[1]-((1-exp(-Lambda[1]))/(lambda[1])))
    }
    if(i==2){
      eta=1
      truc= (pi[eta]*(1-exp(-Lambda[eta]))/((lambda[eta])))
      truc=truc*(1-exp(-Lambda[i]))
      Q[i,((i+1):n)]=p_gamma[((i+1):n)]*(1/(2*Pi_gamma[((i+1):n)]))*( truc + pi[i]*(D[i]-((1-exp(-Lambda[i]))/(lambda[i]))))
      Q[i,1]=p_gamma[1]*(1/Pi_gamma[1])*exp((t[1]-Tc[2])*lambda[1]/2)*(1-exp(-Lambda[2]/2))*(( pi[1]*(1-exp(-t[1]*lambda[1]))/(lambda[1])))
    }
    if( i>2){
      truc=0
      for(eta in 1:(i-2)){
        truc= truc+ ((( exp(-sum(Lambda[(eta+1):(i-1)]))*pi[eta]*(1-exp(-Lambda[eta]))/((lambda[eta])))))
      }
      eta=i-1
      truc= truc+ (((pi[eta]*(1-exp(-Lambda[eta]))/((lambda[eta])))))
      truc=truc*(1-exp(-Lambda[i]))
      Q[i,((i+1):n)]=p_gamma[((i+1):n)]*(1/(2*Pi_gamma[((i+1):n)]))*( truc + (pi[i]*(D[i]-((1-exp(-Lambda[i]))/(lambda[i])))))
      truc=rep(0,length(1:(i-1)))
      exp_truc=rep(0,length(1:(i-1)))
      for(gamma in 1:(i-1)){
        if(gamma<(i-1)){
          exp_truc[gamma]=exp(-(sum(Lambda[(gamma+1):(i-1)]/2)+((Tc[gamma+1]-t[gamma])*lambda[gamma]/2)))
        }
        if(gamma==(i-1)){
          exp_truc[gamma]=exp(-(Tc[gamma+1]-t[gamma])*lambda[gamma]/2)
        }
        if(gamma>2){
          sub_truc=0
          for(eta in 1:(gamma-2)){
            sub_truc=sub_truc+((pi[eta]*(1-exp(-Lambda[eta]))/(lambda[eta]))*exp(-(sum(Lambda[(eta+1):(gamma-1)])+((t[gamma]-Tc[gamma])*lambda[gamma]))))
          }
          eta=gamma-1
          sub_truc=sub_truc+((pi[eta]*(1-exp(-Lambda[eta]))/(lambda[eta]))*exp(-(t[gamma]-Tc[gamma])*lambda[gamma]))
          truc[gamma]=sub_truc+( pi[gamma]*(1-exp((Tc[gamma]-t[gamma])*lambda[gamma]))/(lambda[gamma]))
        }




        if(gamma==2){
          sub_truc=0
          eta=1
          sub_truc=sub_truc+((pi[eta]*(1-exp(-Lambda[eta]))/(lambda[eta]))*exp(-(t[gamma]-Tc[gamma])*lambda[gamma]))
          truc[gamma]=sub_truc+( pi[gamma]*(1-exp((Tc[gamma]-t[gamma])*lambda[gamma]))/(lambda[gamma]))
        }
        if(gamma==1){
          truc[gamma]=(pi[gamma]*(1-exp((Tc[gamma]-t[gamma])*lambda[gamma]))/(lambda[gamma]))
        }
      }
      Q[i,1:(i-1)]=p_gamma[(1:(i-1))]*(1/Pi_gamma[(1:(i-1))])*(1-exp(-Lambda[i]/2))*exp_truc*truc
    }
  }
  truc=rep(0,length(1:(n-1)))
  exp_truc=rep(0,length(1:(n-1)))
  for(gamma in 1:(n-1)){
    if(gamma<(n-1)){
      exp_truc[gamma]=exp(-( sum(Lambda[(gamma+1):(n-1)]/2) + ((Tc[gamma+1]-t[gamma])*lambda[gamma]/2)))
    }
    if(gamma==(n-1)){
      exp_truc[gamma]=exp(-(Tc[gamma+1]-t[gamma])*lambda[gamma]/2 )
    }
    if(gamma>2){
      sub_truc=0
      for(eta in 1:(gamma-2)){
        sub_truc=sub_truc+((pi[eta]*(1-exp(-Lambda[eta]))/(lambda[eta]))*exp(-(sum(Lambda[(eta+1):(gamma-1)]) + (t[gamma]-Tc[gamma])*lambda[gamma])))
      }
      eta=gamma-1
      sub_truc=sub_truc+((pi[eta]*(1-exp(-Lambda[eta]))/(lambda[eta]))*exp(-(t[gamma]-Tc[gamma])*lambda[gamma]))
      truc[gamma]=sub_truc+(pi[gamma]*(1-exp((Tc[gamma]-t[gamma])*lambda[gamma]))/(lambda[gamma]))
    }
    if(gamma==2){
      sub_truc=0
      eta=1
      sub_truc=sub_truc+(( pi[eta]*(1-exp(-Lambda[eta]))/(lambda[eta]))*exp(-(t[gamma]-Tc[gamma])*lambda[gamma]))
      truc[gamma]=sub_truc+( pi[gamma]*(1-exp((Tc[gamma]-t[gamma])*lambda[gamma]))/(lambda[gamma]))
    }
    if(gamma==1){
      truc[gamma]=(pi[gamma]*(1-exp((Tc[gamma]-t[gamma])*lambda[gamma]))/(lambda[gamma]))
    }
  }
  Q[n,1:(n-1)]=p_gamma[(1:(n-1))]*(1/Pi_gamma[(1:(n-1))])*exp_truc*truc
  diag(Q)=rep(1,n)-apply(Q,2,sum)
  output=list()
  output[[1]]=Q
  output[[2]]=q
  output[[3]]=t
  output[[4]]=Tc
  return(output)
}
