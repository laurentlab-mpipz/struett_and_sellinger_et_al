#' Build the index of coalescing individuals which is necessary to build the exact transition matrix from sequence of genealogy
#'
#' @param genealogy : Matrix of sequence of genealogy (output of read_multiple_merger_msprime_data)
#' @param Tc : numerical vector containing the discretization of time
#' @return a matrix of 2 line,first one idicating the coalescent state and the second line the position
build_seq_id<-function(genealogy,Tc){
  M=dim(genealogy$Coal_time)[1]
  output=matrix(0,nrow = 2,ncol = dim(genealogy$Coal_time)[2])
  output[2,]=genealogy$Coal_time[M,]
  for(pos in 1:dim(genealogy$Coal_time)[2]){
    id=c(genealogy$id_split[(M-1),pos],genealogy$id_create[(M-1),pos])
    id=find_index(id,M=M)
    t_state=max(which(Tc<(genealogy$Coal_time[(M-1),pos])))
    for(m in 2:(M-1)){
      if(t_state==max(which(Tc<(genealogy$Coal_time[(M-m),pos])))){
        id=4
      }
    }
    output[1,pos]=max(which(Tc<(genealogy$Coal_time[(M-1),pos])))+((length(Tc)*(id-1)))
  }
  return(output)
}
