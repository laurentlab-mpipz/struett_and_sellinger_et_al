#' Runs the ecological Sequentially Markovian Coalescent 2 on sequence of genealogy
#'
#' @param file : path to the simulated data  ( .txt ), list of path if NC>1
#' @param gamma : ratio of recombination rate over mutation rate
#' @param theta : theta used for simulation (i.e theta=1000 if command line is scrm :  -t 1000 ) or theta waterson of the observed data (if analyzing real data) or mutation rate per generation per bp if simulator is msprime
#' @param L : length of simulated sequence
#' @param n : Number of hidden states
#' @param ER : True to estimate recombination rate
#' @param Pop : True  top estimate population size
#' @param SB : True to estimate germination rate
#' @param SF : True to estimate Self-fertilization rate
#' @param BoxB : boundaries of the germination rate ( first value must be  bigger than 0)
#' @param BoxP : logarithmic boundaries in base 10 for the  demography e.g. c(3,3) means the  population size can grow up to a thousand time  and decrease up to a thousand time
#' @param Boxr : logarithmic boundaries in base 10 for the  recombination rate e.g. c(1,1) means the recombination rate can be up to ten times smaller or bigger than the initial given value
#' @param Boxs : boundaries for the self-fertilization rate e.g. c(0.5,0.9) means the selfing rate is between 0.5 and 0.9.
#' @param pop_vect : vector of hidden state sharing their population size parameter. Sum must be equal to hidden state number
#' @param window_scaling : numerical vector of size 2. Time window is divided by first value, and second value is added to time window to shift it in past or present
#' @param sigma : initial value for self-fertilization rate
#' @param beta : initial value for germination rate
#' @param Big_Window : TRUE to use MSMC2 time window (bigger)
#' @param NC : Number of scaffold to be analyzed
#' @param mu_b : ratio of muration rate in the dormant stage and during reproductive event
#' @param simulator : "msprime" or "scrm" or NA if N is given
#' @param M : sample size of data
#' @export
#' @return A list containing all estimations in same format as teSMC.
Optimize_N_t<-function(file,gamma=1,theta,L,n=40,ER=T,Pop=T,SB=FALSE,SF=FALSE,BoxB=c(0.1,1),BoxP=c(3,3),Boxr=c(1,1),Boxs=c(0,0.97),pop_vect=NA,window_scaling=c(1,0),sigma=0,beta=1,Big_Window=F,NC=1,mu_b=1,simulator,M){
  Share=T
  SCALED=F
  FS=F
  npair=2
  BW=F
  M_a=2
  scale_T=1
  Correct_window=T
  mut=T
  if(simulator=='msprime'){
    mu_real=theta
  }
  if(ER==2){

    if(Boxr[1]>Boxr[2]){
      Boxr[1]=log10(Boxr[1]/Boxr[2])
      Boxr[2]=0
      Boxr_s=c(1,0)
    }else{
      Boxr[1]=0
      Boxr[2]=log10(Boxr[1]/Boxr[2])
      Boxr_s=c(0,1)
    }

  }
  if(SB==2){
    if(BoxB[1]>BoxB[2]){
      BoxB_s=c(1,0)
    }else{
      BoxB_s=c(0,1)
    }
    BoxB=c(min(BoxB),max(BoxB))
  }
  if(SF==2){
    if(Boxs[1]>Boxs[2]){
      Boxs_s=c(1,0)
    }else{
      Boxs_s=c(0,1)
    }
    Boxs=c(min(Boxs),max(Boxs))
  }



  if(NC==1){

    if(simulator=="scrm"){
      mu=theta
      theta=get_theta(file)
      mu_=theta/((2*sum(1/(1:(M-1))))*L)
      scale_T=mu_/mu
      Ne=NA
    }else{
      theta=get_theta(file)
      mu_=theta/((2*sum(1/(1:(M-1))))*L)
      theta=mu_*((2*sum(1/(1:(M_a-1))))*L)
      Ne=mu_/(mu_real)
    }
    mu=mu_

    #b=get_first_coal_time(file,mut)
    Popfix=!Pop
    Vect=0:(n-1)
    extra_l=M_a*(M_a-1)*0.5
    if(simulator=="scrm"){
      b=get_genealogy(file,M,mut=mut,simulator,Ne=Ne)
    }
    if(simulator=="msprime"){
      b=get_genealogy(file,M,mut=mut,simulator,Ne=Ne)
    }

    Rho=gamma*2*L*mu
    Tc= window_scaling[2] -(0.5*(2-sigma)*log(1-(Vect/n))/(extra_l*(beta^2)*window_scaling[1]))
    Tc=Tc*scale_T


    if(M_a<M){
      print("extracting sub genealogies then building N")
      if(M_a==2){
        count_ind=0
        for(i in 1:(M-1)){
          possible_ind=i:M
          if(i>1){
            if(i<(M-1)){
              b_a_temp1=get_sub_genealogy(b,ind=c(possible_ind),update_index=F)
            }else{
              b_a_temp1=get_sub_genealogy(b,ind=c(possible_ind),update_index=T)
            }
          }else{
            b_a_temp1=b#get_sub_genealogy(b,ind=c(possible_ind),update_index=F)
          }
          for(j in (i+1):(M-1)){
            count_ind=count_ind+1
            ind=c(i,j)
            if(length(ind)<length(possible_ind)){
              b_a=get_sub_genealogy(b_a_temp1,ind,update_index=T)
            }else{
              b_a=b_a_temp1
            }
            #browser()
            if(count_ind==1){
              N=build_N(b_a,Tc)
            }else{
              N=N+build_N(b_a,Tc)
            }
          }
        }
      }

    }else{
      print("building N")
      N=build_N(b,Tc)
    }

    if(BW){
      a=Get_sim_data(file,L,2,1)
      res=build_M(a[[1]],b,Tc)
      print("M is built")
      M=res$M
      print(sum(M))
      q_=res$q
    }
    if(SCALED){
      corrector_N=rowSums(N)
      N=diag(1/corrector_N)%*%N
      if(BW){
        corrector_M=rowSums(M)
        M=diag(1/corrector_M)%*%M
      }
    }
  }else{

    if(length(mu)==1){
      theta=rep(theta,NC)
    }
    if(length(L)==1){
      L=rep(L,NC)
    }


    if(simulator=="scrm"){
      mu=theta
      mu_=c()
      for(chr in 1:NC){
        theta=get_theta(file[chr])
        mu_=c(mu_,theta/((2*sum(1/(1:(M-1))))*L[chr]))
      }
      scale_T=mean(mu_/mu_real)
      Ne=NA
    }else{
      mu_=c()
      for(chr in 1:NC){
        theta=get_theta(file[chr])
        mu_=c(mu_,theta/((2*sum(1/(1:(M-1))))*L[chr]))
      }
      theta=mu_*((2*sum(1/(1:(M_a-1))))*L)
      Ne=mean(mu_/(mu))
    }
    mu=mu_

    #b=get_first_coal_time(file,mut)
    Popfix=!Pop
    Vect=0:(n-1)
    extra_l=M_a*(M_a-1)*0.5

    Rho=gamma*2*L*mu
    Tc= window_scaling[2] -(0.5*(2-sigma)*log(1-(Vect/n))/(extra_l*(beta^2)*window_scaling[1]))
    Tc=Tc*scale_T
    N_total=list()
    M_total=list()
    for(chr in 1:NC){

      b=get_genealogy(file[chr],M,mut=mut,simulator,Ne=Ne)

      if(M_a<M){
        print("extracting sub genealogies then building N")
        if(M_a==2){
          count_ind=0
          for(i in 1:(M-1)){
            possible_ind=i:M
            if(i>1){
              if(i<(M-1)){
                b_a_temp1=get_sub_genealogy(b,ind=c(possible_ind),update_index=F)
              }else{
                b_a_temp1=get_sub_genealogy(b,ind=c(possible_ind),update_index=T)
              }
            }else{
              b_a_temp1=b#get_sub_genealogy(b,ind=c(possible_ind),update_index=F)
            }
            for(j in (i+1):(M-1)){
              count_ind=count_ind+1
              ind=c(i,j)
              if(length(ind)<length(possible_ind)){
                b_a=get_sub_genealogy(b_a_temp1,ind,update_index=T)
              }else{
                b_a=b_a_temp1
              }
              if(count_ind==1){
                N=build_N(b_a,Tc)
              }else{
                N=N+build_N(b_a,Tc)
              }
            }
          }
        }

      }else{
        print("building N")
        N=build_N(b,Tc)
      }

      if(BW){
        a=Get_sim_data(file,L,2,1)
        res=build_M(a[[1]],b,Tc)
        print("M is built")
        M=res$M
        print(sum(M))
        q_=res$q
        M_total[[chr]]=M
      }

      N_total[[chr]]=N
    }
    N=N_total
    M=M_total
  }

  Tc=Tc/scale_T
  scale_T=1
  test.env <- new.env()
  test.env$L <- L
  test.env$k <- n
  test.env$Rho <- Rho
  test.env$window_scaling <- window_scaling
  test.env$Pop<-!Pop
  test.env$NC<-NC
  test.env$FS<-FS
  test.env$Big_Window <- Big_Window
  test.env$npair <- npair


  test.env$Self <- sigma
  test.env$BoxB <- BoxB
  test.env$Boxs <- Boxs
  test.env$Big_Xi <- N
  test.env$mu_b <- mu
  test.env$BW <- BW

  if(ER==2){
    test.env$Boxr_s <- Boxr_s
  }
  if(SB==2){
    test.env$BoxB_s <- BoxB_s
  }
  if(SF==2){
    test.env$Boxs_s <- Boxs_s
  }

  if(BW){
    test.env$Big_M <- M
    test.env$q_ <- q_
  }
  lr=length(Rho)
  test.env$lr<-lr
  if(any(!is.na(pop_vect))){
    Klink=length(pop_vect)
  }
  if((all(is.na(pop_vect))|sum(pop_vect)!=n)){
    Klink=0.5*n
    pop_vect=rep(2, Klink)
    print("Default pop vector")
  }
  test.env$pop_vect <- pop_vect
  if(SF==1){
    sigma=min(Boxs[2],sigma)
    sigma=max(sigma,Boxs[1])
    Self=sigma
    sigma=rep(sigma,length(pop_vect))
  }
  if(SF==2){
    if(Boxs[(Boxs_s[1]+1)]==0){
      sigma=c(rep(Boxs[(Boxs_s[1]+1)],(length(pop_vect)-1)),Boxs[(Boxs_s[2]+1)])
      oldts=length(pop_vect)
    }else{
      sigma=c(Boxs[(Boxs_s[1]+1)],rep(Boxs[(Boxs_s[2]+1)],(length(pop_vect)-1)))
      oldts=1
    }

    #Self=sigma[1]
    Self=min(Boxs)
  }
  if(ER==1){
    oldrho=rep((Boxr[1]/sum(Boxr)),length(pop_vect))
    if(NC>1){
      oldrho=list()
      for(rr in 1:NC){
        oldrho[[rr]]=rep((Boxr[1]/sum(Boxr)),length(pop_vect))
      }
    }

  }
  if(ER==0){
    Boxr=c(0,0)
  }
  if(ER==2){
    oldrho=c(rep(Boxr_s[1],(length(pop_vect)-1)),Boxr_s[2])
    if(NC>1){
      oldrho=list()
      for(rr in 1:NC){
        oldrho[[rr]]=c(rep(Boxr_s[1],(length(pop_vect)-1)),Boxr_s[2])
      }
    }

  }

  if(SB==0&SF==0){
    maxBit=1
  }
  if(SB==0){
    Beta=beta
    test.env$beta <- beta
  }
  if(SF==0){
    Self=sigma
    oldSelf=Self
    test.env$sigma <- sigma
  }
  if(Pop){
    oldXi_=rep((BoxP[1]/sum(BoxP)),Klink)
    oldXi=vector()
    xx=0
    for(ix in 1:Klink){
      x=xx+1
      xx = xx + pop_vect[ix]
      oldXi[x:xx]=oldXi_[ix]
    }
    Xi_=oldXi*sum(BoxP)
    Xi_=Xi_-(BoxP[1])
    Xi_=10^Xi_
  }
  if(SB==1){
    oldbeta=(sqrt(beta)-BoxB[1])/(BoxB[2]-BoxB[1])
  }
  if(SF==1){
    oldsigma=(sigma-Boxs[1])/(Boxs[2]-Boxs[1])
  }
  if(T){
    if(NC==1){

      test.env$ER <- ER
      test.env$SF <- SF
      test.env$SB <- SB



      function_to_minimize<-function(param){

        Boxr=get('Boxr', envir=test.env)
        mu=get('mu', envir=test.env)
        npair=get('npair', envir=test.env)
        Big_Window=get('Big_Window', envir=test.env)
        mu_b=get('mu_b', envir=test.env)
        FS=get('FS', envir=test.env)
        Klink=get('Klink', envir=test.env)
        Rho=get('Rho', envir=test.env)
        BoxB=get('BoxB', envir=test.env)
        Boxs=get('Boxs', envir=test.env)
        BoxP=get('BoxP', envir=test.env)
        pop_vect=get('pop_vect', envir=test.env)
        L=get('L', envir=test.env)
        n=get('k', envir=test.env)
        Beta=get('Beta', envir=test.env)
        Self=get('Self', envir=test.env)
        window_scaling=get('window_scaling', envir=test.env)
        Pop=get('Pop', envir=test.env)
        ER=get('ER', envir=test.env)
        SF=get('SF', envir=test.env)
        SB=get('SB', envir=test.env)
        BW=get('BW', envir=test.env)
        Big_Xi=get('Big_Xi', envir=test.env)

        start_position=0
        if(ER==1){
          rho_=numeric(n)
          rho=param[(start_position+1):(start_position+Klink)]
          rho=rho*sum(Boxr)
          rho=rho-(Boxr[1])
          rho=10^(rho)
          rho=rho*Rho
          start_position=start_position+Klink
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            rho_[x:xx]=rho[ix]

          }

        }
        if(ER==2){

          Boxr_s=get('Boxr_s', envir=test.env)

          rho_=numeric(n)
          #t_r=min(ceiling(param[(start_position+1)]*Klink),Klink)
          t_r=get('t_r', envir=test.env)
          if(t_r>Klink){
            rho=rep(Boxr_s[1],Klink)
          }else{
            if(t_r>1){
              rho=c(rep(Boxr_s[1],(t_r-1)),rep(Boxr_s[2],(Klink-t_r+1)))
            }else{
              rho=rep(Boxr_s[2],Klink)
            }
          }

          rho=rho*sum(Boxr)
          rho=rho-(Boxr[1])
          rho=10^(rho)
          rho=rho*Rho
          #start_position=start_position+1
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            rho_[x:xx]=rho[ix]

          }
        }
        if(ER==0){
          rho_=rep(Rho,n)
        }
        if(SF==1){
          sigma_=numeric(n)
          sigma=param[(start_position+1):(start_position+Klink)]
          start_position=start_position+Klink
          sigma=sigma*(Boxs[2]-Boxs[1])
          sigma=sigma+Boxs[1]
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            sigma_[x:xx]=sigma[ix]
          }
        }
        if(SF==2){
          Boxs_s=get('Boxs_s', envir=test.env)
          sigma_=numeric(n)

          #t_s=min(ceiling(param[(start_position+1)]*Klink),Klink)
          t_s=get('t_s', envir=test.env)

          if(t_s>Klink){
            sigma=rep(Boxs_s[1],Klink)
          }else{
            if(t_s>1){
              sigma=c(rep(Boxs_s[1],(t_s-1)),rep(Boxs_s[2],(Klink-t_s+1)))
            }else{
              sigma=rep(Boxs_s[2],Klink)
            }
          }


          #start_position=start_position+1
          sigma=sigma*(Boxs[2]-Boxs[1])
          sigma=sigma+Boxs[1]
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            sigma_[x:xx]=sigma[ix]
          }

        }
        if(SF==0){
          sigma_=rep(sigma,n)
        }
        if(SB==1){
          beta_=numeric(n)
          beta=((param[(start_position+1):(start_position+Klink)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
          start_position=start_position+(Klink)
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            beta_[x:xx]=beta[ix]

          }
        }
        if(SB==2){
          beta_=numeric(n)
          BoxB_s=get('BoxB_s', envir=test.env)
          #t_b=min(ceiling(param[(start_position+1)]*Klink),Klink)
          t_b=get('t_b', envir=test.env)

          if(t_b>Klink){
            beta=rep(BoxB_s[1],Klink)
          }else{
            if(t_b>1){
              beta=c(rep(BoxB_s[1],(t_b-1)),rep(BoxB_s[2],(Klink-t_b+1)))
            }else{
              beta=rep(BoxB_s[2],Klink)
            }
          }



          beta=((beta*(BoxB[2]-BoxB[1]))+BoxB[1])^2
          # start_position=start_position+1
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            beta_[x:xx]=beta[ix]

          }
        }
        if(SB==0){
          beta_=rep(beta,n)
        }
        if(!Pop){
          Xi=numeric(n)
          Xi_=param[(start_position+1):(start_position+Klink)]
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            Xi[x:xx]=Xi_[ix]
          }
          Xi=Xi*sum(BoxP)
          Xi=Xi-(BoxP[1])
          Xi=10^Xi
        }else{
          Xi=rep(1,n)
        }
        # browser()
        builder=build_HMM_matrix_t(n,rho_,beta=beta_,Pop = Pop,Xi=Xi,L=L,Beta=Beta,scale=window_scaling,sigma = sigma_,Sigma = Self,Big_Window=Big_Window,npair=npair)
        Q=builder[[1]]
        Q=t(Q)
        A=as.vector(Q)
        keep=which(A>0&as.vector(Big_Xi)>0)
        A=A[keep]
        Big_Xi=as.vector(Big_Xi)
        Big_Xi=Big_Xi[keep]



        LH=0




        if(BW){

          q_=get('q_', envir=test.env)
          Big_M=get('Big_M', envir=test.env)

          Tc=builder[[3]]
          g=matrix(0,nrow=length(Tc),ncol=2)
          if(!FS){
            g[,2]=1-exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
            g[,1]=exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
          }
          if(FS){
            g[,2]= 0.75 - (0.75*exp(-4*mu*(beta+((1-beta)*mu_b))*2*Tc/3))
            g[,1]= 0.25 + (0.75*exp(-4*mu*(beta+((1-beta)*mu_b))*2*Tc/3))
          }

          x=as.vector(g)
          keep=which(x>0)
          x=x[keep]
          m=as.vector(Big_M)
          m=m[keep]
          nu=builder[[2]]

          LH=-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)



        }
        if(!BW){
          LH=-sum(log(A)*Big_Xi)

        }

        return(LH)
      }

      if(max(c(ER,SB,SF))<2){


        param=c()
        if(ER==1){
          param=c(param,oldrho)

        }

        if(SF==1){
          param=c(param,oldsigma)
        }

        if(SB==1){
          param=c(param,oldbeta)
        }

        if(!Popfix){
          param=c(param,oldXi)
        }

        sol= BB::BBoptim(param,function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=35+length(param),M=c(20)))
        LH=as.numeric(as.matrix(sol[[2]]))
        sol=as.matrix(sol[[1]])
        start_position=0
        sol=as.numeric(sol[1:length(param),1])

      }else{

        param=c()
        if(ER==1){
          param=c(param,oldrho)

        }

        if(SF==1){
          param=c(param,oldsigma)
        }

        if(SB==1){
          param=c(param,oldbeta)
        }

        if(!Popfix){
          param=c(param,oldXi)
        }

        LH_temp=0

        if(ER==2){
          for(t_r in 1:(1+Klink)){
            test.env$t_r <- t_r
            if(SB==2){
              for( t_b in 1:(1+Klink)){
                test.env$t_b <- t_b
                if(SF==2){

                  for(t_s in 1:(1+Klink)){
                    test.env$t_s <- t_s

                    sol_temp=function_to_minimize(param)
                    if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                      LH_temp=as.numeric(sol_temp)
                      oldtr=t_r
                      oldtb=t_b
                      oldts=t_s

                    }

                  }

                }else{
                  sol_temp=function_to_minimize(param)
                  if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                    LH_temp=as.numeric(sol_temp)
                    oldtr=t_r
                    oldtb=t_b

                  }
                }
              }

            }else{ # NO  SB
              if(SF==2){
                for(t_s in 1:(1+Klink)){
                  test.env$t_s <- t_s
                  sol_temp=function_to_minimize(param)
                  if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                    LH_temp=as.numeric(sol_temp)
                    oldtr=t_r
                    oldts=t_s

                  }
                }
              }else{
                sol_temp=function_to_minimize(param)
                if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                  LH_temp=as.numeric(sol_temp)
                  oldtr=t_r

                }
              }
            }
          }
        }else{ # No ER
          if(SB==2){
            for( t_b in 1:(1+Klink)){
              test.env$t_b <- t_b
              if(SF==2){

                for(t_s in 1:(1+Klink)){
                  test.env$t_s <- t_s
                  sol_temp=function_to_minimize(param)
                  if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                    LH_temp=as.numeric(sol_temp)
                    oldtb=t_b
                    oldts=t_s

                  }
                }
              }else{
                sol_temp=function_to_minimize(param)
                if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                  LH_temp=as.numeric(sol_temp)
                  oldtb=t_b

                }
              }
            }
          }else{
            if(SF==2){

              for(t_s in 1:(1+Klink)){
                test.env$t_s <- t_s
                sol_temp=function_to_minimize(param)
                print(sol_temp)
                if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                  LH_temp=as.numeric(sol_temp)
                  oldts=t_s


                }
              }
            }else{

              stop("How did you get here ?")

            }
          }
        }

        if(ER==2){
          test.env$t_r <- oldtr

          if(oldtr>Klink){
            oldrho=rep(Boxr_s[1],(Klink))
          }else{

            if(oldtr>1){
              oldrho=c(rep(Boxr_s[1],(oldtr-1)),rep(Boxr_s[2],(Klink+1-oldtr)))
            }else{
              oldrho=rep(Boxr_s[2],(Klink))
            }
          }


        }


        if(SF==2){
          # oldts=ceiling(sol[(start_position+1)]*Klink)
          #   start_position=start_position+1
          test.env$t_s <- oldts

          if(oldts>Klink){
            oldsigma=rep(Boxs_s[1],(Klink))
          }else{
            if(oldts>1){
              oldsigma=c(rep(Boxs_s[1],(oldts-1)),rep(Boxs_s[2],(Klink+1-oldts)))
            }else{
              oldsigma=rep(Boxs_s[2],(Klink))
            }
          }


        }


        if(SB==2){
          #    oldtb=ceiling(sol[(start_position+1)]*Klink)
          #   start_position=start_position+1
          test.env$t_b <- oldtb

          if(oldtb>Klink){
            oldbeta=rep(BoxB_s[1],(Klink))
          }else{
            if(oldtb>1){
              oldbeta=c(rep(BoxB_s[1],(oldtb-1)),rep(BoxB_s[2],(Klink+1-oldtb)))
            }else{
              oldbeta=rep(BoxB_s[2],(Klink))
            }
          }


        }

        param=c()
        if(ER==1){
          param=c(param,oldrho)

        }

        if(SF==1){
          param=c(param,oldsigma)
        }

        if(SB==1){
          param=c(param,oldbeta)
        }

        if(!Popfix){
          param=c(param,oldXi)
        }


        sol= BB::BBoptim(param,function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(param),M=c(20)))
        LH=as.numeric(as.matrix(sol[[2]]))
        sol=as.matrix(sol[[1]])
        start_position=0
        sol=as.numeric(sol[1:length(param),1])
      }

      if(ER==1){
        rho=sol[(start_position+1):(start_position+Klink)]
        start_position=start_position+Klink
        oldrho=rho
      }

      if(SF==1){
        sigma_=sol[(start_position+1):(start_position+Klink)]
        start_position=start_position+Klink
        oldsigma=sigma_
      }



      if(SB==1){
        beta_=sol[(start_position+1):(start_position+Klink)]
        start_position=start_position+Klink
        oldbeta=beta_
      }


      if(!Popfix){
        Xi_=sol[(start_position+1):(start_position+Klink)]
        start_position=start_position+Klink
        oldXi_=Xi_
      }

    }


    if(NC>1){

      test.env$ER <- ER
      test.env$SF <- SF
      test.env$SB <- SB



      function_to_minimize<-function(param){
        Boxr=get('Boxr', envir=test.env)
        mu=get('mu', envir=test.env)
        npair=get('npair', envir=test.env)
        Big_Window=get('Big_Window', envir=test.env)
        mu_b=get('mu_b', envir=test.env)
        FS=get('FS', envir=test.env)
        Klink=get('Klink', envir=test.env)
        Rho=get('Rho', envir=test.env)
        BoxB=get('BoxB', envir=test.env)
        Boxs=get('Boxs', envir=test.env)
        BoxP=get('BoxP', envir=test.env)
        pop_vect=get('pop_vect', envir=test.env)
        L=get('L', envir=test.env)
        n=get('k', envir=test.env)
        Beta=get('Beta', envir=test.env)
        Self=get('Self', envir=test.env)
        window_scaling=get('window_scaling', envir=test.env)
        Pop=get('Pop', envir=test.env)
        ER=get('ER', envir=test.env)
        SF=get('SF', envir=test.env)
        SB=get('SB', envir=test.env)

        BW=get('BW', envir=test.env)
        Big_Xi=get('Big_Xi', envir=test.env)

        a=0
        start_position=0
        if(ER==1){
          rho=list()
          rho_=list()
          oldrho_param=param[(start_position+1):(start_position+(Klink*NC))]
          for(rr in 1:NC){
            rho[[rr]]= oldrho_param[(1+((rr-1)*Klink)):(rr*Klink)]*sum(Boxr)
            rho[[rr]]=rho[[rr]]-(Boxr[1])
            rho[[rr]]=10^(rho[[rr]])
            rho[[rr]]=rho[[rr]]*Rho[rr]

            xx=0
            rho_[[rr]]=vector()
            for(ix in 1:Klink){
              x=xx+1
              xx = xx + pop_vect[ix]
              rho_[[rr]][x:xx]= rho[[rr]][ix]
            }
          }
          start_position=start_position+(Klink*NC)
        }
        if(ER==2){

          Boxr_s=get('Boxr_s', envir=test.env)





          rho=list()
          rho_=list()
          # t_r=ceiling(param[(start_position+1)]*Klink)
          t_r=get('t_r', envir=test.env)
          for(rr in 1:NC){
            if(t_r>Klink){
              rho[[rr]]=rep(Boxr_s[1],Klink)
            }else{
              if(t_r>1){
                rho[[rr]]=c(rep(Boxr_s[1],(t_r-1)),rep(Boxr_s[2],(Klink-t_r+1)))
              }else{
                rho[[rr]]=rep(Boxr_s[2],Klink)
              }
            }



            rho[[rr]]= rho[[rr]]*sum(Boxr)
            rho[[rr]]=rho[[rr]]-(Boxr[1])
            rho[[rr]]=10^(rho[[rr]])
            rho[[rr]]=rho[[rr]]*Rho[rr]

            xx=0
            rho_[[rr]]=vector()
            for(ix in 1:Klink){
              x=xx+1
              xx = xx + pop_vect[ix]
              rho_[[rr]][x:xx]= rho[[rr]][ix]
            }
          }
          #  start_position=start_position+1
        }

        if(ER==0){
          rho_=list()
          for(rr in 1:NC){
            rho_[[rr]]=rep(Rho[rr],n)
          }
        }
        if(SF==1){
          sigma_=numeric(n)
          sigma=param[(start_position+1):(start_position+(Klink))]
          start_position=start_position+(Klink)
          sigma=sigma*(Boxs[2]-Boxs[1])
          sigma=sigma+Boxs[1]
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            sigma_[x:xx]=sigma[ix]
          }

        }



        if(SF==2){
          Boxs_s=get('Boxs_s', envir=test.env)
          sigma_=numeric(n)
          #t_s=ceiling(param[(start_position+1)]*Klink)
          t_s=get('t_s', envir=test.env)

          if(t_s>Klink){
            sigma=rep(Boxs_s[1],Klink)
          }else{
            if(t_s>1){
              sigma=c(rep(Boxs_s[1],(t_s-1)),rep(Boxs_s[2],(Klink-t_s+1)))
            }else{
              sigma=rep(Boxs_s[2],Klink)
            }
          }


          # start_position=start_position+1
          sigma=sigma*(Boxs[2]-Boxs[1])
          sigma=sigma+Boxs[1]
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            sigma_[x:xx]=sigma[ix]
          }
        }

        if(SF==0){
          sigma_=rep(sigma,n)
        }
        if(SB==1){
          beta_=numeric(n)
          beta=((param[(start_position+1):(start_position+(Klink))]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
          start_position=start_position+(Klink)
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            beta_[x:xx]=beta[ix]

          }
        }
        if(SB==2){
          beta_=numeric(n)
          BoxB_s=get('BoxB_s', envir=test.env)
          # t_b=ceiling(param[(start_position+1)]*Klink)
          t_b=get('t_b', envir=test.env)
          if(t_b>Klink){
            beta=rep(BoxB_s[1],Klink)
          }else{
            if(t_b>1){
              beta=c(rep(BoxB_s[1],(t_b-1)),rep(BoxB_s[2],(Klink-t_b+1)))
            }else{
              beta=rep(BoxB_s[2],Klink)
            }
          }

          beta=((beta*(BoxB[2]-BoxB[1]))+BoxB[1])^2
          #   start_position=start_position+1
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            beta_[x:xx]=beta[ix]

          }
        }
        if(SB==0){
          beta_=rep(beta,n)
        }

        if(!Pop){
          Xi=numeric(n)
          Xi_=param[(start_position+1):(start_position+Klink)]
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            Xi[x:xx]=Xi_[ix]
          }
          Xi=Xi*sum(BoxP)
          Xi=Xi-(BoxP[1])
          Xi=10^Xi
        }else{
          Xi=rep(1,n)
        }




        LH=0


        for(chr in 1:NC){

          builder=build_HMM_matrix_t(n,(rho_[[chr]]),beta=beta_,Pop = Pop,Xi=Xi,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma_,Sigma = Self,Big_Window=Big_Window,npair=npair)
          Q=builder[[1]]
          Q=t(Q)
          A=as.vector(Q)
          keep=which(as.vector(Big_Xi[[chr]])>0)
          A=A[keep]
          Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
          Big_Xi[[chr]]=Big_Xi[[chr]][keep]

          if(BW){

            q_=get('q_', envir=test.env)
            Big_M=get('Big_M', envir=test.env)
            Tc=builder[[3]]
            g=matrix(0,nrow=length(Tc),ncol=2)
            if(!FS){
              g[,2]=1-exp(-mu*(beta_+((1-beta_)*mu_b))*2*Tc)
              g[,1]=exp(-mu*(beta_+((1-beta_)*mu_b))*2*Tc)
            }
            if(FS){
              g[,2]= 0.75 - (0.75*exp(-4*mu*(beta_+((1-beta_)*mu_b))*2*Tc/3))
              g[,1]= 0.25 + (0.75*exp(-4*mu*(beta_+((1-beta_)*mu_b))*2*Tc/3))
            }
            x=as.vector(g)
            keep=which(x>0)
            x=x[keep]
            m=as.vector(Big_M[[chr]])
            m=m[keep]

            nu=builder[[2]]
            LH=LH-sum(log(A)*Big_Xi[[chr]])-sum(log(x)*m)-sum(log(nu)*q_[[chr]])
          }
          if(!BW){
            LH=LH-sum(log(A)*Big_Xi[[chr]])
          }




          LH=LH


        }

        return(LH)
      }


      if(max(c(ER,SB,SF))<2){


        param=c()
        if(ER==1){
          for(rr in 1:NC){
            param=c(param,oldrho[[rr]])
          }
        }

        if(SF==1){
          param=c(param,oldsigma)
        }

        if(SB==1){
          param=c(param,oldbeta)
        }

        if(!Popfix){
          param=c(param,oldXi)
        }

        sol= BB::BBoptim(param,function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=35+length(param),M=c(20)))
        LH=as.numeric(as.matrix(sol[[2]]))
        sol=as.matrix(sol[[1]])
        start_position=0


        sol=as.numeric(sol[1:length(param),1])
        if(ER==1){
          rho=sol[(start_position+1):(start_position+(Klink*NC))]
          start_position=start_position+(Klink*NC)
          if(ER==1){
            for(rr in 1:NC){
              oldrho[[rr]]=rho[(1+((rr-1)*Klink)):(rr*Klink)]
            }
          }
        }

        if(SF==1){
          sigma_=sol[(start_position+1):(start_position+Klink)]
          start_position=start_position+Klink
          oldsigma=sigma_
        }

        if(SB==1){
          beta_=sol[(start_position+1):(start_position+Klink)]
          start_position=start_position+Klink
          oldbeta=beta_
        }


        if(!Popfix){
          Xi_=sol[(start_position+1):(start_position+Klink)]
          start_position=start_position+Klink
          oldXi_=Xi_
        }
      }else{


        param=c()
        if(ER==1){
          for(rr in 1:NC){
            param=c(param,oldrho[[rr]])
          }
        }
        if(ER==3){
          param=c(param,Boxr_s)

        }
        if(SF==1){
          param=c(param,oldsigma)
        }
        if(SF==3){
          param=c(param,Boxs_s)
        }
        if(SB==1){
          param=c(param,oldbeta)
        }
        if(SB==3){
          param=c(param,BoxB_s)
        }

        if(!Popfix){
          param=c(param,oldXi_)
        }

        LH_temp=0

        if(ER==2){
          for(t_r in 1:(1+Klink)){
            test.env$t_r <- t_r
            if(SB==2){
              for( t_b in 1:(1+Klink)){
                test.env$t_b <- t_b
                if(SF==2){

                  for(t_s in 1:(1+Klink)){
                    test.env$t_s <- t_s

                    sol_temp=function_to_minimize(param)
                    if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                      LH_temp=as.numeric(sol_temp)
                      oldtr=t_r
                      oldtb=t_b
                      oldts=t_s

                    }

                  }

                }else{
                  sol_temp=function_to_minimize(param)
                  if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                    LH_temp=as.numeric(sol_temp)
                    oldtr=t_r
                    oldtb=t_b

                  }
                }
              }

            }else{ # NO  SB
              if(SF==2){
                for(t_s in 1:(1+Klink)){
                  test.env$t_s <- t_s
                  sol_temp=function_to_minimize(param)
                  if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                    LH_temp=as.numeric(sol_temp)
                    oldtr=t_r
                    oldts=t_s

                  }
                }
              }else{
                sol_temp=function_to_minimize(param)
                if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                  LH_temp=as.numeric(sol_temp)
                  oldtr=t_r

                }
              }
            }
          }
        }else{ # No ER
          if(SB==2){
            for( t_b in 1:(1+Klink)){
              test.env$t_b <- t_b
              if(SF==2){

                for(t_s in 1:(1+Klink)){
                  test.env$t_s <- t_s
                  sol_temp=function_to_minimize(param)
                  if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                    LH_temp=as.numeric(sol_temp)
                    oldtb=t_b
                    oldts=t_s

                  }
                }
              }else{
                sol_temp=function_to_minimize(param)
                if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                  LH_temp=as.numeric(sol_temp)
                  oldtb=t_b

                }
              }
            }
          }else{
            if(SF==2){

              for(t_s in 1:(1+Klink)){
                test.env$t_s <- t_s
                sol_temp=function_to_minimize(param)
                print(sol_temp)
                if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                  LH_temp=as.numeric(sol_temp)
                  oldts=t_s


                }
              }
            }else{

              stop("How did you get here ?")

            }
          }
        }

        if(ER==2){
          test.env$t_r <- oldtr

          if(oldtr>Klink){
            oldrho=rep(Boxr_s[1],(Klink))
          }else{
            if(oldtr>1){
              oldrho=c(rep(Boxr_s[1],(oldtr-1)),rep(Boxr_s[2],(Klink+1-oldtr)))
            }else{
              oldrho=rep(Boxr_s[2],(Klink))
            }
          }


        }


        if(SF==2){

          test.env$t_s <- oldts
          if(oldts>Klink){
            oldsigma=rep(Boxs_s[1],(Klink))
          }else{
            if(oldts>1){
              oldsigma=c(rep(Boxs_s[1],(oldts-1)),rep(Boxs_s[2],(Klink+1-oldts)))
            }else{
              oldsigma=rep(Boxs_s[2],(Klink))
            }
          }


        }


        if(SB==2){


          test.env$t_b <- oldtb

          if(oldtb>Klink){
            oldbeta=rep(BoxB_s[1],(Klink))
          }else{
            if(oldtb>1){
              oldbeta=c(rep(BoxB_s[1],(oldtb-1)),rep(BoxB_s[2],(Klink+1-oldtb)))
            }else{
              oldbeta=rep(BoxB_s[2],(Klink))
            }
          }


        }


        param=c()
        if(ER==1){
          for(rr in 1:NC){
            param=c(param,oldrho[[rr]])
          }
        }
        if(ER==3){
          param=c(param,Boxr_s)

        }
        if(SF==1){
          param=c(param,oldsigma)
        }
        if(SF==3){
          param=c(param,Boxs_s)
        }
        if(SB==1){
          param=c(param,oldbeta)
        }
        if(SB==3){
          param=c(param,BoxB_s)
        }

        if(!Popfix){
          param=c(param,oldXi_)
        }

        sol= BB::BBoptim(param,function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=35+length(param),M=c(20)))
        LH=as.numeric(as.matrix(sol[[2]]))
        sol=as.matrix(sol[[1]])
        start_position=0
        sol=as.numeric(sol[1:length(param),1])
        if(ER==1){
          rho=sol[(start_position+1):(start_position+(Klink*NC))]
          start_position=start_position+(Klink*NC)
          if(ER==1){
            for(rr in 1:NC){
              oldrho[[rr]]=rho[(1+((rr-1)*Klink)):(rr*Klink)]
            }
          }
        }
        if(ER==3){

          Boxr_s=sol[(start_position+1):(start_position+2)]
          test.env$Boxr_s <- Boxr_s
          start_position=start_position+2
          for(rr in 1:NC){
            if(oldtr>Klink){
              oldrho[[rr]]=rep(Boxr_s[1],(Klink))
            }else{
              if(oldtr>1){
                oldrho[[rr]]=c(rep(Boxr_s[1],(oldtr-1)),rep(Boxr_s[2],(Klink+1-oldtr)))
              }else{
                oldrho[[rr]]=rep(Boxr_s[2],(Klink))
              }
            }
          }

        }
        if(SF==1){
          sigma_=sol[(start_position+1):(start_position+Klink)]
          start_position=start_position+Klink
          oldsigma=sigma_
        }
        if(SF==3){
          Boxs_s=sol[(start_position+1):(start_position+2)]
          test.env$Boxs_s <- Boxs_s
          start_position=start_position+2
          if(oldts>Klink){
            oldsigma=rep(Boxs_s[1],(Klink))
          }else{
            if(oldts>1){
              oldsigma=c(rep(Boxs_s[1],(oldts-1)),rep(Boxs_s[2],(Klink+1-oldts)))
            }else{
              oldsigma=rep(Boxs_s[2],(Klink))
            }
          }
        }
        if(SB==1){
          beta_=sol[(start_position+1):(start_position+Klink)]
          start_position=start_position+Klink
          oldbeta=beta_
        }
        if(SB==3){
          BoxB_s=sol[(start_position+1):(start_position+2)]
          test.env$BoxB_s <- BoxB_s
          start_position=start_position+2
          if(oldtb>Klink){
            oldbeta=rep(BoxB_s[1],(Klink))
          }else{
            if(oldtb>1){
              oldbeta=c(rep(BoxB_s[1],(oldtb-1)),rep(BoxB_s[2],(Klink+1-oldtb)))
            }else{
              oldbeta=rep(BoxB_s[2],(Klink))
            }
          }
        }

        if(!Popfix){
          Xi_=sol[(start_position+1):(start_position+Klink)]
          start_position=start_position+Klink
          oldXi_=Xi_
        }

      }

    }
  }



  if(SB>0){
    beta_=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1] )^2
    beta=vector()
    xx=0
    for(ix in 1:Klink){
      x=xx+1
      xx = xx + pop_vect[ix]
      beta[x:xx]=beta_[ix]
    }
  }
  if(SF>0){
    sigma_=oldsigma*(Boxs[2]-Boxs[1])
    sigma_=sigma_+Boxs[1]
    sigma=vector()
    xx=0
    for(ix in 1:Klink){
      x=xx+1
      xx = xx + pop_vect[ix]
      sigma[x:xx]= sigma_[ix]
    }
  }
  if(NC==1){
    if(ER>0){
      rho_=oldrho*sum(Boxr)
      rho_=rho_-(Boxr[1])
      rho_=10^(rho_)
      rho_=rho_*Rho
      rho=vector()
      xx=0
      for(ix in 1:Klink){
        x=xx+1
        xx = xx + pop_vect[ix]
        rho[x:xx]=rho_[ix]
      }
    }else{
      rho=Rho
      rho_=Rho
    }
  }
  if(NC>1){
    if(ER>0){
      rho_=list()
      rho=list()
      for(chr in 1:NC){
        rho_[[chr]]=oldrho[[chr]]*sum(Boxr)
        rho_[[chr]]=rho_[[chr]]-(Boxr[1])
        rho_[[chr]]=10^(rho_[[chr]])
        rho_[[chr]]=rho_[[chr]]*Rho[chr]
        rho[[chr]]=vector()
        xx=0
        for(ix in 1:Klink){
          x=xx+1
          xx = xx + pop_vect[ix]
          rho[[chr]][x:xx]=rho_[[chr]][ix]/(2*L)
        }
      }
    }else{
      rho=Rho/(2*L)
    }
  }

  res<-list()
  res$beta=beta
  res$sigma=sigma


  if(Pop){
    xx=0
    for(ix in 1:Klink){
      x=xx+1
      xx = xx + pop_vect[ix]
      oldXi[x:xx]=oldXi_[ix]
    }
    Xi_=oldXi*sum(BoxP)
    Xi_=Xi_-(BoxP[1])
    Xi_=10^Xi_
    res$Xi=Xi_
  }else{
    res$Xi=rep(1,n)
  }
  Beta=get('Beta', envir=test.env)
  Self=get('Self', envir=test.env)
  res$rho=rho
  res$Tc=Tc
  res$mu=mu
  res$N=N
  return(res)
}
