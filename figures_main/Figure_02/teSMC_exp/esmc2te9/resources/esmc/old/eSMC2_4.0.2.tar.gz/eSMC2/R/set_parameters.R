#' Sets parameters value given some teSMC intput
#'
#' @param estimate : character
#' @param model : character
#' @return A numeric vector of size 3 correspong to the numerical value of ER,SF and SB which are necessary input for the baum-welch algorithm.
set_parameters<-function(estimate,model){
  output=c(0,0,0)
  if(estimate=="ER"){
    output[1]=1
  }
  if(estimate=="SF"){
    output[2]=1
  }
  if(estimate=="SB"){
    output[3]=1
  }

  if(model=="Given Transition"){
    output[which(output==1)]=2
  }
  if(model=="One transition"){
    output[which(output==1)]=3
  }
  return(output)
}
