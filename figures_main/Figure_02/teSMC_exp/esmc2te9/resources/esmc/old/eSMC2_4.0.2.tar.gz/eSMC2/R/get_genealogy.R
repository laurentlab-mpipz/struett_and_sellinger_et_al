#' get the genealogy of a simulation in the newick format
#'
#' @param file : path to the .txt file
#' @param M : number of simulated sequences
#' @param mut : TRUE if mutation were simulated
#' @param simulator : "scrm" or "msprime"
#' @param Ne : NA for scrm and the effective haploid population size if using msprime
#' @export
#' @return list of size 3 containing matrices describing genealogy. First and second list object contain index of coalescing individual, first coalescent event being in last line and  each column is a different genealogy. Last object sequence length of genealogy on last line and coalescent times on others lines (starting at line M-1)
get_genealogy<-function(file,M,mut=F,simulator,Ne=NA){
  data=Get_data(file,heavy = T,simulator=simulator)
  character_size=ceiling(log10(M+1))
  Output=list()
  coal_time=matrix(0,nrow = (M), ncol= (length(data)))
  id_split=matrix(0,nrow = (M-1), ncol= (length(data)))
  id_create=matrix(0,nrow = (M-1), ncol= (length(data)))
  start=F
  end=F
  bonus=0
  for(i in 1:length(data)){
    if(simulator=="scrm"){
    if(length(substr(data[[i]],1,3))>0){
      if(start&mut&substr(data[[i]],1,3)[1]=="seg"){

        end=T
        coal_time=coal_time[,-c((i-start_i):(length(data)))]
        id_split=id_split[,-c((i-start_i):(length(data)))]
        id_create=id_create[,-c((i-start_i):(length(data)))]
        }
      }
    }
    if(!end){
      if(start){
        genealogy=data[[i]]

        if(length(which(strsplit(genealogy,split = "")[[1]]=="]"))==1 & length(which(strsplit(genealogy,split = "")[[1]]=="["))==1){
          coal_time[M,(i-start_i+bonus)]=as.numeric(substr(genealogy,2,(gregexpr(genealogy,pattern = "]")[[1]][1]-1)))
          j=0

          while(j <(M-1)){
            j_ad=0
            j=j+1
            #print(genealogy)
            truc_expr=as.numeric(gregexpr(genealogy,pattern = ":")[[1]])
            for(xx in 1:length(as.numeric(gregexpr(genealogy,pattern = ")")[[1]]))){

              if(simulator=="msprime"){
                id1_v=as.numeric(gregexpr(genealogy,pattern = ",")[[1]])[which(as.numeric(gregexpr(genealogy,pattern = ",")[[1]])<as.numeric(gregexpr(genealogy,pattern = ")")[[1]][xx]))]
                id1=max(id1_v[which(id1_v<max(truc_expr[which(truc_expr<as.numeric(gregexpr(genealogy,pattern = ")")[[1]][xx]))]))])
              }
              if(simulator=="scrm"){
                id1=max(as.numeric(gregexpr(genealogy,pattern = ",")[[1]])[which(as.numeric(gregexpr(genealogy,pattern = ",")[[1]])<as.numeric(gregexpr(genealogy,pattern = ")")[[1]][xx]))])
              }
              if(is.infinite(id1)|is.na(as.numeric(id1))){
                browser()
              }

              if(xx==1){


                pos_p1=max(as.numeric(gregexpr(genealogy,pattern = "\\(")[[1]])[which(as.numeric(gregexpr(genealogy,pattern = "\\(")[[1]])<id1)])
                pos_p2=min(as.numeric(gregexpr(genealogy,pattern = ")")[[1]])[which(as.numeric(gregexpr(genealogy,pattern = ")")[[1]])>id1)])


                if(length(which(truc_expr>pos_p1&truc_expr<pos_p2))>2){
                  names=c()
                  pos_cn=1:length(which(truc_expr>pos_p1&truc_expr<pos_p2))
                  for(id_count in character_size:1){
                    for(c_n in pos_cn){
                      name1=as.numeric(substr(genealogy,(truc_expr[which(truc_expr>pos_p1&truc_expr<pos_p2)[c_n]]-id_count),(truc_expr[which(truc_expr>pos_p1&truc_expr<pos_p2)[c_n]]-1)))
                      if(!is.na(name1)){
                        names=c(names,name1)
                        pos_cn=pos_cn[-which(pos_cn==c_n)]
                      }
                    }

                  }

                  name_split=min(names)
                  names=names[-which(names==name_split)]
                  for(c_n in 1:(length(which(truc_expr>pos_p1&truc_expr<pos_p2))-1)){
                    name_create=max(names)
                    names=names[-which(names==name_create)]
                    id_split[(M-j-c_n+1),(i-start_i+bonus)]=name_split
                    id_create[(M-j-c_n+1),(i-start_i+bonus)]=name_create
                  }




                  if(as.numeric(id_split[(M-j),(i-start_i+bonus)])==0){
                    browser()
                  }
                  if(simulator=="scrm"){
                    coal_time[(M-j),(i-start_i+bonus)]=as.numeric(substr(genealogy,(truc_expr[max(which(truc_expr<id1))]+1),(id1-1)))
                    coal_time[(M-j-1):(M-j-length(which(truc_expr>pos_p1&truc_expr<pos_p2))+2),(i-start_i+bonus)]=as.numeric(substr(genealogy,(truc_expr[max(which(truc_expr<id1))]+1),(id1-1)))#0

                  }
                  if(simulator=="msprime"){
                    coal_time_exp=substr(genealogy,(truc_expr[max(which(truc_expr<id1))]+1),(id1-1))
                    coal_time_exp=gsub(",",".",coal_time_exp)
                    if(is.na(as.numeric(coal_time_exp))){
                      browser()
                    }
                    coal_time[(M-j),(i-start_i+bonus)]=as.numeric(coal_time_exp)
                    coal_time[(M-j-1):(M-j-length(which(truc_expr>pos_p1&truc_expr<pos_p2))+2),(i-start_i+bonus)]=as.numeric(coal_time_exp)#0
                  }




                  x_k=xx
                  id1_s=id1


                }else{
                  for(id_count in 1:character_size){


                    name1=as.numeric(substr(genealogy,(truc_expr[min(which(truc_expr>id1))]-id_count),(truc_expr[min(which(truc_expr>id1))]-1)))
                    name2=as.numeric(substr(genealogy,(truc_expr[max(which(truc_expr<id1))]-id_count),(truc_expr[max(which(truc_expr<id1))]-1)))
                    if(!is.na(name1)){
                      name_pot1=as.numeric(name1)
                    }
                    if(!is.na(name2)){
                      name_pot2=as.numeric(name2)
                    }
                  }
                  name_split=min(as.numeric(c(name_pot1,name_pot2)))
                  name_create=max(as.numeric(c(name_pot1,name_pot2)))
                  id_split[(M-j),(i-start_i+bonus)]=name_split



                  id_create[(M-j),(i-start_i+bonus)]=name_create

                  if(as.numeric(id_split[(M-j),(i-start_i+bonus)])==0){
                    browser()
                  }
                  if(simulator=="scrm"){
                    coal_time[(M-j),(i-start_i+bonus)]=as.numeric(substr(genealogy,(truc_expr[max(which(truc_expr<id1))]+1),(id1-1)))
                  }
                  if(simulator=="msprime"){
                    coal_time_exp=substr(genealogy,(truc_expr[max(which(truc_expr<id1))]+1),(id1-1))
                    coal_time_exp=gsub(",",".",coal_time_exp)
                    if(is.na(as.numeric(coal_time_exp))){
                      browser()
                    }
                    coal_time[(M-j),(i-start_i+bonus)]=as.numeric(coal_time_exp)
                  }

                  x_k=xx
                  id1_s=id1


                }
                j_ad=length(which(truc_expr>pos_p1&truc_expr<pos_p2))-2
              }
              if(xx>1){
                if(id1>as.numeric(gregexpr(genealogy,pattern = ")")[[1]][(xx-1)])){
                  if(substr(genealogy,(truc_expr[max(which(truc_expr<id1))]-1),(truc_expr[max(which(truc_expr<id1))]-1))!=")"){
                    if(simulator=="scrm"){
                      check_expr=substr(genealogy,(truc_expr[max(which(truc_expr<id1))]+1),(id1-1))
                    }
                    if(simulator=="msprime"){
                      check_expr=substr(genealogy,(truc_expr[max(which(truc_expr<id1))]+1),(id1-1))
                      check_expr=gsub(",",".",check_expr)
                    }
                    if(is.na(as.numeric(check_expr))|is.na(as.numeric(coal_time[(M-j),(i-start_i+bonus)]))){
                      browser()
                    }
                    if(as.numeric(check_expr)<(coal_time[(M-j),(i-start_i+bonus)])){

                      pos_p1=max(as.numeric(gregexpr(genealogy,pattern = "\\(")[[1]])[which(as.numeric(gregexpr(genealogy,pattern = "\\(")[[1]])<id1)])
                      pos_p2=min(as.numeric(gregexpr(genealogy,pattern = ")")[[1]])[which(as.numeric(gregexpr(genealogy,pattern = ")")[[1]])>id1)])

                      if(length(which(truc_expr>pos_p1&truc_expr<pos_p2))>2){
                        names=c()
                        pos_cn=1:length(which(truc_expr>pos_p1&truc_expr<pos_p2))
                        for(id_count in character_size:1){
                          for(c_n in pos_cn){
                            name1=as.numeric(substr(genealogy,(truc_expr[which(truc_expr>pos_p1&truc_expr<pos_p2)[c_n]]-id_count),(truc_expr[which(truc_expr>pos_p1&truc_expr<pos_p2)[c_n]]-1)))
                            if(!is.na(name1)){
                              names=c(names,name1)
                              pos_cn=pos_cn[-which(pos_cn==c_n)]
                            }
                          }

                        }
                        name_split=min(names)
                        names=names[-which(names==name_split)]
                        for(c_n in 1:(length(which(truc_expr>pos_p1&truc_expr<pos_p2))-1)){
                          name_create=max(names)
                          names=names[-which(names==name_create)]
                          id_split[(M-j-c_n+1),(i-start_i+bonus)]=name_split
                          id_create[(M-j-c_n+1),(i-start_i+bonus)]=name_create
                        }




                        if(as.numeric(id_split[(M-j),(i-start_i+bonus)])==0){
                          browser()
                        }
                        if(simulator=="scrm"){
                          coal_time[(M-j),(i-start_i+bonus)]=as.numeric(substr(genealogy,(truc_expr[max(which(truc_expr<id1))]+1),(id1-1)))
                          coal_time[(M-j-1):(M-j-length(which(truc_expr>pos_p1&truc_expr<pos_p2))+2),(i-start_i+bonus)]=as.numeric(substr(genealogy,(truc_expr[max(which(truc_expr<id1))]+1),(id1-1)))#0

                        }
                        if(simulator=="msprime"){
                          coal_time_exp=substr(genealogy,(truc_expr[max(which(truc_expr<id1))]+1),(id1-1))
                          coal_time_exp=gsub(",",".",coal_time_exp)
                          if(is.na(as.numeric(coal_time_exp))){
                            browser()
                          }
                          coal_time[(M-j),(i-start_i+bonus)]=as.numeric(coal_time_exp)
                          coal_time[(M-j-1):(M-j-length(which(truc_expr>pos_p1&truc_expr<pos_p2))+2),(i-start_i+bonus)]=as.numeric(coal_time_exp)#0
                        }


                        x_k=xx
                        id1_s=id1


                      }else{

                        for(id_count in 1:character_size){
                          name1=as.numeric(substr(genealogy,(truc_expr[min(which(truc_expr>id1))]-id_count),(truc_expr[min(which(truc_expr>id1))]-1)))
                          name2=as.numeric(substr(genealogy,(truc_expr[max(which(truc_expr<id1))]-id_count),(truc_expr[max(which(truc_expr<id1))]-1)))
                          if(!is.na(name1)){
                            name_pot1=as.numeric(name1)
                          }
                          if(!is.na(name2)){
                            name_pot2=as.numeric(name2)
                          }
                        }
                        name_split=min(as.numeric(c(name_pot1,name_pot2)))
                        name_create=max(as.numeric(c(name_pot1,name_pot2)))
                        id_split[(M-j),(i-start_i+bonus)]=name_split
                        id_create[(M-j),(i-start_i+bonus)]=name_create
                        if(as.numeric(id_split[(M-j),(i-start_i+bonus)])==0){
                          browser()
                        }
                        if(simulator=="scrm"){
                          coal_time[(M-j),(i-start_i+bonus)]=as.numeric(substr(genealogy,(truc_expr[max(which(truc_expr<id1))]+1),(id1-1)))
                        }
                        if(simulator=="msprime"){
                          coal_time_exp=substr(genealogy,(truc_expr[max(which(truc_expr<id1))]+1),(id1-1))
                          coal_time_exp=gsub(",",".",coal_time_exp)
                          coal_time[(M-j),(i-start_i+bonus)]=as.numeric(coal_time_exp)
                        }
                        x_k=xx
                        id1_s=id1
                      }



                      j_ad=length(which(truc_expr>pos_p1&truc_expr<pos_p2))-2

                    }


                  }
                }
              }

            }
            if((j+j_ad)<(M-1)){
              pos_e=c()
              if(x_k<xx){
                pos_e=c(pos_e,as.numeric((gregexpr(genealogy,pattern = ")")[[1]][x_k+1]-1)))
              }
              if(simulator=="scrm"){
                if(!is.na(as.numeric((gregexpr(genealogy,pattern = ",")[[1]][min(na.rm =T,which(as.numeric(gregexpr(genealogy,pattern = ",")[[1]])>as.numeric(gregexpr(genealogy,pattern = ")")[[1]][x_k])))])))){
                  pos_e=c(pos_e,(as.numeric((gregexpr(genealogy,pattern = ",")[[1]][min(na.rm =T,which(as.numeric(gregexpr(genealogy,pattern = ",")[[1]])>as.numeric(gregexpr(genealogy,pattern = ")")[[1]][x_k])))]))-1))
                }
                pos_e=min(pos_e)
                time=(coal_time[(M-j),(i-start_i+bonus)])+as.numeric(substr(genealogy,(gregexpr(genealogy,pattern = ")")[[1]][x_k]+2),pos_e))
                new_ind=paste(id_split[(M-j),(i-start_i+bonus)],":",time,sep="")
              }
              if(simulator=="msprime"){
                if(!is.na(as.numeric((gregexpr(genealogy,pattern = ",")[[1]][(1+min(na.rm =T,which(as.numeric(gregexpr(genealogy,pattern = ",")[[1]])>as.numeric(gregexpr(genealogy,pattern = ")")[[1]][x_k]))))])))){
                  pos_e=c(pos_e,(as.numeric((gregexpr(genealogy,pattern = ",")[[1]][(1+min(na.rm =T,which(as.numeric(gregexpr(genealogy,pattern = ",")[[1]])>as.numeric(gregexpr(genealogy,pattern = ")")[[1]][x_k]))))]))-1))
                }
                pos_e=min(pos_e)
                time_exp=substr(genealogy,(gregexpr(genealogy,pattern = ")")[[1]][x_k]+2),pos_e)
                time_exp=gsub(",",".",time_exp)
                if(is.na(as.numeric(time_exp))){
                  browser()
                }
                time=(coal_time[(M-j),(i-start_i+bonus)])+as.numeric(time_exp)
                time=gsub(".",",",as.character(time), fixed = TRUE)

                new_ind=paste(id_split[(M-j),(i-start_i+bonus)],":",time,sep="")
                if(nchar(new_ind)<4){
                  browser()
                }
              }
              if(length(truc_expr[which(truc_expr>=id1_s&truc_expr<pos_e)])>2){
                browser()
              }

              #genealogy=paste(substr(genealogy,1,as.numeric(truc_expr[max(which(truc_expr<id1_s))]-3)),new_ind,substr(genealogy,(pos_e+1),nchar(genealogy)),sep = "")
              #browser()
              if(j_ad>0){
                # browser()
              }
              genealogy=paste(substr(genealogy,1,(max(as.numeric(gregexpr(genealogy,pattern = "\\(")[[1]][which(as.numeric(gregexpr(genealogy,pattern = "\\(")[[1]])<as.numeric(truc_expr[max(which(truc_expr<id1_s))]))]))-1)),new_ind,substr(genealogy,(pos_e+1),nchar(genealogy)),sep = "")

            }
            if(any(is.na(as.numeric(coal_time[,(i-start_i+bonus)])))){
              browser()
            }
            j=j+j_ad
          }
        }else{
          stop('Problem in data')
        }



      }
      if(length(data[[i]])>0){
        if(data[[i]]=="//"){
          start=TRUE
          start_i=i
        }
      }
    }



  }
  if(simulator=="scrm"){
    coal_time[1:(M-1),]= 2*as.numeric(coal_time[1:(M-1),])
  }
  if(simulator=="msprime"){
    coal_time[1:(M-1),]=as.numeric(coal_time[1:(M-1),])/(Ne)#
    coal_time[M,]=round(as.numeric(coal_time[M,]))
  }
  Output$Coal_time=coal_time
  Output$id_split=id_split
  Output$id_create=id_create
  Output=purge_gen(Output)
  return(Output)
}
