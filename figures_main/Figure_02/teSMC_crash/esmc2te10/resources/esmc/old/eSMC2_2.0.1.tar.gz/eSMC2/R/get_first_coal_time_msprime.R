#' Extract the first coalescent time from a .txt file containing genealogies outputed by msprime
#' @param path : path to the file
#' @param mut : TRUE if mutation were simulated
#' @export
#' @return A list of size 2, first the theta waterson and  second a matrix of 2 lines containing the coalescent time and the sequence length of the genealogy
get_first_coal_time_msprime<-function(path,mut=T){
  DNAfile=Get_data(path)
  theta=NA
  DNA=matrix(0,ncol=length(DNAfile),nrow=2)
  start=1
  if(mut==T){
    start=2
    theta=as.numeric(substr(DNAfile[[1]][2],6,nchar(DNAfile[[1]][2])))
    if(is.na(theta)){
      browser()
    }
  }

  for(i in start:length(DNAfile)){
    data=DNAfile[[i]][1]
    pos_time=which(strsplit(data, "")[[1]]=="e")
    DNA[1,i]=as.numeric(substr(data,pos_time+1,nchar(data)))
    DNA[2,i]=round(as.numeric(substr(data,1,pos_time-5)))

  }
  DNA=DNA[,-1]
  if(!is.null(dim(DNA))){
    pos_0=which(DNA[2,]==0)
  }else{
    DNA=cbind(DNA,DNA)
    DNA[2,1]= DNA[2,1]-1
    DNA[2,2]= 1
    pos_0=c()
  }

  if(length(pos_0)>0){
    DNA=DNA[,-pos_0]
  }
  #diff_check=which(c(DNA[1:(dim(DNA)[2]-1)]-DNA[2:(dim(DNA)[2])])==0)
  output=list()
  output$DNA=DNA
  output$theta=theta
  return(output)
}
