#' Runs the baum-welch algorithm to estimate demographic history, germination , self-fertilization  and recombinationn rate
#'
#' @param Os : list containing the signal of all analysis
#' @param maxIt : number of expectation and maximization iteration
#' @param L : Sequence length
#' @param mu : estimated mutation rate given prior
#' @param theta_W : average theta waterson per chromosome
#' @param Rho : vector of estimated recombination rate per sequence
#' @param beta : germination rate
#' @param Popfix : True if population size is assumed constant
#' @param SB : True to estimate germination rate in time, set to 2 to estimate the transition time from the current germination rate to the ancestral one (Cf BoxB)
#' @param k : number of hidden states
#' @param BoxB : boundaries of the germination rate ( first value must be  bigger than 0), or vector of size 2 indicating the current dormancy rate and the ancestral one if SB=2 e.g. c(0.1,1) for a current seed bank of 10 generation with ancestral state being absence of dormancy
#' @param BoxP : logarithmic boundaries in base 10 for the  demography e.g. c(3,3) means the  population size can grow up to a thousand time  and decrease up to a thousand time
#' @param Boxr : logarithmic boundaries in base 10 for the  recombination rate e.g. c(1,1) means the recombination rate can be up to ten times smaller or bigger than the initial given value. Or a vector of size 2 indicating the current r/mu rate and the ancestral r/mu if ER=2.  e.g. c(0.1,1) for a current r/mu of 0.1 and an ancestral state being r/mu=1
#' @param maxBit :  number of run of the  baum-welch algorithm (each time using as prior result from precedent run)
#' @param pop_vect :  vector of hidden states sharing population size parameter (sum must be equal to k).
#' @param window_scaling : numerical vector of size 2. Time window is divided by first value, and second value is added to time window to shift it in past or present
#' @param sigma : self-fertilization rate
#' @param SF : True to estimate Self-fertilization rate, set to 2 to estimate the transition time from the current selfing rate to the ancestral one (Cf Boxs)
#' @param Boxs : boundaries for the self-fertilization rate e.g. c(0.5,0.9) means the selfing rate is between 0.5 and 0.9. Or vector of size 2 indicating the current selfing rate and the ancestral one if SF=2 e.g. c(0.99,0) for a current selfing rate of 99\% and with ancestral state being absence of selfing
#' @param ER : True to estimate recombination rate, set to 2 to estimate the transition time from the current r/mu rate to the ancestral one (Cf Boxr)
#' @param BW : True to run complete baum-welch implementation
#' @param NC : Number of different chromosome or scaffold analyzed
#' @param redo_R : True to reestimation recombination rate if no convergence reached
#' @param mu_b : ratio of mutation rate in seed bank over mutation rate during sexual event.
#' @param Big_Window : TRUE to use MSMC2 time window (bigger), 2 for an extremely big time window, 3 for a window focusing the past and 4 for a time window focusing on recent time.
#' @param LH_opt : TRUE to directly maximize the likelihood (can be very slow)
#' @param matrix_param : List of vector size 2 indicating the relative weight of the matrix compare to the likelihood and the window length. The list length correspond to the number of extra matrices added.
#' @param X_star : sequence of expected coalescence time
#' @param hs_vect : list of hidden state to bind  for the extra matrix
#' @return List containing of all model parameters.
Baum_Welch_algo_t<-function(Os, maxIt =20,L,mu,theta_W,Rho,beta=1,Popfix=T,SB=F,k=40,BoxB=c(0.1,1),BoxP=c(3,3),Boxr=c(1,1),maxBit=1,pop_vect=NA,window_scaling=c(1,0),sigma=0.00,SF=F,Boxs=c(0,0.97),ER=F,BW=F,NC=1,redo_R=F,mu_b=1,Big_Window=F,LH_opt=F,matrix_param=NA,X_star=NA,hs_vect=NA){
  Xi=NA
  FS=F
  SCALED=F
  cut_edge=F
  if(ER==2){

    if(Boxr[1]>Boxr[2]){
      Boxr[1]=log10(Boxr[1]/Boxr[2])
      Boxr[2]=0
      Boxr_s=c(1,0)
    }else{
      Boxr[1]=0
      Boxr[2]=log10(Boxr[1]/Boxr[2])
      Boxr_s=c(0,1)
    }

  }
  if(SB==2){
    if(BoxB[1]>BoxB[2]){
      BoxB_s=c(1,0)
    }else{
      BoxB_s=c(0,1)
    }
    BoxB=c(min(BoxB),max(BoxB))
  }
  if(SF==2){
    if(Boxs[1]>Boxs[2]){
      Boxs_s=c(1,0)
    }else{
      Boxs_s=c(0,1)
    }
    Boxs=c(min(Boxs),max(Boxs))
  }
  if(ER==3){
    Boxr_1=Boxr[[1]]
    Boxr_1=c(abs(log10(Boxr_1[1]/gamma)),abs(log10(Boxr_1[2]/gamma)))
    Boxr_2=Boxr[[2]]
    gamma_2=mean(Boxr_2)
    correct_R=gamma_2/gamma
    Boxr_2=c(abs(log10(Boxr_2[1]/gamma_2)),abs(log10(Boxr_2[2]/gamma_2)))
    Boxr_s=c((Boxr_1[1]/sum(Boxr_1)),(Boxr_2[1]/sum(Boxr_2)))

  }
  if(SB==3){
    BoxB_1=c(min(BoxB[[1]]),max(BoxB[[1]]))
    BoxB_2=c(min(BoxB[[3]]),max(BoxB[[3]]))
    BoxB_s=c(1,1)
  }
  if(SF==3){

    Boxs_1=c(min(Boxs[[1]]),max(Boxs[[1]]))
    Boxs_2=c(min(Boxs[[2]]),max(Boxs[[2]]))
    Boxs_s=c(0,0)
  }

  print(paste("sequence length :",L,sep=" "))
  if(length(Rho)>1&length(Rho)!=NC){
    stop("Problem in recombination definition")
  }
  old_list=list()
  n <- length(Os[[1]][[1]]);
  Pop=Popfix
  theta=mu*2*L
  gamma=Rho/theta
  if(NC>1&length(Rho)==1){
    Rho=rep(Rho,NC)
  }

  gamma_o=gamma
  print(gamma)
  test.env <- new.env()
  test.env$L <- L
  test.env$X_star <- X_star
  test.env$matrix_param <- matrix_param
  test.env$k <- k
  test.env$hs_vect <- hs_vect
  test.env$mu <- mu
  test.env$Rho <- Rho
  test.env$window_scaling <- window_scaling
  test.env$BW<-BW
  test.env$Pop<-Popfix
  test.env$NC<-NC
  test.env$FS<-FS
  test.env$mu_b <- mu_b
  test.env$Big_Window <- Big_Window
  if(ER==2){
    test.env$Boxr_s <- Boxr_s
  }
  if(SB==2){
    test.env$BoxB_s <- BoxB_s
  }
  if(SF==2){
    test.env$Boxs_s <- Boxs_s
  }
  if(ER==3){
    test.env$Boxr_s <- Boxr_s
    test.env$Boxr_1 <- Boxr_1
    test.env$Boxr_2 <- Boxr_2
    test.env$correct_R <- correct_R
  }
  if(SB==3){
    test.env$BoxB_s <- BoxB_s
    test.env$BoxB_1 <- BoxB_1
    test.env$BoxB_2 <- BoxB_2
  }
  if(SF==3){
    test.env$Boxs_s <- Boxs_s
    test.env$Boxs_1 <- Boxs_1
    test.env$Boxs_2 <- Boxs_2
  }
  if(NC>1){
    npair=NC
    test.env$npair <- NC
  }
  if(NC==1){
    npair=length(Os)
    test.env$npair <- length(Os)
  }
  mb=0
  if(any(!is.na(pop_vect))){
    Klink=length(pop_vect)
  }
  if((all(is.na(pop_vect))|sum(pop_vect)!=k)){
    Klink=0.5*k
    pop_vect=rep(2, Klink)
    print("Default pop discretizaion vector")
  }
  test.env$Klink <- Klink
  test.env$pop_vect <- pop_vect
  if(SB==1){
    BoxB[1]=max(sqrt(0.01),sqrt(BoxB[1]))
    BoxB[2]=min(sqrt(1),sqrt(BoxB[2]))
    if(length(beta)==1){

      beta=max((BoxB[1]),beta)
      beta=min(beta,(BoxB[2]))
      Beta=beta
      beta=rep(beta,length(pop_vect))
    }else{
      if(length(beta)==length(pop_vect)){
        for(bb in 1:length(beta)){

        beta[bb]=max((BoxB[1]),beta[bb])
        beta[bb]=min(beta[bb],(BoxB[2]))
        }
        Beta=mean(beta)
      }

      }
  }
  if(SB==2){
    if(BoxB_s[1]==0){
      beta=c(rep(BoxB[(BoxB_s[1]+1)],(length(pop_vect)-1)),BoxB[(BoxB_s[2]+1)])
      oldtb=length(pop_vect)
    }else{
      beta=c(BoxB[(BoxB_s[1]+1)],rep(BoxB[(BoxB_s[2]+1)],(length(pop_vect)-1)))
      oldtb=1
    }

    Beta=max(BoxB)
    BoxB[1]=max(sqrt(0.01),sqrt(BoxB[1]))
    BoxB[2]=min(sqrt(1),sqrt(BoxB[2]))

  }
  if(SB==3){

    bb=0
    sum_h=0
    while (sum_h<(k/2)){
      bb=bb+1
      sum_h=sum(pop_vect[1:bb])
    }

    oldtb=bb
    test.env$t_b <- oldtb
    beta=c(rep(max(BoxB_1),(bb-1)),rep(max(BoxB_2),Klink-bb+1))
    Beta=max(BoxB_1)
    BoxB_1[1]=max(sqrt(0.01),sqrt(BoxB_1[1]))
    BoxB_1[2]=min(sqrt(1),sqrt(BoxB_1[2]))
    BoxB_2[1]=max(sqrt(0.01),sqrt(BoxB_2[1]))
    BoxB_2[2]=min(sqrt(1),sqrt(BoxB_2[2]))
  }
  if(SF==1){
    if(length(sigma)==1){
    sigma=min(Boxs[2],sigma)
    sigma=max(sigma,Boxs[1])
    Self=sigma
    sigma=rep(sigma,length(pop_vect))
    }else{
      if(length(sigma)==length(pop_vect)){
      for(ss in 1:length(sigma)){
        sigma[ss]=min(Boxs[2],sigma[ss])
        sigma[ss]=max(sigma[ss],Boxs[1])
      }
      Self=mean(sigma)
    }
    }

  }
  if(SF==2){
    if(Boxs[(Boxs_s[1]+1)]==0){
      sigma=c(rep(Boxs[(Boxs_s[1]+1)],(length(pop_vect)-1)),Boxs[(Boxs_s[2]+1)])
      oldts=length(pop_vect)
    }else{
      sigma=c(Boxs[(Boxs_s[1]+1)],rep(Boxs[(Boxs_s[2]+1)],(length(pop_vect)-1)))
      oldts=1
    }

    #Self=sigma[1]
    Self=min(Boxs)
  }
  if(SF==3){

    bb=0
    sum_h=0
    while (sum_h<(k/2)){
      bb=bb+1
      sum_h=sum(pop_vect[1:bb])
    }
    oldts=bb
    test.env$t_s <- oldts
    Self=min(Boxs[[1]])
    sigma=c(rep(min(Boxs_1),(bb-1)),rep(min(Boxs_2),Klink-bb+1))
  }
  if(ER==1){
    oldrho=rep((Boxr[1]/sum(Boxr)),length(pop_vect))
    if(NC>1){
      oldrho=list()
      for(rr in 1:NC){
        oldrho[[rr]]=rep((Boxr[1]/sum(Boxr)),length(pop_vect))
      }
    }

  }
  if(ER==0){
    Boxr=c(0,0)
  }
  if(ER==2){
    oldrho=c(rep(Boxr_s[1],(length(pop_vect)-1)),Boxr_s[2])
    if(NC>1){
      oldrho=list()
      for(rr in 1:NC){
        oldrho[[rr]]=c(rep(Boxr_s[1],(length(pop_vect)-1)),Boxr_s[2])
      }
    }

  }
  if(ER==3){
    bb=0
    sum_h=0
    while (sum_h<(k/2)){
      bb=bb+1
      sum_h=sum(pop_vect[1:bb])
    }
    oldtr=bb
    test.env$t_r <- oldtr
    oldrho=c(rep(Boxr_s[1],(oldtr-1)),rep(Boxr_s[2],(Klink-oldtr+1)))
    if(NC>1){
      oldrho=list()
      for(rr in 1:NC){
        oldrho[[rr]]=c(rep(Boxr_s[1],(oldtr-1)),rep(Boxr_s[2],(Klink-oldtr+1)))
      }
    }

  }
  if(SB==0&SF==0){
    maxBit=1
  }
  if(SB==0){
    Beta=beta
    test.env$beta <- beta
  }
  if(SF==0){
    Self=sigma
    oldSelf=Self
    test.env$sigma <- sigma
  }
  if(ER==0){
    oldrho=rep(0,Klink)
    if(NC>1){
      oldrho=list()
      for(chr in 1:chr){
        oldrho[[chr]]=rep(0,Klink)
      }

    }
  }
  while(mb<maxBit){
    print(paste("Beta:",Beta))
    print(paste("Self:",Self))
    test.env$Beta <- Beta
    test.env$Self <- Self
    test.env$BoxB <- BoxB
    test.env$Boxs <- Boxs
    test.env$Boxr <- Boxr
    mb=mb+1
    diff=1
    it <- 0
    if(mb==1){
      if(SB>0&SB<3){
        oldbeta=(sqrt(beta)-BoxB[1])/(BoxB[2]-BoxB[1])
      }
      if(SB==3){
        if(oldtb>Klink){
          oldbeta=(sqrt(beta)-BoxB_1[1])/(BoxB_1[2]-BoxB_1[1])
        }else{
          if(oldtb>1){
            oldbeta=c((sqrt(beta[1:(oldtb-1)])-BoxB_1[1])/(BoxB_1[2]-BoxB_1[1]),(sqrt(beta[oldtb:Klink])-BoxB_2[1])/(BoxB_2[2]-BoxB_2[1]))
          }else{
            oldbeta=(sqrt(beta)-BoxB_2[1])/(BoxB_2[2]-BoxB_2[1])
          }
        }
      }
      if(SF>0&SF<3){
        oldsigma=(sigma-Boxs[1])/(Boxs[2]-Boxs[1])
      }
      if(SF==3){
        if(oldts>Klink){
          oldsigma=(sigma-Boxs_1[1])/(Boxs_1[2]-Boxs_1[1])
        }else{
          if(oldts>1){
            oldsigma= c( ((sigma[1:(oldts-1)]-Boxs_1[1])/(Boxs_1[2]-Boxs_1[1])), ((sigma[oldts:Klink]-Boxs_2[1])/(Boxs_2[2]-Boxs_2[1])))
          }else{
            oldsigma=(sigma-Boxs_2[1])/(Boxs_2[2]-Boxs_2[1])
          }
        }
        print(oldsigma)
      }
      if(ER>1){
        bb=0
        sum_h=0
        while (sum_h<(k/2)){
          bb=bb+1
          sum_h=sum(pop_vect[1:bb])
        }
        oldtr=bb
      }
    }
    if(mb>1){


      if(!Popfix){
        xx=0
        for(ix in 1:Klink){
          x=xx+1
          xx = xx + pop_vect[ix]
          oldXi[x:xx]=oldXi_[ix]
        }
        Xi_=oldXi*sum(BoxP)
        Xi_=Xi_-(BoxP[1])
        Xi_=10^Xi_
      }
      if(NC==1){
        theta=(((theta_W*(Beta^2)))*2/((2-Self)*(Beta+((1-Beta)*mu_b))))
        mu=theta/(2*L)
        Rho=gamma*theta
      }
      if(NC>1){
        theta=mean(theta_W/(2*L))
        mu=(((theta*(Beta^2)))*2/((2-Self)*(Beta+((1-Beta)*mu_b))))
        Rho=gamma*theta*2*L
      }
      test.env$mu <- mu
      test.env$Rho <- Rho
    }
    if(ER==0){
      oldrho=rep(0,Klink)
      if(NC>1){
        oldrho=list()
        for(chr in 1:chr){
          oldrho[[chr]]=rep(0,Klink)
        }
      }
    }
    if(ER==1){
      oldrho=rep((Boxr[1]/sum(Boxr)),length(pop_vect))
      if(NC>1){
        oldrho=list()
        for(rr in 1:NC){
          oldrho[[rr]]=rep((Boxr[1]/sum(Boxr)),length(pop_vect))
        }
      }

    }
    if(ER>1&ER<3){
      oldrho=c(rep(Boxr_s[1],(length(pop_vect)-1)),Boxr_s[2])
      if(NC>1){
        oldrho=list()
        for(rr in 1:NC){
          oldrho[[rr]]=c(rep(Boxr_s[1],(length(pop_vect)-1)),Boxr_s[2])
        }
      }

    }
    if(ER==3){

      if(oldtr>Klink){
        oldrho=rep(Boxr_s[1],Klink)
      }else{
        if(oldtr>1){
          oldrho=c(rep(Boxr_s[1],oldtr-1),rep(Boxr_s[2],(Klink+1-oldtr)))
        }else{
          oldrho=rep(Boxr_s[2],Klink)
        }
      }

      if(NC>1){
        oldrho=list()
        for(rr in 1:NC){
          if(oldtr>Klink){
            oldrho[[rr]]=rep(Boxr_s[1],Klink)
          }else{
            if(oldtr>1){
              oldrho[[rr]]=c(rep(Boxr_s[1],oldtr-1),rep(Boxr_s[2],(Klink+1-oldtr)))
            }else{
              oldrho[[rr]]=rep(Boxr_s[2],Klink)
            }
          }

        }
      }
    }
    oldXi_=rep((BoxP[1]/sum(BoxP)),Klink)
    oldXi=vector()
    xx=0
    for(ix in 1:Klink){
      x=xx+1
      xx = xx + pop_vect[ix]
      oldXi[x:xx]=oldXi_[ix]
    }


    diff_conv=vector()

    if(!LH_opt){

      while (it<maxIt){
        start_time <- Sys.time()
        Do_BW=T
        print(paste("maxIt:",maxIt))
        it <- it+1;
        print(paste("It:",it))



        if(max(c(ER,SB,SF))<2){



          if(Popfix){
            if(!is.list(oldrho)){
              rho_=oldrho*sum(Boxr)
              rho_=rho_-(Boxr[1])
              rho_=10^(rho_)
              rho_=rho_*Rho
              rho=vector()
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                rho[x:xx]= rho_[ix]
              }
            }else{
              rho_=list()
              rho=list()
              for(rr in 1:NC){
                rho_[[rr]]=oldrho[[rr]]*sum(Boxr)
                rho_[[rr]]=rho_[[rr]]-(Boxr[1])
                rho_[[rr]]=10^(rho_[[rr]])
                rho_[[rr]]=rho_[[rr]]*Rho[rr]

                xx=0
                rho[[rr]]=vector()
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  rho[[rr]][x:xx]= rho_[[rr]][ix]
                }
              }

            }

            if(SB>0){
              beta_=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1] )^2
              beta=vector()
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                beta[x:xx]=beta_[ix]
              }
            }
            if(SF>0){
              sigma_=oldsigma*(Boxs[2]-Boxs[1])
              sigma_=sigma_+Boxs[1]
              sigma=vector()
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                sigma[x:xx]= sigma_[ix]
              }
            }
            print(c("sigma:",sigma,"beta :",beta))
            if(is.list(rho_)){
              print(c("rho/theta:",rho_[[1]]/theta))
            }else{
              print(c("rho/theta:",rho_/theta))
            }

            Keep_going=F
            if(it==1){
              diff_o=0
            }
            if(it>1){
              if(SF==1){
                diff_o=mean(abs(sigma_o-sigma))
              }
              if(SF==2){
                diff_o=0.0001
              }
              if(SB==1){
                diff_o=max(diff_o,mean(abs(beta_o-beta)))
              }
              if(SB==2){
                diff_o=max(diff_o,0.0001)
              }
              count_diff_o=0
              if(diff_o>=0.005){
                if(it==maxIt){
                  count_diff_o=count_diff_o+1
                  maxIt=maxIt+1
                  if(count_diff_o>10){
                    maxBit=maxBit-1
                  }
                }
              }
            }
            sigma_o=sigma
            beta_o=beta



            if(NC==1){
              builder=build_HMM_matrix_t(k,(rho),beta=beta,L=L,Pop=Pop,Xi=NA,Beta=Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
            }
            if(NC>1){
              builder=list()
              for(chr in 1:NC){
                builder[[chr]]=build_HMM_matrix_t(k,(rho[[chr]]),beta=beta,L=L[chr],Pop=Pop,Xi=NA,Beta=Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
              }
            }
          }
          if(!Popfix){
            xx=0
            for(ix in 1:Klink){
              x=xx+1
              xx = xx + pop_vect[ix]
              oldXi[x:xx]=oldXi_[ix]
            }
            Xi_=oldXi*sum(BoxP)
            Xi_=Xi_-(BoxP[1])
            Xi_=10^Xi_
            if(!is.list(oldrho)){
              rho_=oldrho*sum(Boxr)
              rho_=rho_-(Boxr[1])
              rho_=10^(rho_)
              rho_=rho_*Rho
              rho=vector()
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                rho[x:xx]= rho_[ix]
              }
            }else{
              rho_=list()
              rho=list()
              for(rr in 1:NC){
                rho_[[rr]]=oldrho[[rr]]*sum(Boxr)
                rho_[[rr]]=rho_[[rr]]-(Boxr[1])
                rho_[[rr]]=10^(rho_[[rr]])
                rho_[[rr]]=rho_[[rr]]*Rho[rr]
                rho[[rr]]=vector()
                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  rho[[rr]][x:xx]= rho_[[rr]][ix]
                }
              }

            }
            if(SB>0){
              beta_=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1] )^2
              beta=vector()
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                beta[x:xx]=beta_[ix]
              }
            }
            if(SF>0){
              sigma_=oldsigma*(Boxs[2]-Boxs[1])
              sigma_=sigma_+Boxs[1]
              sigma=vector()
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                sigma[x:xx]= sigma_[ix]
              }
            }
            print(c("sigma:",sigma,"beta :",beta))
            Keep_going=F
            if(it==1){
              diff_o=0
            }
            if(it>1){
              if(SF==1){
                diff_o=mean(abs(sigma_o-sigma))
              }
              if(SF==2){
                diff_o=0.0001
              }
              if(SB==1){
                diff_o=max(diff_o,mean(abs(beta_o-beta)))
              }
              if(SB==2){
                diff_o=max(diff_o,0.0001)
              }
              count_diff_o=0
              if(diff_o>=0.005){
                if(it==maxIt){
                  count_diff_o=count_diff_o+1
                  maxIt=maxIt+1
                  if(count_diff_o>10){
                    maxBit=maxBit-1
                  }
                }
              }
            }
            sigma_o=sigma
            beta_o=beta
            # browser()
            if(NC==1){
              builder=build_HMM_matrix_t(k,(rho),beta=beta,L=L,Pop=Pop,Xi_,Beta=Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
            }
            if(NC>1){
              builder=list()
              for(chr in 1:NC){
                builder[[chr]]=build_HMM_matrix_t(k,(rho[[chr]]),beta=beta,L=L[chr],Pop=Pop,Xi_,Beta=Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
              }
            }
          }
          if(ER>1){
            oldtr_s=oldtr
          }
          if(SF>1){
            oldts_s=oldts
          }
          if(SB>1){
            oldtb_s=oldtb
          }
          if(!Popfix){
            oldXi_s=oldXi_
          }
          if(ER>0){
            oldrho_s=oldrho
          }
          if(SB>0){
            oldbeta_s=oldbeta
          }
          if(SF>0){
            oldsigma_s=oldsigma
          }

          if(NC==1){

            if(it==1){

              test.env$ER <- ER
              test.env$SF <- SF
              test.env$SB <- SB
              test.env$Os <- Os



              function_to_minimize<-function(param){
                Boxr=get('Boxr', envir=test.env)
                mu=get('mu', envir=test.env)
                npair=get('npair', envir=test.env)
                Big_Window=get('Big_Window', envir=test.env)
                mu_b=get('mu_b', envir=test.env)
                FS=get('FS', envir=test.env)
                Klink=get('Klink', envir=test.env)
                Rho=get('Rho', envir=test.env)
                BoxB=get('BoxB', envir=test.env)
                Boxs=get('Boxs', envir=test.env)
                BoxP=get('BoxP', envir=test.env)
                pop_vect=get('pop_vect', envir=test.env)
                L=get('L', envir=test.env)
                n=get('k', envir=test.env)
                Beta=get('Beta', envir=test.env)
                Self=get('Self', envir=test.env)
                window_scaling=get('window_scaling', envir=test.env)
                Pop=get('Pop', envir=test.env)
                ER=get('ER', envir=test.env)
                SF=get('SF', envir=test.env)
                SB=get('SB', envir=test.env)
                Os=get('Os', envir=test.env)
                start_position=0
                if(ER==1){
                  rho_=numeric(n)
                  rho=param[(start_position+1):(start_position+Klink)]
                  rho=rho*sum(Boxr)
                  rho=rho-(Boxr[1])
                  rho=10^(rho)
                  rho=rho*Rho
                  start_position=start_position+Klink
                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    rho_[x:xx]=rho[ix]

                  }

                }
                if(ER==2){
                  t_r=get('t_r', envir=test.env)
                  Boxr_s=get('Boxr_s', envir=test.env)
                  rho_=numeric(n)
                  #t_r=min(ceiling(param[(start_position+1)]*Klink),Klink)


                  if(t_r>Klink){

                    rho=rep(Boxr_s[1],Klink)
                  }else{
                    if(t_r>1){
                      rho=c(rep(Boxr_s[1],(t_r-1)),rep(Boxr_s[2],(Klink-t_r+1)))
                    }else{
                      rho=rep(Boxr_s[2],Klink)
                    }
                  }
                  rho=rho*sum(Boxr)
                  rho=rho-(Boxr[1])
                  rho=10^(rho)
                  rho=rho*Rho


                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    rho_[x:xx]=rho[ix]

                  }
                }
                if(ER==3){
                  t_r=get('t_r', envir=test.env)
                  Boxr_s=get('Boxr_s', envir=test.env)
                  Boxr_1=get('Boxr_1', envir=test.env)
                  Boxr_2=get('Boxr_2', envir=test.env)
                  correct_R=get('correct_R', envir=test.env)
                  rho_=numeric(n)
                  #t_r=min(ceiling(param[(start_position+1)]*Klink),Klink)


                  if(t_r>Klink){

                    rho=rep(Boxr_s[1],Klink)
                    rho=rho*sum(Boxr_1)
                    rho=rho-(Boxr_1[1])
                    rho=10^(rho)
                    rho=rho*Rho
                  }else{
                    if(t_r>1){
                      rho=c(rep(Boxr_s[1],(t_r-1)),rep(Boxr_s[2],(Klink-t_r+1)))
                      rho=c(rho[1:(t_r-1)]*sum(Boxr_1),rho[t_r:Klink]*sum(Boxr_2))
                      rho=c(rho[1:(t_r-1)]-(Boxr_1[1]),rho[t_r:Klink]-(Boxr_2[1]))
                      rho=10^(rho)
                      rho=c(rho[1:(t_r-1)]*Rho,rho[t_r:Klink]*Rho*correct_R)
                    }else{
                      rho=rep(Boxr_s[2],Klink)
                      rho=rho*sum(Boxr_2)
                      rho=rho-(Boxr_2[1])
                      rho=10^(rho)
                      rho=rho*Rho*correct_R
                    }
                  }
                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    rho_[x:xx]=rho[ix]

                  }
                }
                if(ER==0){
                  rho_=rep(Rho,n)
                }
                if(SF==1){
                  sigma_=numeric(n)
                  sigma=param[(start_position+1):(start_position+Klink)]
                  start_position=start_position+Klink
                  sigma=sigma*(Boxs[2]-Boxs[1])
                  sigma=sigma+Boxs[1]
                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    sigma_[x:xx]=sigma[ix]
                  }
                }
                if(SF==2){
                  Boxs_s=get('Boxs_s', envir=test.env)
                  sigma_=numeric(n)

                  #t_s=min(ceiling(param[(start_position+1)]*Klink),Klink)
                  t_s=get('t_s', envir=test.env)
                  if(t_s>Klink){
                    sigma=rep(Boxs_s[1],Klink)
                  }else{
                    if(t_s>1){
                      sigma=c(rep(Boxs_s[1],(t_s-1)),rep(Boxs_s[2],(Klink-t_s+1)))
                    }else{
                      sigma=rep(Boxs_s[2],Klink)
                    }
                  }
                  #start_position=start_position+1
                  sigma=sigma*(Boxs[2]-Boxs[1])
                  sigma=sigma+Boxs[1]
                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    sigma_[x:xx]=sigma[ix]
                  }

                }
                if(SF==3){
                  Boxs_s=get('Boxs_s', envir=test.env)
                  Boxs_1=get('Boxs_1', envir=test.env)
                  Boxs_2=get('Boxs_2', envir=test.env)
                  sigma_=numeric(n)

                  t_s=get('t_s', envir=test.env)
                  if(t_s>Klink){
                    sigma=rep(Boxs_s[1],Klink)
                    sigma=sigma*(Boxs_1[2]-Boxs_1[1])
                    sigma=sigma+Boxs_1[1]
                  }else{
                    if(t_s>1){
                      sigma=c(rep(Boxs_s[1],(t_s-1)),rep(Boxs_s[2],(Klink-t_s+1)))
                      sigma= c(sigma[1:(t_s-1)]*(Boxs_1[2]-Boxs_1[1]),sigma[t_s:Klink]*(Boxs_2[2]-Boxs_2[1]) )
                      sigma= c(sigma[1:(t_s-1)]+Boxs_1[1],sigma[t_s:Klink]+Boxs_2[1])
                    }else{
                      sigma=rep(Boxs_s[2],Klink)
                      sigma=sigma*(Boxs_2[2]-Boxs_2[1])
                      sigma=sigma+Boxs_2[1]
                    }
                  }
                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    sigma_[x:xx]=sigma[ix]
                  }
                }
                if(SF==0){
                  sigma_=rep(sigma,n)
                }
                if(SB==1){
                  beta_=numeric(n)
                  beta=((param[(start_position+1):(start_position+Klink)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
                  start_position=start_position+(Klink)
                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    beta_[x:xx]=beta[ix]

                  }
                }
                if(SB==2){
                  beta_=numeric(n)
                  BoxB_s=get('BoxB_s', envir=test.env)
                  #t_b=min(ceiling(param[(start_position+1)]*Klink),Klink)
                  t_b=get('t_b', envir=test.env)
                  if(t_b>Klink){
                    beta=rep(BoxB_s[1],Klink)
                  }else{
                    if(t_b>1){
                      beta=c(rep(BoxB_s[1],(t_b-1)),rep(BoxB_s[2],(Klink-t_b+1)))
                    }else{
                      beta=rep(BoxB_s[2],Klink)
                    }
                  }

                  beta=((beta*(BoxB[2]-BoxB[1]))+BoxB[1])^2
                  # start_position=start_position+1
                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    beta_[x:xx]=beta[ix]

                  }
                }
                if(SB==3){
                  beta_=numeric(n)
                  BoxB_s=get('BoxB_s', envir=test.env)
                  BoxB_1=get('BoxB_1', envir=test.env)
                  BoxB_2=get('BoxB_2', envir=test.env)
                  t_b=get('t_b', envir=test.env)
                  if(t_b>Klink){
                    beta=rep(BoxB_s[1],Klink)
                    beta=((beta*(BoxB_1[2]-BoxB_1[1]))+BoxB_1[1])^2
                  }else{
                    if(t_b>1){
                      beta=c(rep(BoxB_s[1],(t_b-1)),rep(BoxB_s[2],(Klink-t_b+1)))
                      beta=c((((beta[1:(t_b-1)]*(BoxB_1[2]-BoxB_1[1]))+BoxB_1[1])^2),(((beta[t_b:Klink]*(BoxB_2[2]-BoxB_2[1]))+BoxB_2[1])^2))
                    }else{
                      beta=rep(BoxB_s[2],Klink)
                      beta=((beta*(BoxB_2[2]-BoxB_2[1]))+BoxB_2[1])^2
                    }
                  }


                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    beta_[x:xx]=beta[ix]

                  }
                }
                if(SB==0){
                  beta_=rep(beta,n)
                }
                if(!Pop){
                  Xi=numeric(n)
                  Xi_=param[(start_position+1):(start_position+Klink)]
                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    Xi[x:xx]=Xi_[ix]
                  }
                  Xi=Xi*sum(BoxP)
                  Xi=Xi-(BoxP[1])
                  Xi=10^Xi
                }else{
                  Xi=rep(1,n)
                }

                builder=build_HMM_matrix_t(n,rho_,beta=beta_,Pop = Pop,Xi=Xi,L=L,Beta=Beta,scale=window_scaling,sigma = sigma_,Sigma = Self,Big_Window=Big_Window,npair=npair)
                Q = builder[[1]]
                nu= builder[[2]]
                Tc=builder[[3]]
                g=build_emission_matrix(mu,mu_b,Tc=builder[[4]],t=builder[[3]],beta,FS)
                MLH=0
                test=Build_zip_Matrix_mailund(Q,g,Os[[1]][[2]],nu,do_all=F)
                for(i in 1:length(Os)){
                  fo=forward_zip_mailund(Os[[i]][[1]],g,nu,test[[1]])
                  MLH=MLH-fo[[3]]
                }
                return(MLH)
              }

              param=c()
              if(ER==1){
                param=c(param,oldrho)

              }

              if(SF==1){
                param=c(param,oldsigma)
              }

              if(SB==1){
                param=c(param,oldbeta)
              }

              if(!Popfix){
                param=c(param,oldXi_)
              }

              LH_temp=0


              if(ER==1){

                LH_temp=function_to_minimize(param)
                for(pos_param in 1:length(pop_vect)){

                UP=F

                if((oldrho[pos_param]+0.05)<1){
                  oldrho[pos_param]=oldrho[pos_param]+0.05

                  param=c()
                  if(ER==1){
                    param=c(param,oldrho)

                  }

                  if(SF==1){
                    param=c(param,oldsigma)
                  }

                  if(SB==1){
                    param=c(param,oldbeta)
                  }

                  if(!Popfix){
                    param=c(param,oldXi_)
                  }

                  LH_temp2=function_to_minimize(param)
                  if(LH_temp>LH_temp2){
                    UP=T
                    LH_temp=LH_temp2
                  }else{
                    oldrho[pos_param]=oldrho[pos_param]-0.05

                  }
                }

                if(UP){
                  while(UP){
                    if((oldrho[pos_param]+0.05)<1){
                      oldrho[pos_param]=oldrho[pos_param]+0.05

                      UP=F
                      param=c()
                      if(ER==1){
                        param=c(param,oldrho)

                      }

                      if(SF==1){
                        param=c(param,oldsigma)
                      }

                      if(SB==1){
                        param=c(param,oldbeta)
                      }

                      if(!Popfix){
                        param=c(param,oldXi_)
                      }

                      LH_temp2=function_to_minimize(param)
                      if(LH_temp>LH_temp2){
                        UP=T
                        LH_temp=LH_temp2
                      }else{
                        oldrho[pos_param]=oldrho[pos_param]-0.05

                      }
                    }else{
                      UP=F
                    }
                  }
                }else{
                  DOWN=F
                  if((oldrho[pos_param]-0.05)>0){
                    oldrho[pos_param]=oldrho[pos_param]-0.05


                    param=c()
                    if(ER==1){
                      param=c(param,oldrho)

                    }

                    if(SF==1){
                      param=c(param,oldsigma)
                    }

                    if(SB==1){
                      param=c(param,oldbeta)
                    }

                    if(!Popfix){
                      param=c(param,oldXi_)
                    }

                    LH_temp2=function_to_minimize(param)
                    if(LH_temp>LH_temp2){
                      DOWN=T
                      LH_temp=LH_temp2
                    }else{
                      oldrho[pos_param]=oldrho[pos_param]+0.05

                    }
                  }
                  while(DOWN){
                    if((oldrho[pos_param]-0.05)>0){
                      oldrho[pos_param]=oldrho[pos_param]-0.05

                      DOWN=F
                      param=c()
                      if(ER==1){
                        param=c(param,oldrho)

                      }

                      if(SF==1){
                        param=c(param,oldsigma)
                      }

                      if(SB==1){
                        param=c(param,oldbeta)
                      }

                      if(!Popfix){
                        param=c(param,oldXi_)
                      }
                      LH_temp2=function_to_minimize(param)
                      if(LH_temp>LH_temp2){
                        DOWN=T
                        LH_temp=LH_temp2
                      }else{
                        oldrho[pos_param]=oldrho[pos_param]+0.05

                      }
                    }else{
                      DOWN=F
                    }
                  }
                }


                }




              }

              if(SF==1){
                LH_temp=function_to_minimize(param)
                for(pos_param in 1:length(pop_vect)){

                  UP=F

                  if((oldsigma[pos_param]+0.05)<1){
                    oldsigma[pos_param]=oldsigma[pos_param]+0.05

                    param=c()
                    if(ER==1){
                      param=c(param,oldrho)

                    }

                    if(SF==1){
                      param=c(param,oldsigma)
                    }

                    if(SB==1){
                      param=c(param,oldbeta)
                    }

                    if(!Popfix){
                      param=c(param,oldXi_)
                    }

                    LH_temp2=function_to_minimize(param)
                    if(LH_temp>LH_temp2){
                      UP=T
                      LH_temp=LH_temp2
                    }else{
                      oldsigma[pos_param]=oldsigma[pos_param]-0.05

                    }
                  }

                  if(UP){
                    while(UP){
                      if((oldsigma[pos_param]+0.05)<1){
                        oldsigma[pos_param]=oldsigma[pos_param]+0.05

                        UP=F
                        param=c()
                        if(ER==1){
                          param=c(param,oldrho)

                        }

                        if(SF==1){
                          param=c(param,oldsigma)
                        }

                        if(SB==1){
                          param=c(param,oldbeta)
                        }

                        if(!Popfix){
                          param=c(param,oldXi_)
                        }

                        LH_temp2=function_to_minimize(param)
                        if(LH_temp>LH_temp2){
                          UP=T
                          LH_temp=LH_temp2
                        }else{
                          oldsigma[pos_param]=oldsigma[pos_param]-0.05

                        }
                      }else{
                        UP=F
                      }
                    }
                  }else{
                    DOWN=F
                    if((oldsigma[pos_param]-0.05)>0){
                      oldsigma[pos_param]=oldsigma[pos_param]-0.05


                      param=c()
                      if(ER==1){
                        param=c(param,oldrho)

                      }

                      if(SF==1){
                        param=c(param,oldsigma)
                      }

                      if(SB==1){
                        param=c(param,oldbeta)
                      }

                      if(!Popfix){
                        param=c(param,oldXi_)
                      }

                      LH_temp2=function_to_minimize(param)
                      if(LH_temp>LH_temp2){
                        DOWN=T
                        LH_temp=LH_temp2
                      }else{
                        oldsigma[pos_param]=oldsigma[pos_param]+0.05

                      }
                    }
                    while(DOWN){
                      if((oldsigma[pos_param]-0.05)>0){
                        oldsigma[pos_param]=oldsigma[pos_param]-0.05

                        DOWN=F
                        param=c()
                        if(ER==1){
                          param=c(param,oldrho)

                        }

                        if(SF==1){
                          param=c(param,oldsigma)
                        }

                        if(SB==1){
                          param=c(param,oldbeta)
                        }

                        if(!Popfix){
                          param=c(param,oldXi_)
                        }
                        LH_temp2=function_to_minimize(param)
                        if(LH_temp>LH_temp2){
                          DOWN=T
                          LH_temp=LH_temp2
                        }else{
                          oldsigma[pos_param]=oldsigma[pos_param]+0.05

                        }
                      }else{
                        DOWN=F
                      }
                    }
                  }


                }

              }

              if(SB==1){
                LH_temp=function_to_minimize(param)
                for(pos_param in 1:length(pop_vect)){

                  UP=F

                  if((oldbeta[pos_param]+0.05)<1){
                    oldbeta[pos_param]=oldbeta[pos_param]+0.05

                    param=c()
                    if(ER==1){
                      param=c(param,oldrho)

                    }

                    if(SF==1){
                      param=c(param,oldsigma)
                    }

                    if(SB==1){
                      param=c(param,oldbeta)
                    }

                    if(!Popfix){
                      param=c(param,oldXi_)
                    }

                    LH_temp2=function_to_minimize(param)
                    if(LH_temp>LH_temp2){
                      UP=T
                      LH_temp=LH_temp2
                    }else{
                      oldbeta[pos_param]=oldbeta[pos_param]-0.05

                    }
                  }

                  if(UP){
                    while(UP){
                      if((oldbeta[pos_param]+0.05)<1){
                        oldbeta[pos_param]=oldbeta[pos_param]+0.05

                        UP=F
                        param=c()
                        if(ER==1){
                          param=c(param,oldrho)

                        }

                        if(SF==1){
                          param=c(param,oldsigma)
                        }

                        if(SB==1){
                          param=c(param,oldbeta)
                        }

                        if(!Popfix){
                          param=c(param,oldXi_)
                        }

                        LH_temp2=function_to_minimize(param)
                        if(LH_temp>LH_temp2){
                          UP=T
                          LH_temp=LH_temp2
                        }else{
                          oldbeta[pos_param]=oldbeta[pos_param]-0.05

                        }
                      }else{
                        UP=F
                      }
                    }
                  }else{
                    DOWN=F
                    if((oldbeta[pos_param]-0.05)>0){
                      oldbeta[pos_param]=oldbeta[pos_param]-0.05


                      param=c()
                      if(ER==1){
                        param=c(param,oldrho)

                      }

                      if(SF==1){
                        param=c(param,oldsigma)
                      }

                      if(SB==1){
                        param=c(param,oldbeta)
                      }

                      if(!Popfix){
                        param=c(param,oldXi_)
                      }

                      LH_temp2=function_to_minimize(param)
                      if(LH_temp>LH_temp2){
                        DOWN=T
                        LH_temp=LH_temp2
                      }else{
                        oldbeta[pos_param]=oldbeta[pos_param]+0.05

                      }
                    }
                    while(DOWN){
                      if((oldbeta[pos_param]-0.05)>0){
                        oldbeta[pos_param]=oldbeta[pos_param]-0.05

                        DOWN=F
                        param=c()
                        if(ER==1){
                          param=c(param,oldrho)

                        }

                        if(SF==1){
                          param=c(param,oldsigma)
                        }

                        if(SB==1){
                          param=c(param,oldbeta)
                        }

                        if(!Popfix){
                          param=c(param,oldXi_)
                        }
                        LH_temp2=function_to_minimize(param)
                        if(LH_temp>LH_temp2){
                          DOWN=T
                          LH_temp=LH_temp2
                        }else{
                          oldbeta[pos_param]=oldbeta[pos_param]+0.05

                        }
                      }else{
                        DOWN=F
                      }
                    }
                  }


                }

              }

            }
          }

          if(NC>1){
            if(it==1){

              test.env$ER <- ER
              test.env$SF <- SF
              test.env$SB <- SB
              test.env$Os <- Os




              function_to_minimize<-function(param){
                Boxr=get('Boxr', envir=test.env)
                mu=get('mu', envir=test.env)
                npair=get('npair', envir=test.env)
                Big_Window=get('Big_Window', envir=test.env)
                mu_b=get('mu_b', envir=test.env)
                FS=get('FS', envir=test.env)
                Klink=get('Klink', envir=test.env)
                Rho=get('Rho', envir=test.env)
                BoxB=get('BoxB', envir=test.env)
                Boxs=get('Boxs', envir=test.env)
                BoxP=get('BoxP', envir=test.env)
                pop_vect=get('pop_vect', envir=test.env)
                L=get('L', envir=test.env)
                n=get('k', envir=test.env)
                Beta=get('Beta', envir=test.env)
                Self=get('Self', envir=test.env)
                window_scaling=get('window_scaling', envir=test.env)
                Pop=get('Pop', envir=test.env)
                ER=get('ER', envir=test.env)
                SF=get('SF', envir=test.env)
                SB=get('SB', envir=test.env)
                Os=get('Os', envir=test.env)
                NC=get('NC', envir=test.env)
                start_position=0
                if(ER==1){

                  rho=list()
                  rho_=list()
                  oldrho_param=param[(start_position+1):(start_position+(Klink*NC))]
                  for(rr in 1:NC){
                    rho[[rr]]= oldrho_param[(1+((rr-1)*Klink)):(rr*Klink)]*sum(Boxr)
                    rho[[rr]]=rho[[rr]]-(Boxr[1])
                    rho[[rr]]=10^(rho[[rr]])
                    rho[[rr]]=rho[[rr]]*Rho[rr]

                    xx=0
                    rho_[[rr]]=vector()
                    for(ix in 1:Klink){
                      x=xx+1
                      xx = xx + pop_vect[ix]
                      rho_[[rr]][x:xx]= rho[[rr]][ix]
                    }
                  }
                  start_position=start_position+(Klink*NC)
                }
                if(ER==2){

                  Boxr_s=get('Boxr_s', envir=test.env)

                  #t_r=min(ceiling(param[(start_position+1)]*Klink),Klink)
                  t_r=get('t_r', envir=test.env)

                  rho=list()
                  rho_=list()

                  for(rr in 1:NC){

                    if(t_r>Klink){
                      oldrho_param=rep(Boxr_s[1],Klink)
                    }else{
                      if(t_r>1){
                        oldrho_param=c(rep(Boxr_s[1],(t_r-1)),rep(Boxr_s[2],(Klink-t_r+1)))
                      }else{
                        oldrho_param=rep(Boxr_s[2],Klink)
                      }
                    }


                    rho[[rr]]= oldrho_param[(1+((rr-1)*Klink)):(rr*Klink)]*sum(Boxr)
                    rho[[rr]]=rho[[rr]]-(Boxr[1])
                    rho[[rr]]=10^(rho[[rr]])
                    rho[[rr]]=rho[[rr]]*Rho[rr]

                    xx=0
                    rho_[[rr]]=vector()
                    for(ix in 1:Klink){
                      x=xx+1
                      xx = xx + pop_vect[ix]
                      rho_[[rr]][x:xx]= rho[[rr]][ix]
                    }
                  }
                }
                if(ER==0){
                  rho_=list()
                  for(rr in 1:NC){
                    rho_[[rr]]=rep(Rho[rr],n)
                  }
                }
                if(ER==3){

                  Boxr_s=get('Boxr_s', envir=test.env)
                  Boxr_1=get('Boxr_1', envir=test.env)
                  Boxr_2=get('Boxr_2', envir=test.env)
                  correct_R=get('correct_R', envir=test.env)
                  t_r=get('t_r', envir=test.env)

                  rho=list()
                  rho_=list()

                  for(rr in 1:NC){

                    if(t_r>Klink){
                      oldrho_param=rep(Boxr_s[1],Klink)
                      rho[[rr]]= oldrho_param[(1+((rr-1)*Klink)):(rr*Klink)]*sum(Boxr_1)
                      rho[[rr]]=rho[[rr]]-(Boxr_1[1])
                      rho[[rr]]=10^(rho[[rr]])
                      rho[[rr]]=rho[[rr]]*Rho[rr]
                    }else{
                      if(t_r>1){
                        oldrho_param=c(rep(Boxr_s[1],(t_r-1)),rep(Boxr_s[2],(Klink-t_r+1)))
                        rho[[rr]]=  c(( oldrho_param[(1+((rr-1)*Klink)):((t_r-1)+((rr-1)*Klink))]*sum(Boxr_1))  , ( oldrho_param[((t_r)+((rr-1)*Klink)):(rr*Klink)]*sum(Boxr_2)) )
                        rho[[rr]]=c(  rho[[rr]][1:(t_r-1)]-(Boxr_1[1]) ,  rho[[rr]][t_r:Klink]-(Boxr_2[1]) )
                        rho[[rr]]=10^(rho[[rr]])
                        rho[[rr]]=c(rho[[rr]][1:(t_r-1)]*Rho[rr],rho[[rr]][t_r:Klink]*Rho[rr]*correct_R)
                      }else{
                        oldrho_param=rep(Boxr_s[2],Klink)
                        rho[[rr]]= oldrho_param[(1+((rr-1)*Klink)):(rr*Klink)]*sum(Boxr_2)
                        rho[[rr]]=rho[[rr]]-(Boxr_2[1])
                        rho[[rr]]=10^(rho[[rr]])
                        rho[[rr]]=rho[[rr]]*Rho[rr]
                      }
                    }




                    xx=0
                    rho_[[rr]]=vector()
                    for(ix in 1:Klink){
                      x=xx+1
                      xx = xx + pop_vect[ix]
                      rho_[[rr]][x:xx]= rho[[rr]][ix]
                    }
                  }
                }
                if(SF==1){
                  sigma_=numeric(n)
                  sigma=param[(start_position+1):(start_position+Klink)]
                  start_position=start_position+Klink
                  sigma=sigma*(Boxs[2]-Boxs[1])
                  sigma=sigma+Boxs[1]
                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    sigma_[x:xx]=sigma[ix]
                  }
                }
                if(SF==2){
                  Boxs_s=get('Boxs_s', envir=test.env)
                  sigma_=numeric(n)

                  #t_s=min(ceiling(param[(start_position+1)]*Klink),Klink)
                  t_s=get('t_s', envir=test.env)
                  if(t_s>Klink){
                    sigma=rep(Boxs_s[1],Klink)
                  }else{
                    if(t_s>1){
                      sigma=c(rep(Boxs_s[1],(t_s-1)),rep(Boxs_s[2],(Klink-t_s+1)))
                    }else{
                      sigma=rep(Boxs_s[2],Klink)
                    }
                  }
                  #start_position=start_position+1
                  sigma=sigma*(Boxs[2]-Boxs[1])
                  sigma=sigma+Boxs[1]
                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    sigma_[x:xx]=sigma[ix]
                  }

                }
                if(SF==3){
                  Boxs_s=get('Boxs_s', envir=test.env)
                  Boxs_1=get('Boxs_1', envir=test.env)
                  Boxs_2=get('Boxs_2', envir=test.env)
                  sigma_=numeric(n)

                  t_s=get('t_s', envir=test.env)
                  if(t_s>Klink){
                    sigma=rep(Boxs_s[1],Klink)
                    sigma=sigma*(Boxs_1[2]-Boxs_1[1])
                    sigma=sigma+Boxs_1[1]
                  }else{
                    if(t_s>1){
                      sigma=c(rep(Boxs_s[1],(t_s-1)),rep(Boxs_s[2],(Klink-t_s+1)))
                      sigma= c(sigma[1:(t_s-1)]*(Boxs_1[2]-Boxs_1[1]),sigma[t_s:Klink]*(Boxs_2[2]-Boxs_2[1]) )
                      sigma= c(sigma[1:(t_s-1)]+Boxs_1[1],sigma[t_s:Klink]+Boxs_2[1])
                    }else{
                      sigma=rep(Boxs_s[2],Klink)
                      sigma=sigma*(Boxs_2[2]-Boxs_2[1])
                      sigma=sigma+Boxs_2[1]
                    }
                  }
                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    sigma_[x:xx]=sigma[ix]
                  }
                }
                if(SF==0){
                  sigma_=rep(sigma,n)
                }
                if(SB==1){
                  beta_=numeric(n)
                  beta=((param[(start_position+1):(start_position+Klink)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
                  start_position=start_position+(Klink)
                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    beta_[x:xx]=beta[ix]

                  }
                }
                if(SB==2){
                  beta_=numeric(n)
                  BoxB_s=get('BoxB_s', envir=test.env)
                  #t_b=min(ceiling(param[(start_position+1)]*Klink),Klink)
                  t_b=get('t_b', envir=test.env)
                  if(t_b>Klink){
                    beta=rep(BoxB_s[1],Klink)
                  }else{
                    if(t_b>1){
                      beta=c(rep(BoxB_s[1],(t_b-1)),rep(BoxB_s[2],(Klink-t_b+1)))
                    }else{
                      beta=rep(BoxB_s[2],Klink)
                    }
                  }

                  beta=((beta*(BoxB[2]-BoxB[1]))+BoxB[1])^2
                  # start_position=start_position+1
                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    beta_[x:xx]=beta[ix]

                  }
                }
                if(SB==0){
                  beta_=rep(beta,n)
                }
                if(SB==3){
                  beta_=numeric(n)
                  BoxB_s=get('BoxB_s', envir=test.env)
                  BoxB_1=get('BoxB_1', envir=test.env)
                  BoxB_2=get('BoxB_2', envir=test.env)
                  t_b=get('t_b', envir=test.env)
                  if(t_b>Klink){
                    beta=rep(BoxB_s[1],Klink)
                    beta=((beta*(BoxB_1[2]-BoxB_1[1]))+BoxB_1[1])^2
                  }else{
                    if(t_b>1){
                      beta=c(rep(BoxB_s[1],(t_b-1)),rep(BoxB_s[2],(Klink-t_b+1)))
                      beta=c((((beta[1:(t_b-1)]*(BoxB_1[2]-BoxB_1[1]))+BoxB_1[1])^2),(((beta[t_b:Klink]*(BoxB_2[2]-BoxB_2[1]))+BoxB_2[1])^2))
                    }else{
                      beta=rep(BoxB_s[2],Klink)
                      beta=((beta*(BoxB_2[2]-BoxB_2[1]))+BoxB_2[1])^2
                    }
                  }


                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    beta_[x:xx]=beta[ix]

                  }
                }
                if(!Pop){
                  Xi=numeric(n)
                  Xi_=param[(start_position+1):(start_position+Klink)]
                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    Xi[x:xx]=Xi_[ix]
                  }
                  Xi=Xi*sum(BoxP)
                  Xi=Xi-(BoxP[1])
                  Xi=10^Xi
                }else{
                  Xi=rep(1,n)
                }

                MLH=0


                for(chr in 1:NC){
                  builder=build_HMM_matrix_t(k,(rho[[chr]]),beta=beta_,L=L[chr],Pop=Pop,Xi,Beta=Beta,scale=window_scaling,sigma =sigma_,Sigma = Self,Big_Window=Big_Window,npair=npair)
                  Q = builder[[1]]
                  nu= builder[[2]]
                  Tc=builder[[3]]
                  g=build_emission_matrix(mu[chr],mu_b,Tc=builder[[4]],t=builder[[3]],beta,FS)




                  q_=rep(0,length(Tc))
                  test=Build_zip_Matrix_mailund(Q,g,Os[[chr]][[1]][[2]],nu,do_all=F)

                  for(i in 1:length(Os[[chr]])){
                    fo=forward_zip_mailund(Os[[chr]][[i]][[1]],g,nu,test[[1]])
                    MLH=MLH-fo[[3]]
                  }
                }
                return(MLH)
              }

              param=c()
              if(ER==1){
                for(rr in 1:NC){
                  param=c(param,oldrho[[rr]])
                }
              }

              if(SF==1){
                param=c(param,oldsigma)
              }

              if(SB==1){
                param=c(param,oldbeta)
              }

              if(!Popfix){
                param=c(param,oldXi_)
              }

              LH_temp=0


              if(ER==1){

                LH_temp=function_to_minimize(param)
                for(rr in 1:NC){
                for(pos_param in 1:length(oldrho[[rr]])){

                  UP=F

                  if((oldrho[[rr]][pos_param]+0.05)<1){
                    oldrho[[rr]][pos_param]=oldrho[[rr]][pos_param]+0.05

                    param=c()
                    if(ER==1){
                      for(rr in 1:NC){
                        param=c(param,oldrho[[rr]])
                      }
                    }

                    if(SF==1){
                      param=c(param,oldsigma)
                    }

                    if(SB==1){
                      param=c(param,oldbeta)
                    }

                    if(!Popfix){
                      param=c(param,oldXi_)
                    }

                    LH_temp2=function_to_minimize(param)
                    if(LH_temp>LH_temp2){
                      UP=T
                      LH_temp=LH_temp2
                    }else{
                      oldrho[[rr]][pos_param]=oldrho[[rr]][pos_param]-0.05

                    }
                  }

                  if(UP){
                    while(UP){
                      if((oldrho[[rr]][pos_param]+0.05)<1){
                        oldrho[[rr]][pos_param]=oldrho[[rr]][pos_param]+0.05

                        UP=F
                        param=c()
                        if(ER==1){
                          for(rr in 1:NC){
                            param=c(param,oldrho[[rr]])
                          }
                        }

                        if(SF==1){
                          param=c(param,oldsigma)
                        }

                        if(SB==1){
                          param=c(param,oldbeta)
                        }

                        if(!Popfix){
                          param=c(param,oldXi_)
                        }

                        LH_temp2=function_to_minimize(param)
                        if(LH_temp>LH_temp2){
                          UP=T
                          LH_temp=LH_temp2
                        }else{
                          oldrho[[rr]][pos_param]=oldrho[[rr]][pos_param]-0.05

                        }
                      }else{
                        UP=F
                      }
                    }
                  }else{
                    DOWN=F
                    if((oldrho[[rr]][pos_param]-0.05)>0){
                      oldrho[[rr]][pos_param]=oldrho[[rr]][pos_param]-0.05


                      param=c()
                      if(ER==1){
                        for(rr in 1:NC){
                          param=c(param,oldrho[[rr]])
                        }
                      }

                      if(SF==1){
                        param=c(param,oldsigma)
                      }

                      if(SB==1){
                        param=c(param,oldbeta)
                      }

                      if(!Popfix){
                        param=c(param,oldXi_)
                      }

                      LH_temp2=function_to_minimize(param)
                      if(LH_temp>LH_temp2){
                        DOWN=T
                        LH_temp=LH_temp2
                      }else{
                        oldrho[[rr]][pos_param]=oldrho[[rr]][pos_param]+0.05

                      }
                    }
                    while(DOWN){
                      if((oldrho[[rr]][pos_param]-0.05)>0){
                        oldrho[[rr]][pos_param]=oldrho[[rr]][pos_param]-0.05

                        DOWN=F
                        param=c()
                        if(ER==1){
                          for(rr in 1:NC){
                            param=c(param,oldrho[[rr]])
                          }
                        }

                        if(SF==1){
                          param=c(param,oldsigma)
                        }

                        if(SB==1){
                          param=c(param,oldbeta)
                        }

                        if(!Popfix){
                          param=c(param,oldXi_)
                        }
                        LH_temp2=function_to_minimize(param)
                        if(LH_temp>LH_temp2){
                          DOWN=T
                          LH_temp=LH_temp2
                        }else{
                          oldrho[[rr]][pos_param]=oldrho[[rr]][pos_param]+0.05

                        }
                      }else{
                        DOWN=F
                      }
                    }
                  }


                }
                }



              }

              if(SF==1){
                LH_temp=function_to_minimize(param)
                for(pos_param in 1:length(pop_vect)){

                  UP=F

                  if((oldsigma[pos_param]+0.05)<1){
                    oldsigma[pos_param]=oldsigma[pos_param]+0.05

                    param=c()
                    if(ER==1){
                      for(rr in 1:NC){
                        param=c(param,oldrho[[rr]])
                      }
                    }

                    if(SF==1){
                      param=c(param,oldsigma)
                    }

                    if(SB==1){
                      param=c(param,oldbeta)
                    }

                    if(!Popfix){
                      param=c(param,oldXi_)
                    }

                    LH_temp2=function_to_minimize(param)
                    if(LH_temp>LH_temp2){
                      UP=T
                      LH_temp=LH_temp2
                    }else{
                      oldsigma[pos_param]=oldsigma[pos_param]-0.05

                    }
                  }

                  if(UP){
                    while(UP){
                      if((oldsigma[pos_param]+0.05)<1){
                        oldsigma[pos_param]=oldsigma[pos_param]+0.05

                        UP=F
                        param=c()
                        if(ER==1){
                          for(rr in 1:NC){
                            param=c(param,oldrho[[rr]])
                          }
                        }

                        if(SF==1){
                          param=c(param,oldsigma)
                        }

                        if(SB==1){
                          param=c(param,oldbeta)
                        }

                        if(!Popfix){
                          param=c(param,oldXi_)
                        }

                        LH_temp2=function_to_minimize(param)
                        if(LH_temp>LH_temp2){
                          UP=T
                          LH_temp=LH_temp2
                        }else{
                          oldsigma[pos_param]=oldsigma[pos_param]-0.05

                        }
                      }else{
                        UP=F
                      }
                    }
                  }else{
                    DOWN=F
                    if((oldsigma[pos_param]-0.05)>0){
                      oldsigma[pos_param]=oldsigma[pos_param]-0.05


                      param=c()
                      if(ER==1){
                        for(rr in 1:NC){
                          param=c(param,oldrho[[rr]])
                        }
                      }

                      if(SF==1){
                        param=c(param,oldsigma)
                      }

                      if(SB==1){
                        param=c(param,oldbeta)
                      }

                      if(!Popfix){
                        param=c(param,oldXi_)
                      }

                      LH_temp2=function_to_minimize(param)
                      if(LH_temp>LH_temp2){
                        DOWN=T
                        LH_temp=LH_temp2
                      }else{
                        oldsigma[pos_param]=oldsigma[pos_param]+0.05

                      }
                    }
                    while(DOWN){
                      if((oldsigma[pos_param]-0.05)>0){
                        oldsigma[pos_param]=oldsigma[pos_param]-0.05

                        DOWN=F
                        param=c()
                        if(ER==1){
                          for(rr in 1:NC){
                            param=c(param,oldrho[[rr]])
                          }
                        }

                        if(SF==1){
                          param=c(param,oldsigma)
                        }

                        if(SB==1){
                          param=c(param,oldbeta)
                        }

                        if(!Popfix){
                          param=c(param,oldXi_)
                        }
                        LH_temp2=function_to_minimize(param)
                        if(LH_temp>LH_temp2){
                          DOWN=T
                          LH_temp=LH_temp2
                        }else{
                          oldsigma[pos_param]=oldsigma[pos_param]+0.05

                        }
                      }else{
                        DOWN=F
                      }
                    }
                  }


                }

              }

              if(SB==1){
                LH_temp=function_to_minimize(param)
                for(pos_param in 1:length(pop_vect)){

                  UP=F

                  if((oldbeta[pos_param]+0.05)<1){
                    oldbeta[pos_param]=oldbeta[pos_param]+0.05

                    param=c()
                    if(ER==1){
                      for(rr in 1:NC){
                        param=c(param,oldrho[[rr]])
                      }
                    }

                    if(SF==1){
                      param=c(param,oldsigma)
                    }

                    if(SB==1){
                      param=c(param,oldbeta)
                    }

                    if(!Popfix){
                      param=c(param,oldXi_)
                    }

                    LH_temp2=function_to_minimize(param)
                    if(LH_temp>LH_temp2){
                      UP=T
                      LH_temp=LH_temp2
                    }else{
                      oldbeta[pos_param]=oldbeta[pos_param]-0.05

                    }
                  }

                  if(UP){
                    while(UP){
                      if((oldbeta[pos_param]+0.05)<1){
                        oldbeta[pos_param]=oldbeta[pos_param]+0.05

                        UP=F
                        param=c()
                        if(ER==1){
                          for(rr in 1:NC){
                            param=c(param,oldrho[[rr]])
                          }
                        }

                        if(SF==1){
                          param=c(param,oldsigma)
                        }

                        if(SB==1){
                          param=c(param,oldbeta)
                        }

                        if(!Popfix){
                          param=c(param,oldXi_)
                        }

                        LH_temp2=function_to_minimize(param)
                        if(LH_temp>LH_temp2){
                          UP=T
                          LH_temp=LH_temp2
                        }else{
                          oldbeta[pos_param]=oldbeta[pos_param]-0.05

                        }
                      }else{
                        UP=F
                      }
                    }
                  }else{
                    DOWN=F
                    if((oldbeta[pos_param]-0.05)>0){
                      oldbeta[pos_param]=oldbeta[pos_param]-0.05


                      param=c()
                      if(ER==1){
                        for(rr in 1:NC){
                          param=c(param,oldrho[[rr]])
                        }
                      }

                      if(SF==1){
                        param=c(param,oldsigma)
                      }

                      if(SB==1){
                        param=c(param,oldbeta)
                      }

                      if(!Popfix){
                        param=c(param,oldXi_)
                      }

                      LH_temp2=function_to_minimize(param)
                      if(LH_temp>LH_temp2){
                        DOWN=T
                        LH_temp=LH_temp2
                      }else{
                        oldbeta[pos_param]=oldbeta[pos_param]+0.05

                      }
                    }
                    while(DOWN){
                      if((oldbeta[pos_param]-0.05)>0){
                        oldbeta[pos_param]=oldbeta[pos_param]-0.05

                        DOWN=F
                        param=c()
                        if(ER==1){
                          for(rr in 1:NC){
                            param=c(param,oldrho[[rr]])
                          }
                        }

                        if(SF==1){
                          param=c(param,oldsigma)
                        }

                        if(SB==1){
                          param=c(param,oldbeta)
                        }

                        if(!Popfix){
                          param=c(param,oldXi_)
                        }
                        LH_temp2=function_to_minimize(param)
                        if(LH_temp>LH_temp2){
                          DOWN=T
                          LH_temp=LH_temp2
                        }else{
                          oldbeta[pos_param]=oldbeta[pos_param]+0.05

                        }
                      }else{
                        DOWN=F
                      }
                    }
                  }


                }

              }

            }
          }


          if(Popfix){
            if(!is.list(oldrho)){
              rho_=oldrho*sum(Boxr)
              rho_=rho_-(Boxr[1])
              rho_=10^(rho_)
              rho_=rho_*Rho
              rho=vector()
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                rho[x:xx]= rho_[ix]
              }
            }else{
              rho_=list()
              rho=list()
              for(rr in 1:NC){
                rho_[[rr]]=oldrho[[rr]]*sum(Boxr)
                rho_[[rr]]=rho_[[rr]]-(Boxr[1])
                rho_[[rr]]=10^(rho_[[rr]])
                rho_[[rr]]=rho_[[rr]]*Rho[rr]

                xx=0
                rho[[rr]]=vector()
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  rho[[rr]][x:xx]= rho_[[rr]][ix]
                }
              }

            }

            if(SB>0){
              beta_=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1] )^2
              beta=vector()
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                beta[x:xx]=beta_[ix]
              }
            }
            if(SF>0){
              sigma_=oldsigma*(Boxs[2]-Boxs[1])
              sigma_=sigma_+Boxs[1]
              sigma=vector()
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                sigma[x:xx]= sigma_[ix]
              }
            }
            print(c("sigma:",sigma,"beta :",beta))
            if(is.list(rho_)){
              print(c("rho/theta:",rho_[[1]]/theta))
            }else{
              print(c("rho/theta:",rho_/theta))
            }

            Keep_going=F
            if(it==1){
              diff_o=0
            }
            if(it>1){
              if(SF==1){
                diff_o=mean(abs(sigma_o-sigma))
              }
              if(SF==2){
                diff_o=0.0001
              }
              if(SB==1){
                diff_o=max(diff_o,mean(abs(beta_o-beta)))
              }
              if(SB==2){
                diff_o=max(diff_o,0.0001)
              }
              count_diff_o=0
              if(diff_o>=0.005){
                if(it==maxIt){
                  count_diff_o=count_diff_o+1
                  maxIt=maxIt+1
                  if(count_diff_o>10){
                    maxBit=maxBit-1
                  }
                }
              }
            }
            sigma_o=sigma
            beta_o=beta



            if(NC==1){
              builder=build_HMM_matrix_t(k,(rho),beta=beta,L=L,Pop=Pop,Xi=NA,Beta=Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
            }
            if(NC>1){
              builder=list()
              for(chr in 1:NC){
                builder[[chr]]=build_HMM_matrix_t(k,(rho[[chr]]),beta=beta,L=L[chr],Pop=Pop,Xi=NA,Beta=Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
              }
            }
          }
          if(!Popfix){
            xx=0
            for(ix in 1:Klink){
              x=xx+1
              xx = xx + pop_vect[ix]
              oldXi[x:xx]=oldXi_[ix]
            }
            Xi_=oldXi*sum(BoxP)
            Xi_=Xi_-(BoxP[1])
            Xi_=10^Xi_
            if(!is.list(oldrho)){
              rho_=oldrho*sum(Boxr)
              rho_=rho_-(Boxr[1])
              rho_=10^(rho_)
              rho_=rho_*Rho
              rho=vector()
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                rho[x:xx]= rho_[ix]
              }
            }else{
              rho_=list()
              rho=list()
              for(rr in 1:NC){
                rho_[[rr]]=oldrho[[rr]]*sum(Boxr)
                rho_[[rr]]=rho_[[rr]]-(Boxr[1])
                rho_[[rr]]=10^(rho_[[rr]])
                rho_[[rr]]=rho_[[rr]]*Rho[rr]
                rho[[rr]]=vector()
                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  rho[[rr]][x:xx]= rho_[[rr]][ix]
                }
              }

            }
            if(SB>0){
              beta_=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1] )^2
              beta=vector()
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                beta[x:xx]=beta_[ix]
              }
            }
            if(SF>0){
              sigma_=oldsigma*(Boxs[2]-Boxs[1])
              sigma_=sigma_+Boxs[1]
              sigma=vector()
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                sigma[x:xx]= sigma_[ix]
              }
            }
            print(c("sigma:",sigma,"beta :",beta))
            Keep_going=F
            if(it==1){
              diff_o=0
            }
            if(it>1){
              if(SF==1){
                diff_o=mean(abs(sigma_o-sigma))
              }
              if(SF==2){
                diff_o=0.0001
              }
              if(SB==1){
                diff_o=max(diff_o,mean(abs(beta_o-beta)))
              }
              if(SB==2){
                diff_o=max(diff_o,0.0001)
              }
              count_diff_o=0
              if(diff_o>=0.005){
                if(it==maxIt){
                  count_diff_o=count_diff_o+1
                  maxIt=maxIt+1
                  if(count_diff_o>10){
                    maxBit=maxBit-1
                  }
                }
              }
            }
            sigma_o=sigma
            beta_o=beta
            # browser()
            if(NC==1){
              builder=build_HMM_matrix_t(k,(rho),beta=beta,L=L,Pop=Pop,Xi_,Beta=Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
            }
            if(NC>1){
              builder=list()
              for(chr in 1:NC){
                builder[[chr]]=build_HMM_matrix_t(k,(rho[[chr]]),beta=beta,L=L[chr],Pop=Pop,Xi_,Beta=Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
              }
            }
          }



          if(NC==1){
            Q = builder[[1]]
            nu= builder[[2]]
            Tc= builder[[3]]
            g=build_emission_matrix(mu,mu_b,Tc=builder[[4]],t=builder[[3]],beta,FS)
            M=matrix(0,nrow=length(Tc),ncol=3)
            N=matrix(0,length(Tc),length(Tc))
            MLH=0
            q_=rep(0,length(Tc))
            s_t=Sys.time()
            test=Build_zip_Matrix_mailund(Q,g,Os[[1]][[2]],nu)
            e_t=Sys.time()
            print(e_t-s_t)

            for(i in 1:length(Os)){
              Os[[i]][[1]]=as.numeric(Os[[i]][[1]])
              fo=forward_zip_mailund(Os[[i]][[1]],g,nu,test[[1]])
              MLH=MLH+fo[[3]]
              c=exp(fo[[2]])
              ba=Backward_zip_mailund(Os[[i]][[1]],test[[3]],length(Tc),c)

              W_P=list()
              W_P_=list()
              count_oo=0
              for(oo in c(1,3)){
                count_oo=count_oo+1
                int=t(Q)%*%diag(g[,oo])
                int=eigen(int)
                W_P[[count_oo]]=int$vectors
                W_P_[[count_oo]]=solve(W_P[[count_oo]])
              }
              symbol= c(0:2,10:40)
              for(ob in 1){
                truc_M=matrix(0,nrow=length(Tc),ncol=3)
                if(Os[[i]][[1]][(ob+1)]<=2){
                  truc_N=(fo[[1]][,ob]%*%(t(ba[,(ob+1)]*g[,(as.numeric(Os[[i]][[1]][(ob+1)])+1)]/c[(ob+1)])))
                  truc_M[,(as.numeric(Os[[i]][[1]][(ob+1)])+1)]=fo[[1]][,ob]*(test[[2]][[(as.numeric(Os[[i]][[1]][(ob+1)])+1)]]%*%(ba[,(ob+1)]/c[(ob+1)]))
                }else{

                  if(Os[[i]][[1]][(ob+1)]<30){
                    truc_N=(t(W_P_[[1]])%*%(t(W_P[[1]])%*%fo[[1]][,ob]%*%t(ba[,(ob+1)]/c[(ob+1)])%*%t(W_P_[[1]])*test[[4]][[(as.numeric(Os[[i]][[1]][(ob+1)]))]])%*%(t(W_P[[1]]))%*%diag(g[,1]))
                    truc_M[,1]=diag(t(W_P_[[1]])%*%(t(W_P[[1]])%*%fo[[1]][,ob]%*%t(ba[,(ob+1)]/c[(ob+1)])%*%t(W_P_[[1]]))*test[[2]][[(as.numeric(Os[[i]][[1]][(ob+1)]))]]%*%t(W_P[[1]]))
                  }else{
                    truc_N=(t(W_P_[[2]])%*%(t(W_P[[2]])%*%fo[[1]][,ob]%*%t(ba[,(ob+1)]/c[(ob+1)])%*%t(W_P_[[2]])*test[[4]][[(as.numeric(Os[[i]][[1]][(ob+1)]))]])%*%(t(W_P[[2]]))%*%diag(g[,3]))
                    truc_M[,3]=diag(t(W_P_[[2]])%*%(t(W_P[[2]])%*%fo[[1]][,ob]%*%t(ba[,(ob+1)]/c[(ob+1)])%*%t(W_P_[[2]]))*test[[2]][[(as.numeric(Os[[i]][[1]][(ob+1)]))]]%*%t(W_P[[2]]))

                  }
                }
              }
              #truc_N=sum_chi_corrected(fo[[1]][,ob],ba[,(ob+1)],test[[4]],Os[[i]][[1]][(ob+1)],g,W,c[(ob+1)])
              N=N+truc_N
              #truc_M=sum_M_cor(fo[[1]][,ob],ba[,(ob+1)],Os[[i]][[1]][(ob+1)],test[[2]],W,(c[(ob+1)]),test[[1]])
              M=M+truc_M

              for(sym in sort(symbol)){
                ob=as.numeric(sym)
                pos=which(as.numeric(Os[[i]][[1]][-c(1,length(Os[[i]][[1]]))])==ob)
                if(length(pos)>0){
                  pos=pos+1
                  #print("expected L:")
                  #print(Os[[3]][which(Os[[3]][,1]==sym),2]*length(pos))
                  #print("ob:")
                  #print(ob)
                  if(ob<3){
                    # print("expected L:")
                    #  print(length(pos))
                    ba_t=t(t(ba[,(pos)])/c[(pos)])
                    truc=c(rowSums(fo[[1]][,(pos-1)]*(test[[1]][[(ob+1)]]%*%ba_t)))
                    truc=(truc/(sum(truc)))*length(pos)
                    M[,(ob+1)]=M[,(ob+1)]+ truc
                    truc_N=(fo[[1]][,(pos-1)]%*%(t(diag(g[,(ob+1)])%*%ba_t)))
                    # print("calculated L:")
                    #  print(sum(truc_N*t(Q)))
                    N=N+truc_N
                  }else{
                    if(ob<30){
                      A=(t(W_P[[1]])%*%fo[[1]][,(pos-1)]%*%t(t(t(ba[,(pos)])/c[(pos)]))%*%t(W_P_[[1]]))
                      A_=A*test[[2]][[(ob)]]
                      A_=(t(W_P_[[1]])%*%A_%*%t(W_P[[1]]))
                      M[,1]=M[,1]+(diag(A_))
                      A_=A*test[[4]][[(ob)]]
                      A_=(t(W_P_[[1]])%*%A_%*%t(W_P[[1]]))
                      truc_N=((A_%*%diag(g[,1])))
                    }else{
                      A=(t(W_P[[2]])%*%fo[[1]][,(pos-1)]%*%t(t(t(ba[,(pos)])/c[(pos)]))%*%t(W_P_[[2]]))
                      A_=A*test[[2]][[(ob)]]
                      A_=(t(W_P_[[2]])%*%A_%*%t(W_P[[2]]))
                      M[,3]=M[,3]+(diag(A_))
                      A_=A*test[[4]][[(ob)]]
                      A_=(t(W_P_[[2]])%*%A_%*%t(W_P[[2]]))
                      truc_N=((A_%*%diag(g[,3])))
                    }

                    #print("calculated L:")
                    #print(sum(truc_N*t(Q)))
                    N=N+truc_N
                  }
                }
              }

              if(as.numeric(Os[[i]][[1]][length(Os[[i]][[1]])])<=3){
                M[,(as.numeric(Os[[i]][[1]][length(Os[[i]][[1]])])+1)]=M[,(as.numeric(Os[[i]][[1]][length(Os[[i]][[1]])])+1)]+(fo[[1]][,length(Os[[i]][[1]])]*ba[,length(Os[[i]][[1]])])
              }else{
                if(as.numeric(Os[[i]][[1]][length(Os[[i]][[1]])])<30){

                  M[,1]=M[,1]+((fo[[1]][,length(Os[[i]][[1]])]*ba[,length(Os[[i]][[1]])])/sum(fo[[1]][,length(Os[[i]][[1]])]*ba[,length(Os[[i]][[1]])]))
                }else{
                  M[,3]=M[,3]+((fo[[1]][,length(Os[[i]][[1]])]*ba[,length(Os[[i]][[1]])])/sum(fo[[1]][,length(Os[[i]][[1]])]*ba[,length(Os[[i]][[1]])]))

                }
              }
              q_=q_+((fo[[1]][,1]*ba[,1])/sum(fo[[1]][,1]*ba[,1]))
            }
            N=N*t(Q)
            if(is.complex(N)){
              N=Re(N)
            }

            if(is.complex(M)){
              M=Re(M)
            }
            Scale_N=(L-1)/sum(N)
            N=N*Scale_N
            Scale_M=L/sum(M)
            M=M*Scale_M
            q_=q_/sum(q_)
            if(SCALED){
              corrector_M=rowSums(M)
              M=diag(1/corrector_M)%*%M
              corrector_N=rowSums(N)
              N=diag(1/corrector_N)%*%N
            }


          }
          if(NC>1){
            Q=list()
            nu=list()
            Tc=list()
            g=list()
            M=list()
            N=list()
            MLH=list()
            q_=list()
            for(chr in 1:NC){
              Q[[chr]] = builder[[chr]][[1]]
              nu[[chr]]= builder[[chr]][[2]]
              Tc[[chr]]=builder[[chr]][[3]]
              g[[chr]]=build_emission_matrix(mu[chr],mu_b,Tc=builder[[chr]][[4]],t=builder[[chr]][[3]],beta,FS)
              M[[chr]]=matrix(0,nrow=length(Tc[[chr]]),ncol=3)
              N[[chr]]=matrix(0,length(Tc[[chr]]),length(Tc[[chr]]))
              MLH[[chr]]=0
              q_[[chr]]=rep(0,length(Tc[[chr]]))
              test=Build_zip_Matrix_mailund(Q[[chr]],g[[chr]],Os[[chr]][[1]][[2]],nu[[chr]])
              for(i in 1:length(Os[[chr]])){
                Os[[chr]][[i]][[1]]=as.numeric(Os[[chr]][[i]][[1]])
                fo=forward_zip_mailund(Os[[chr]][[i]][[1]],g[[chr]],nu[[chr]],test[[1]])
                MLH[[chr]]=MLH[[chr]]+fo[[3]]
                c=exp(fo[[2]])
                ba=Backward_zip_mailund(Os[[chr]][[i]][[1]],test[[3]],length(Tc[[chr]]),c)
                W_P=list()
                W_P_=list()
                count_oo=0
                for(oo in c(1,3)){
                  count_oo=count_oo+1
                  int=t(Q[[chr]])%*%diag(g[[chr]][,oo])
                  int=eigen(int)
                  W_P[[count_oo]]=int$vectors
                  W_P_[[count_oo]]=solve(W_P[[count_oo]])
                }
                symbol= c(0:2,10:40)
                for(ob in 1){
                  truc_M=matrix(0,nrow=length(Tc[[chr]]),ncol=3)
                  if(as.numeric(Os[[chr]][[i]][[1]][(ob+1)])<=4){
                    truc_N=(fo[[1]][,ob]%*%(t(ba[,(ob+1)]*g[[chr]][,(as.numeric(Os[[chr]][[i]][[1]][(ob+1)])+1)]/c[(ob+1)])))
                    truc_M[,(as.numeric(Os[[chr]][[i]][[1]][(ob+1)])+1)]=fo[[1]][,ob]*(test[[2]][[(as.numeric(Os[[chr]][[i]][[1]][(ob+1)])+1)]]%*%(ba[,(ob+1)]/c[(ob+1)]))
                  }else{
                    if(as.numeric(Os[[chr]][[i]][[1]][(ob+1)])<30){
                      truc_N=(t(W_P_[[1]])%*%(t(W_P[[1]])%*%fo[[1]][,ob]%*%t(ba[,(ob+1)]/c[(ob+1)])%*%t(W_P_[[1]])*test[[4]][[(as.numeric(Os[[chr]][[i]][[1]][(ob+1)]))]])%*%(t(W_P[[1]]))%*%diag(g[[chr]][,1]))
                      truc_M[,1]=diag(t(W_P_[[1]])%*%(t(W_P[[1]])%*%fo[[1]][,ob]%*%t(ba[,(ob+1)]/c[(ob+1)])%*%t(W_P_[[1]]))*test[[2]][[(as.numeric(Os[[chr]][[i]][[1]][(ob+1)]))]]%*%t(W_P[[1]]))
                    }else{
                      truc_N=(t(W_P_[[2]])%*%(t(W_P[[2]])%*%fo[[1]][,ob]%*%t(ba[,(ob+1)]/c[(ob+1)])%*%t(W_P_[[2]])*test[[4]][[(as.numeric(Os[[chr]][[i]][[1]][(ob+1)]))]])%*%(t(W_P[[2]]))%*%diag(g[[chr]][,3]))
                      truc_M[,3]=diag(t(W_P_[[2]])%*%(t(W_P[[2]])%*%fo[[1]][,ob]%*%t(ba[,(ob+1)]/c[(ob+1)])%*%t(W_P_[[2]]))*test[[2]][[(as.numeric(Os[[chr]][[i]][[1]][(ob+1)]))]]%*%t(W_P[[2]]))

                    }

                  }
                  N[[chr]]=N[[chr]]+truc_N
                  M[[chr]]=M[[chr]]+truc_M
                }
                for(sym in symbol){
                  ob=as.numeric(sym)
                  pos=which(as.numeric(Os[[chr]][[i]][[1]][-c(1,length(Os[[chr]][[i]][[1]]))])==ob)
                  if(length(pos)>0){
                    pos=pos+1
                    if(ob<3){
                      ba_t=t(t(ba[,(pos)])/c[(pos)])
                      truc=c(rowSums(fo[[1]][,(pos-1)]*(test[[1]][[(ob+1)]]%*%ba_t)))
                      truc=(truc/(sum(truc)))*length(pos)
                      M[[chr]][,(ob+1)]=M[[chr]][,(ob+1)]+ truc
                      N[[chr]]=N[[chr]]+(fo[[1]][,(pos-1)]%*%(t(diag(g[[chr]][,(ob+1)])%*%ba_t)))
                    }else{
                      if(ob<30){
                        A=(t(W_P[[1]])%*%fo[[1]][,(pos-1)]%*%t(t(t(ba[,(pos)])/c[(pos)]))%*%t(W_P_[[1]]))
                        A_=A*test[[2]][[(ob)]]
                        A_=(t(W_P_[[1]])%*%A_%*%t(W_P[[1]]))
                        M[[chr]][,1]=M[[chr]][,1]+(diag(A_))
                        A_=A*test[[4]][[(ob)]]
                        A_=(t(W_P_[[1]])%*%A_%*%t(W_P[[1]]))
                        N[[chr]]=N[[chr]]+((A_%*%diag(g[[chr]][,1])))
                      }else{
                        A=(t(W_P[[2]])%*%fo[[1]][,(pos-1)]%*%t(t(t(ba[,(pos)])/c[(pos)]))%*%t(W_P_[[2]]))
                        A_=A*test[[2]][[(ob)]]
                        A_=(t(W_P_[[2]])%*%A_%*%t(W_P[[2]]))
                        M[[chr]][,3]=M[[chr]][,3]+(diag(A_))
                        A_=A*test[[4]][[(ob)]]
                        A_=(t(W_P_[[2]])%*%A_%*%t(W_P[[2]]))
                        N[[chr]]=N[[chr]]+((A_%*%diag(g[[chr]][,3])))
                      }
                    }
                  }
                }
                if(as.numeric(Os[[chr]][[i]][[1]][length(Os[[chr]][[i]][[1]])])<=3){
                  M[[chr]][,(as.numeric(Os[[chr]][[i]][[1]][length(Os[[chr]][[i]][[1]])])+1)]=M[[chr]][,(as.numeric(Os[[chr]][[i]][[1]][length(Os[[chr]][[i]][[1]])])+1)]+(fo[[1]][,length(Os[[chr]][[i]][[1]])]*ba[,length(Os[[chr]][[i]][[1]])])
                }
                if(as.numeric(Os[[chr]][[i]][[1]][length(Os[[chr]][[i]][[1]])])>3){
                  if(as.numeric(Os[[chr]][[i]][[1]][length(Os[[chr]][[i]][[1]])])<30){
                    M[[chr]][,1]=M[[chr]][,1]+((fo[[1]][,length(Os[[chr]][[i]][[1]])]*ba[,length(Os[[chr]][[i]][[1]])])/sum(fo[[1]][,length(Os[[chr]][[i]][[1]])]*ba[,length(Os[[chr]][[i]][[1]])]))

                  }else{
                    M[[chr]][,3]=M[[chr]][,3]+((fo[[1]][,length(Os[[chr]][[i]][[1]])]*ba[,length(Os[[chr]][[i]][[1]])])/sum(fo[[1]][,length(Os[[chr]][[i]][[1]])]*ba[,length(Os[[chr]][[i]][[1]])]))

                  }
                }
                q_[[chr]]=q_[[chr]]+((fo[[1]][,1]*ba[,(1)])/sum(fo[[1]][,1]*ba[,(1)]))
              }

              N[[chr]]=N[[chr]]*t(Q[[chr]])
              if(is.complex(N[[chr]])){
                N[[chr]]=Re(N[[chr]])
              }

              if(is.complex(M[[chr]])){
                M[[chr]]=Re(M[[chr]])
              }
              Scale_N=(L[chr]-1)/sum(N[[chr]])
              N[[chr]]=N[[chr]]*Scale_N

              Scale_M=L[chr]/sum(M[[chr]])
              M[[chr]]=M[[chr]]*Scale_M
              q_[[chr]]=q_[[chr]]/sum(q_[[chr]])
              if(SCALED){
                corrector_M=rowSums(M[[chr]])
                M[[chr]]=diag(1/corrector_M)%*%M[[chr]]
                corrector_N=rowSums(N[[chr]])
                N[[chr]]=diag(1/corrector_N)%*%N[[chr]]
              }


            }
          }
          }else{




          if(Popfix){
            if(ER<3){
              if(!is.list(oldrho)){
                rho_=oldrho*sum(Boxr)
                rho_=rho_-(Boxr[1])
                rho_=10^(rho_)
                rho_=rho_*Rho
                rho=vector()
                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  rho[x:xx]= rho_[ix]
                }
              }else{
                rho_=list()
                rho=list()
                for(rr in 1:NC){
                  rho_[[rr]]=oldrho[[rr]]*sum(Boxr)
                  rho_[[rr]]=rho_[[rr]]-(Boxr[1])
                  rho_[[rr]]=10^(rho_[[rr]])
                  rho_[[rr]]=rho_[[rr]]*Rho[rr]

                  xx=0
                  rho[[rr]]=vector()
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    rho[[rr]][x:xx]= rho_[[rr]][ix]
                  }
                }

              }
            }else{
              if(!is.list(oldrho)){
                rho=vector()
                if(oldtr==1){
                  rho_=oldrho*sum(Boxr_2)
                  rho_=rho_-(Boxr_2[1])
                  rho_=10^(rho_)
                  rho_=rho_*Rho
                }
                if(oldtr>Klink){
                  rho_=oldrho*sum(Boxr_1)
                  rho_=rho_-(Boxr_1[1])
                  rho_=10^(rho_)
                  rho_=rho_*Rho*correct_R
                }
                if(oldtr>1&oldtr<=Klink){
                  rho_=c(oldrho[1:(oldtr-1)]*sum(Boxr_1),oldrho[oldtr:Klink]*sum(Boxr_2))
                  rho_=c(rho_[1:(oldtr-1)]-(Boxr_1[1]),rho_[oldtr:Klink]-(Boxr_2[1]))
                  rho_=10^(rho_)
                  rho_=c(rho_[1:(oldtr-1)]*Rho,rho_[oldtr:Klink]*Rho*correct_R)

                }




                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  rho[x:xx]= rho_[ix]
                }
              }else{
                rho_=list()
                rho=list()
                for(rr in 1:NC){


                  if(oldtr==1){
                    rho_[[rr]]=oldrho[[rr]]*sum(Boxr_2)
                    rho_[[rr]]=rho_[[rr]]-(Boxr_2[1])
                    rho_[[rr]]=10^(rho_[[rr]])
                    rho_[[rr]]=rho_[[rr]]*Rho[rr]
                  }
                  if(oldtr>Klink){
                    rho_[[rr]]=oldrho[[rr]]*sum(Boxr_1)
                    rho_[[rr]]=rho_[[rr]]-(Boxr_1[1])
                    rho_[[rr]]=10^(rho_[[rr]])
                    rho_[[rr]]=rho_[[rr]]*Rho[rr]*correct_R
                  }
                  if(oldtr>1&oldtr<=Klink){


                    rho_[[rr]]=c(oldrho[[rr]][1:(oldtr-1)]*sum(Boxr_1),oldrho[[rr]][oldtr:Klink]*sum(Boxr_2))
                    rho_[[rr]]=c(rho_[[rr]][1:(oldtr-1)]-(Boxr_1[1]),rho_[[rr]][oldtr:Klink]-(Boxr_2[1]))
                    rho_[[rr]]=10^(rho_[[rr]])
                    rho_[[rr]]=c(rho_[[rr]][1:(oldtr-1)]*Rho[rr],rho_[[rr]][oldtr:Klink]*Rho[rr]*correct_R)
                  }


                  xx=0
                  rho[[rr]]=vector()
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    rho[[rr]][x:xx]= rho_[[rr]][ix]
                  }
                }

              }
            }


            if(SB>0){
              if(SB<3){
                beta_=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1] )^2
              }else{
                if(oldtb==1){
                  beta_=((oldbeta*(BoxB_2[2]-BoxB_2[1]))+BoxB_2[1] )^2
                }else{
                  if(oldtb>Klink){
                    beta_=((oldbeta*(BoxB_1[2]-BoxB_1[1]))+BoxB_1[1] )^2
                  }else{
                    beta_= c( ((oldbeta[1:(oldtb-1)]*(BoxB_1[2]-BoxB_1[1]))+BoxB_1[1] )^2 , ((oldbeta[oldtb:Klink]*(BoxB_2[2]-BoxB_2[1]))+BoxB_2[1] )^2 )
                  }
                }


              }

              beta=vector()
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                beta[x:xx]=beta_[ix]
              }
            }
            if(SF>0){
              if(SF<3){
                sigma_=oldsigma*(Boxs[2]-Boxs[1])
                sigma_=sigma_+Boxs[1]
              }else{
                if(oldts==1){
                  sigma_=oldsigma*(Boxs_2[2]-Boxs_2[1])
                  sigma_=sigma_+Boxs_2[1]
                }else{
                  if(oldts>Klink){
                    sigma_=oldsigma*(Boxs_1[2]-Boxs_1[1])
                    sigma_=sigma_+Boxs_1[1]
                  }else{
                    sigma_= c(oldsigma[1:(oldts-1)]*(Boxs_1[2]-Boxs_1[1]) ,oldsigma[oldts:Klink]*(Boxs_2[2]-Boxs_2[1]))
                    sigma_= c( (sigma_[1:(oldts-1)]+Boxs_1[1]) , (sigma_[oldts:Klink]+Boxs_2[1]))
                  }
                }
              }


              sigma=vector()
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                sigma[x:xx]= sigma_[ix]
              }
            }

            print(c("sigma:",sigma,"beta :",beta))
            if(is.list(rho_)){
              print(c("rho/theta:",rho_[[1]]/theta))
            }else{
              print(c("rho/theta:",rho_/theta))
            }
            Keep_going=F
            if(it==1){
              diff_o=0
            }
            if(it>1){
              if(SF==1){
                diff_o=mean(abs(sigma_o-sigma))
              }
              if(SF>1){
                diff_o=0.0001
              }
              if(SB==1){
                diff_o=max(diff_o,mean(abs(beta_o-beta)))
              }
              if(SB>1){
                diff_o=max(diff_o,0.0001)
              }
              count_diff_o=0
              if(diff_o>=0.005){
                if(it==maxIt){
                  count_diff_o=count_diff_o+1
                  maxIt=maxIt+1
                  if(count_diff_o>10){
                    maxBit=maxBit-1
                  }
                }
              }
            }
            sigma_o=sigma
            beta_o=beta



            if(NC==1){
              builder=build_HMM_matrix_t(k,(rho),beta=beta,L=L,Pop=Pop,Xi=NA,Beta=Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
            }
            if(NC>1){
              builder=list()
              for(chr in 1:NC){
                builder[[chr]]=build_HMM_matrix_t(k,(rho[[chr]]),beta=beta,L=L[chr],Pop=Pop,Xi=NA,Beta=Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
              }
            }
          }
          if(!Popfix){
            xx=0
            for(ix in 1:Klink){
              x=xx+1
              xx = xx + pop_vect[ix]
              oldXi[x:xx]=oldXi_[ix]
            }
            Xi_=oldXi*sum(BoxP)
            Xi_=Xi_-(BoxP[1])
            Xi_=10^Xi_
            if(ER<3){
              if(!is.list(oldrho)){
                rho_=oldrho*sum(Boxr)
                rho_=rho_-(Boxr[1])
                rho_=10^(rho_)
                rho_=rho_*Rho
                rho=vector()
                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  rho[x:xx]= rho_[ix]
                }
              }else{
                rho_=list()
                rho=list()
                for(rr in 1:NC){
                  rho_[[rr]]=oldrho[[rr]]*sum(Boxr)
                  rho_[[rr]]=rho_[[rr]]-(Boxr[1])
                  rho_[[rr]]=10^(rho_[[rr]])
                  rho_[[rr]]=rho_[[rr]]*Rho[rr]

                  xx=0
                  rho[[rr]]=vector()
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    rho[[rr]][x:xx]= rho_[[rr]][ix]
                  }
                }

              }
            }else{
              if(!is.list(oldrho)){
                rho=vector()
                if(oldtr==1){
                  rho_=oldrho*sum(Boxr_2)
                  rho_=rho_-(Boxr_2[1])
                  rho_=10^(rho_)
                  rho_=rho_*Rho
                }
                if(oldtr>Klink){
                  rho_=oldrho*sum(Boxr_1)
                  rho_=rho_-(Boxr_1[1])
                  rho_=10^(rho_)
                  rho_=rho_*Rho*correct_R
                }
                if((oldtr>1)&oldtr<=Klink){
                  rho_=c(oldrho[1:(oldtr-1)]*sum(Boxr_1),oldrho[oldtr:Klink]*sum(Boxr_2))
                  rho_=c(rho_[1:(oldtr-1)]-(Boxr_1[1]),rho_[oldtr:Klink]-(Boxr_2[1]))
                  rho_=10^(rho_)
                  rho_=c(rho_[1:(oldtr-1)]*Rho,rho_[oldtr:Klink]*Rho*correct_R)
                }




                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  rho[x:xx]= rho_[ix]
                }
              }else{
                rho_=list()
                rho=list()
                for(rr in 1:NC){


                  if(oldtr==1){
                    rho_[[rr]]=oldrho[[rr]]*sum(Boxr_2)
                    rho_[[rr]]=rho_[[rr]]-(Boxr_2[1])
                    rho_[[rr]]=10^(rho_[[rr]])
                    rho_[[rr]]=rho_[[rr]]*Rho[rr]
                  }
                  if(oldtr>Klink){
                    rho_[[rr]]=oldrho[[rr]]*sum(Boxr_1)
                    rho_[[rr]]=rho_[[rr]]-(Boxr_1[1])
                    rho_[[rr]]=10^(rho_[[rr]])
                    rho_[[rr]]=rho_[[rr]]*Rho[rr]*correct_R
                  }
                  if((oldtr>1)&oldtr<=Klink){
                    rho_[[rr]]=c(oldrho[[rr]][1:(oldtr-1)]*sum(Boxr_1),oldrho[[rr]][oldtr:Klink]*sum(Boxr_2))
                    rho_[[rr]]=c(rho_[[rr]][1:(oldtr-1)]-(Boxr_1[1]),rho_[[rr]][oldtr:Klink]-(Boxr_2[1]))
                    rho_[[rr]]=10^(rho_[[rr]])
                    rho_[[rr]]=c(rho_[[rr]][1:(oldtr-1)]*Rho[rr],rho_[[rr]][oldtr:Klink]*Rho[rr]*correct_R)

                  }


                  xx=0
                  rho[[rr]]=vector()
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    rho[[rr]][x:xx]= rho_[[rr]][ix]
                  }
                }

              }
            }
            if(SB>0){
              if(SB<3){
                beta_=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1] )^2
              }else{
                if(oldtb==1){
                  beta_=((oldbeta*(BoxB_2[2]-BoxB_2[1]))+BoxB_2[1] )^2
                }else{
                  if(oldtb>Klink){
                    beta_=((oldbeta*(BoxB_1[2]-BoxB_1[1]))+BoxB_1[1] )^2
                  }else{
                    beta_= c( ((oldbeta[1:(oldtb-1)]*(BoxB_1[2]-BoxB_1[1]))+BoxB_1[1] )^2 , ((oldbeta[oldtb:Klink]*(BoxB_2[2]-BoxB_2[1]))+BoxB_2[1] )^2 )
                  }
                }
              }

              beta=vector()
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                beta[x:xx]=beta_[ix]
              }
            }
            if(SF>0){
              if(SF<3){
                sigma_=oldsigma*(Boxs[2]-Boxs[1])
                sigma_=sigma_+Boxs[1]
              }else{
                if(oldts==1){
                  sigma_=oldsigma*(Boxs_2[2]-Boxs_2[1])
                  sigma_=sigma_+Boxs_2[1]
                }else{
                  if(oldts>Klink){
                    sigma_=oldsigma*(Boxs_1[2]-Boxs_1[1])
                    sigma_=sigma_+Boxs_1[1]
                  }else{
                    sigma_= c(oldsigma[1:(oldts-1)]*(Boxs_1[2]-Boxs_1[1]) ,oldsigma[oldts:Klink]*(Boxs_2[2]-Boxs_2[1]) )
                    sigma_= c( (sigma_[1:(oldts-1)]+Boxs_1[1]) , (sigma_[oldts:Klink]+Boxs_2[1]))
                  }
                }
              }
              sigma=vector()
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                sigma[x:xx]= sigma_[ix]
              }
            }
            print(c("sigma:",sigma,"beta :",beta))
            Keep_going=F
            if(it==1){
              diff_o=0
            }
            if(it>1){
              if(SF>1){
                diff_o=mean(abs(sigma_o-sigma))
              }
              if(SF==2){
                diff_o=0.0001
              }
              if(SB==1){
                diff_o=max(diff_o,mean(abs(beta_o-beta)))
              }
              if(SB>1){
                diff_o=max(diff_o,0.0001)
              }
              count_diff_o=0
              if(diff_o>=0.005){
                if(it==maxIt){
                  count_diff_o=count_diff_o+1
                  maxIt=maxIt+1
                  if(count_diff_o>10){
                    maxBit=maxBit-1
                  }
                }
              }
            }
            sigma_o=sigma
            beta_o=beta
            # browser()
            if(NC==1){
              builder=build_HMM_matrix_t(k,(rho),beta=beta,L=L,Pop=Pop,Xi_,Beta=Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
            }
            if(NC>1){
              builder=list()
              for(chr in 1:NC){
                builder[[chr]]=build_HMM_matrix_t(k,(rho[[chr]]),beta=beta,L=L[chr],Pop=Pop,Xi_,Beta=Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
              }
            }
          }

          if(NC==1){

            test.env$ER <- ER
            test.env$SF <- SF
            test.env$SB <- SB
            test.env$Os <- Os



            function_to_minimize<-function(param){
              Boxr=get('Boxr', envir=test.env)
              mu=get('mu', envir=test.env)
              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)
              mu_b=get('mu_b', envir=test.env)
              FS=get('FS', envir=test.env)
              Klink=get('Klink', envir=test.env)
              Rho=get('Rho', envir=test.env)
              BoxB=get('BoxB', envir=test.env)
              Boxs=get('Boxs', envir=test.env)
              BoxP=get('BoxP', envir=test.env)
              pop_vect=get('pop_vect', envir=test.env)
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Beta=get('Beta', envir=test.env)
              Self=get('Self', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)
              Pop=get('Pop', envir=test.env)
              ER=get('ER', envir=test.env)
              SF=get('SF', envir=test.env)
              SB=get('SB', envir=test.env)
              Os=get('Os', envir=test.env)
              start_position=0
              if(ER==1){
                rho_=numeric(n)
                rho=param[(start_position+1):(start_position+Klink)]
                rho=rho*sum(Boxr)
                rho=rho-(Boxr[1])
                rho=10^(rho)
                rho=rho*Rho
                start_position=start_position+Klink
                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  rho_[x:xx]=rho[ix]

                }

              }
              if(ER==2){
                t_r=get('t_r', envir=test.env)
                Boxr_s=get('Boxr_s', envir=test.env)
                rho_=numeric(n)
                #t_r=min(ceiling(param[(start_position+1)]*Klink),Klink)


                if(t_r>Klink){

                  rho=rep(Boxr_s[1],Klink)
                }else{
                  if(t_r>1){
                    rho=c(rep(Boxr_s[1],(t_r-1)),rep(Boxr_s[2],(Klink-t_r+1)))
                  }else{
                    rho=rep(Boxr_s[2],Klink)
                  }
                }
                rho=rho*sum(Boxr)
                rho=rho-(Boxr[1])
                rho=10^(rho)
                rho=rho*Rho


                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  rho_[x:xx]=rho[ix]

                }
              }
              if(ER==3){
                t_r=get('t_r', envir=test.env)
                Boxr_s=get('Boxr_s', envir=test.env)
                Boxr_1=get('Boxr_1', envir=test.env)
                Boxr_2=get('Boxr_2', envir=test.env)
                correct_R=get('correct_R', envir=test.env)
                rho_=numeric(n)
                #t_r=min(ceiling(param[(start_position+1)]*Klink),Klink)


                if(t_r>Klink){

                  rho=rep(Boxr_s[1],Klink)
                  rho=rho*sum(Boxr_1)
                  rho=rho-(Boxr_1[1])
                  rho=10^(rho)
                  rho=rho*Rho
                }else{
                  if(t_r>1){
                    rho=c(rep(Boxr_s[1],(t_r-1)),rep(Boxr_s[2],(Klink-t_r+1)))
                    rho=c(rho[1:(t_r-1)]*sum(Boxr_1),rho[t_r:Klink]*sum(Boxr_2))
                    rho=c(rho[1:(t_r-1)]-(Boxr_1[1]),rho[t_r:Klink]-(Boxr_2[1]))
                    rho=10^(rho)
                    rho=c(rho[1:(t_r-1)]*Rho,rho[t_r:Klink]*Rho*correct_R)
                  }else{
                    rho=rep(Boxr_s[2],Klink)
                    rho=rho*sum(Boxr_2)
                    rho=rho-(Boxr_2[1])
                    rho=10^(rho)
                    rho=rho*Rho*correct_R
                  }
                }
                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  rho_[x:xx]=rho[ix]

                }
              }
              if(ER==0){
                rho_=rep(Rho,n)
              }
              if(SF==1){
                sigma_=numeric(n)
                sigma=param[(start_position+1):(start_position+Klink)]
                start_position=start_position+Klink
                sigma=sigma*(Boxs[2]-Boxs[1])
                sigma=sigma+Boxs[1]
                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  sigma_[x:xx]=sigma[ix]
                }
              }
              if(SF==2){
                Boxs_s=get('Boxs_s', envir=test.env)
                sigma_=numeric(n)

                #t_s=min(ceiling(param[(start_position+1)]*Klink),Klink)
                t_s=get('t_s', envir=test.env)
                if(t_s>Klink){
                  sigma=rep(Boxs_s[1],Klink)
                }else{
                  if(t_s>1){
                    sigma=c(rep(Boxs_s[1],(t_s-1)),rep(Boxs_s[2],(Klink-t_s+1)))
                  }else{
                    sigma=rep(Boxs_s[2],Klink)
                  }
                }
                #start_position=start_position+1
                sigma=sigma*(Boxs[2]-Boxs[1])
                sigma=sigma+Boxs[1]
                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  sigma_[x:xx]=sigma[ix]
                }

              }
              if(SF==3){
                Boxs_s=get('Boxs_s', envir=test.env)
                Boxs_1=get('Boxs_1', envir=test.env)
                Boxs_2=get('Boxs_2', envir=test.env)
                sigma_=numeric(n)

                t_s=get('t_s', envir=test.env)
                if(t_s>Klink){
                  sigma=rep(Boxs_s[1],Klink)
                  sigma=sigma*(Boxs_1[2]-Boxs_1[1])
                  sigma=sigma+Boxs_1[1]
                }else{
                  if(t_s>1){
                    sigma=c(rep(Boxs_s[1],(t_s-1)),rep(Boxs_s[2],(Klink-t_s+1)))
                    sigma= c(sigma[1:(t_s-1)]*(Boxs_1[2]-Boxs_1[1]),sigma[t_s:Klink]*(Boxs_2[2]-Boxs_2[1]) )
                    sigma= c(sigma[1:(t_s-1)]+Boxs_1[1],sigma[t_s:Klink]+Boxs_2[1])
                  }else{
                    sigma=rep(Boxs_s[2],Klink)
                    sigma=sigma*(Boxs_2[2]-Boxs_2[1])
                    sigma=sigma+Boxs_2[1]
                  }
                }
                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  sigma_[x:xx]=sigma[ix]
                }
              }
              if(SF==0){
                sigma_=rep(sigma,n)
              }
              if(SB==1){
                beta_=numeric(n)
                beta=((param[(start_position+1):(start_position+Klink)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
                start_position=start_position+(Klink)
                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  beta_[x:xx]=beta[ix]

                }
              }
              if(SB==2){
                beta_=numeric(n)
                BoxB_s=get('BoxB_s', envir=test.env)
                #t_b=min(ceiling(param[(start_position+1)]*Klink),Klink)
                t_b=get('t_b', envir=test.env)
                if(t_b>Klink){
                  beta=rep(BoxB_s[1],Klink)
                }else{
                  if(t_b>1){
                    beta=c(rep(BoxB_s[1],(t_b-1)),rep(BoxB_s[2],(Klink-t_b+1)))
                  }else{
                    beta=rep(BoxB_s[2],Klink)
                  }
                }

                beta=((beta*(BoxB[2]-BoxB[1]))+BoxB[1])^2
                # start_position=start_position+1
                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  beta_[x:xx]=beta[ix]

                }
              }
              if(SB==3){
                beta_=numeric(n)
                BoxB_s=get('BoxB_s', envir=test.env)
                BoxB_1=get('BoxB_1', envir=test.env)
                BoxB_2=get('BoxB_2', envir=test.env)
                t_b=get('t_b', envir=test.env)
                if(t_b>Klink){
                  beta=rep(BoxB_s[1],Klink)
                  beta=((beta*(BoxB_1[2]-BoxB_1[1]))+BoxB_1[1])^2
                }else{
                  if(t_b>1){
                    beta=c(rep(BoxB_s[1],(t_b-1)),rep(BoxB_s[2],(Klink-t_b+1)))
                    beta=c((((beta[1:(t_b-1)]*(BoxB_1[2]-BoxB_1[1]))+BoxB_1[1])^2),(((beta[t_b:Klink]*(BoxB_2[2]-BoxB_2[1]))+BoxB_2[1])^2))
                  }else{
                    beta=rep(BoxB_s[2],Klink)
                    beta=((beta*(BoxB_2[2]-BoxB_2[1]))+BoxB_2[1])^2
                  }
                }


                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  beta_[x:xx]=beta[ix]

                }
              }
              if(SB==0){
                beta_=rep(beta,n)
              }
              if(!Pop){
                Xi=numeric(n)
                Xi_=param[(start_position+1):(start_position+Klink)]
                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  Xi[x:xx]=Xi_[ix]
                }
                Xi=Xi*sum(BoxP)
                Xi=Xi-(BoxP[1])
                Xi=10^Xi
              }else{
                Xi=rep(1,n)
              }

              builder=build_HMM_matrix_t(n,rho_,beta=beta_,Pop = Pop,Xi=Xi,L=L,Beta=Beta,scale=window_scaling,sigma = sigma_,Sigma = Self,Big_Window=Big_Window,npair=npair)
              Q = builder[[1]]
              nu= builder[[2]]
              Tc=builder[[3]]
              g=build_emission_matrix(mu,mu_b,Tc=builder[[4]],t=builder[[3]],beta,FS)
              MLH=0
              test=Build_zip_Matrix_mailund(Q,g,Os[[1]][[2]],nu,do_all=F)
              for(i in 1:length(Os)){
                Os[[i]][[1]]=as.numeric(Os[[i]][[1]])
                fo=forward_zip_mailund(Os[[i]][[1]],g,nu,test[[1]])
                MLH=MLH-fo[[3]]
              }
              return(MLH)
            }

            param=c()
            if(ER==1){
              param=c(param,oldrho)
            }

            if(SF==1){
              param=c(param,oldsigma)
            }

            if(SB==1){
              param=c(param,oldbeta)
            }

            if(!Popfix){
              param=c(param,oldXi_)
            }

            LH_temp=0
            if(it==1){

              if(ER==3){
                LH_temp=function_to_minimize(param)
                UP=F
                if((Boxr_s[1]+0.05)<1){
                  Boxr_s[1]=Boxr_s[1]+0.05
                  test.env$Boxr_s <- Boxr_s
                  LH_temp2=function_to_minimize(param)
                  if(LH_temp>LH_temp2){
                    UP=T
                    LH_temp=LH_temp2
                  }else{
                    Boxr_s[1]=Boxr_s[1]-0.05
                    test.env$Boxr_s <- Boxr_s
                  }
                }

                if(UP){
                  while(UP){
                    if((Boxr_s[1]+0.05)<1){
                      Boxr_s[1]=Boxr_s[1]+0.05
                      test.env$Boxr_s <- Boxr_s
                      UP=F
                      LH_temp2=function_to_minimize(param)
                      if(LH_temp>LH_temp2){
                        UP=T
                        LH_temp=LH_temp2
                      }else{
                        Boxr_s[1]=Boxr_s[1]-0.05
                        test.env$Boxr_s <- Boxr_s
                      }
                    }else{
                      UP=F
                    }
                  }
                }else{
                  DOWN=F
                  if((Boxr_s[1]-0.05)>0){
                    Boxr_s[1]=Boxr_s[1]-0.05
                    test.env$Boxr_s <- Boxr_s
                    LH_temp2=function_to_minimize(param)
                    if(LH_temp>LH_temp2){
                      DOWN=T
                      LH_temp=LH_temp2
                    }else{
                      Boxr_s[1]=Boxr_s[1]+0.05
                      test.env$Boxr_s <- Boxr_s
                    }
                  }
                  while(DOWN){
                    if((Boxr_s[1]-0.05)>0){
                      Boxr_s[1]=Boxr_s[1]-0.05
                      test.env$Boxr_s <- Boxr_s
                      DOWN=F
                      LH_temp2=function_to_minimize(param)
                      if(LH_temp>LH_temp2){
                        DOWN=T
                        LH_temp=LH_temp2
                      }else{
                        Boxr_s[1]=Boxr_s[1]+0.05
                        test.env$Boxr_s <- Boxr_s
                      }
                    }else{
                      DOWN=F
                    }
                  }
                }


                UP=F
                if((Boxr_s[2]+0.05)<1){
                  Boxr_s[2]=Boxr_s[2]+0.05
                  test.env$Boxr_s <- Boxr_s
                  LH_temp2=function_to_minimize(param)
                  if(LH_temp>LH_temp2){
                    UP=T
                    LH_temp=LH_temp2
                  }else{
                    Boxr_s[2]=Boxr_s[2]-0.05
                    test.env$Boxr_s <- Boxr_s
                  }
                }

                if(UP){
                  while(UP){
                    if((Boxr_s[2]+0.05)<1){
                      Boxr_s[2]=Boxr_s[2]+0.05
                      test.env$Boxr_s <- Boxr_s
                      UP=F
                      LH_temp2=function_to_minimize(param)
                      if(LH_temp>LH_temp2){
                        UP=T
                        LH_temp=LH_temp2
                      }else{
                        Boxr_s[2]=Boxr_s[2]-0.05
                        test.env$Boxr_s <- Boxr_s
                      }
                    }else{
                      UP=F
                    }
                  }
                }else{
                  DOWN=F
                  if((Boxr_s[2]-0.05)>0){
                    Boxr_s[2]=Boxr_s[2]-0.05
                    test.env$Boxr_s <- Boxr_s
                    LH_temp2=function_to_minimize(param)
                    if(LH_temp>LH_temp2){
                      DOWN=T
                      LH_temp=LH_temp2
                    }else{
                      Boxr_s[2]=Boxr_s[2]+0.05
                      test.env$Boxr_s <- Boxr_s
                    }
                  }
                  while(DOWN){
                    if((Boxr_s[2]-0.05)>0){
                      Boxr_s[2]=Boxr_s[2]-0.05
                      test.env$Boxr_s <- Boxr_s
                      DOWN=F
                      LH_temp2=function_to_minimize(param)
                      if(LH_temp>LH_temp2){
                        DOWN=T
                        LH_temp=LH_temp2
                      }else{
                        Boxr_s[2]=Boxr_s[2]+0.05
                        test.env$Boxr_s <- Boxr_s
                      }
                    }else{
                      DOWN=F
                    }
                  }
                }



              }

              if(SF==3){
                LH_temp=function_to_minimize(param)
                Boxs_s[1]=Boxs_s[1]+0.05
                test.env$Boxs_s <- Boxs_s
                UP=F
                LH_temp2=function_to_minimize(param)
                if(LH_temp>LH_temp2){
                  UP=T
                  LH_temp=LH_temp2
                }else{
                  Boxs_s[1]=Boxs_s[1]-0.05
                  test.env$Boxs_s <- Boxs_s
                }
                while(UP){
                  if((Boxs_s[1]+0.05)<1){
                    Boxs_s[1]=Boxs_s[1]+0.05
                    test.env$Boxs_s <- Boxs_s
                    UP=F
                    LH_temp2=function_to_minimize(param)
                    if(LH_temp>LH_temp2){
                      UP=T
                      LH_temp=LH_temp2
                    }else{
                      Boxs_s[1]=Boxs_s[1]-0.05
                      test.env$Boxs_s <- Boxs_s
                    }
                  }else{
                    UP=F
                  }
                }
                Boxs_s[2]=Boxs_s[2]+0.05
                test.env$Boxs_s <- Boxs_s
                UP=F
                LH_temp2=function_to_minimize(param)
                if(LH_temp>LH_temp2){
                  UP=T
                  LH_temp=LH_temp2
                }else{
                  Boxs_s[2]=Boxs_s[2]-0.05
                  test.env$Boxs_s <- Boxs_s
                }
                while(UP){
                  if((Boxs_s[2]+0.05)<1){
                    Boxs_s[2]=Boxs_s[2]+0.05
                    test.env$Boxs_s <- Boxs_s
                    UP=F
                    LH_temp2=function_to_minimize(param)
                    if(LH_temp>LH_temp2){
                      UP=T
                      LH_temp=LH_temp2
                    }else{
                      Boxs_s[2]=Boxs_s[2]-0.05
                      test.env$Boxs_s <- Boxs_s
                    }
                  }else{
                    UP=F
                  }
                }


              }

              if(SB==3){
                LH_temp=function_to_minimize(param)
                BoxB_s[1]=BoxB_s[1]-0.05
                test.env$BoxB_s <- BoxB_s
                DOWN=F
                LH_temp2=function_to_minimize(param)
                if(LH_temp>LH_temp2){
                  DOWN=T
                  LH_temp=LH_temp2
                }else{
                  BoxB_s[1]=BoxB_s[1]+0.05
                  test.env$BoxB_s <- BoxB_s
                }
                while(DOWN){
                  if((BoxB_s[1]-0.05)>0){
                    BoxB_s[1]=BoxB_s[1]-0.05
                    test.env$BoxB_s <- BoxB_s
                    DOWN=F
                    LH_temp2=function_to_minimize(param)
                    if(LH_temp>LH_temp2){
                      DOWN=T
                      LH_temp=LH_temp2
                    }else{
                      BoxB_s[1]=BoxB_s[1]+0.05
                      test.env$BoxB_s <- BoxB_s
                    }
                  }else{
                    DOWN=F
                  }
                }
                BoxB_s[2]=BoxB_s[2]-0.05
                test.env$BoxB_s <- BoxB_s
                DOWN=F
                LH_temp2=function_to_minimize(param)
                if(LH_temp>LH_temp2){
                  DOWN=T
                  LH_temp=LH_temp2
                }else{
                  BoxB_s[2]=BoxB_s[2]+0.05
                  test.env$BoxB_s <- BoxB_s
                }
                while(DOWN){
                  if((BoxB_s[2]-0.05)>0){
                    BoxB_s[2]=BoxB_s[2]-0.05
                    test.env$BoxB_s <- BoxB_s
                    DOWN=F
                    LH_temp2=function_to_minimize(param)
                    if(LH_temp>LH_temp2){
                      DOWN=T
                      LH_temp=LH_temp2
                    }else{
                      BoxB_s[2]=BoxB_s[2]+0.05
                      test.env$BoxB_s <- BoxB_s
                    }
                  }else{
                    DOWN=F
                  }
                }


              }


              if(ER>1){
                for(t_r in 1:(1+Klink)){
                  test.env$t_r <- t_r
                  if(SB>1){
                    for( t_b in 1:(1+Klink)){
                      test.env$t_b <- t_b
                      if(SF>1){

                        for(t_s in 1:(1+Klink)){
                          test.env$t_s <- t_s

                          sol_temp=function_to_minimize(param)
                          if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                            LH_temp=as.numeric(sol_temp)
                            oldtr=t_r
                            oldtb=t_b
                            oldts=t_s

                          }

                        }

                      }else{
                        sol_temp=function_to_minimize(param)
                        if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                          LH_temp=as.numeric(sol_temp)
                          oldtr=t_r
                          oldtb=t_b

                        }
                      }
                    }

                  }else{ # NO  SB
                    if(SF>1){
                      for(t_s in 1:(1+Klink)){
                        test.env$t_s <- t_s
                        sol_temp=function_to_minimize(param)
                        if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                          LH_temp=as.numeric(sol_temp)
                          oldtr=t_r
                          oldts=t_s

                        }
                      }
                    }else{
                      sol_temp=function_to_minimize(param)
                      if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                        LH_temp=as.numeric(sol_temp)
                        oldtr=t_r

                      }
                    }
                  }
                }
              }else{ # No ER
                if(SB>1){
                  for( t_b in 1:(1+Klink)){
                    test.env$t_b <- t_b
                    if(SF>1){

                      for(t_s in 1:(1+Klink)){
                        test.env$t_s <- t_s
                        sol_temp=function_to_minimize(param)
                        if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                          LH_temp=as.numeric(sol_temp)
                          oldtb=t_b
                          oldts=t_s

                        }
                      }
                    }else{
                      sol_temp=function_to_minimize(param)
                      if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                        LH_temp=as.numeric(sol_temp)
                        oldtb=t_b

                      }
                    }
                  }
                }else{
                  if(SF>1){

                    for(t_s in 1:(1+Klink)){
                      test.env$t_s <- t_s
                      sol_temp=function_to_minimize(param)
                      print(sol_temp)
                      if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                        LH_temp=as.numeric(sol_temp)
                        oldts=t_s


                      }
                    }
                  }else{

                    stop("How did you get here ?")

                  }
                }
              }
            }else{

              if(ER==3){
                LH_temp=function_to_minimize(param)
                UP=F
                if((Boxr_s[1]+0.05)<1){
                  Boxr_s[1]=Boxr_s[1]+0.05
                  test.env$Boxr_s <- Boxr_s
                  LH_temp2=function_to_minimize(param)
                  if(LH_temp>LH_temp2){
                    UP=T
                    LH_temp=LH_temp2
                  }else{
                    Boxr_s[1]=Boxr_s[1]-0.05
                    test.env$Boxr_s <- Boxr_s
                  }
                }

                if(UP){
                  while(UP){
                    if((Boxr_s[1]+0.05)<1){
                      Boxr_s[1]=Boxr_s[1]+0.05
                      test.env$Boxr_s <- Boxr_s
                      UP=F
                      LH_temp2=function_to_minimize(param)
                      if(LH_temp>LH_temp2){
                        UP=T
                        LH_temp=LH_temp2
                      }else{
                        Boxr_s[1]=Boxr_s[1]-0.05
                        test.env$Boxr_s <- Boxr_s
                      }
                    }else{
                      UP=F
                    }
                  }
                }else{
                  DOWN=F
                  if((Boxr_s[1]-0.05)>0){
                    Boxr_s[1]=Boxr_s[1]-0.05
                    test.env$Boxr_s <- Boxr_s
                    LH_temp2=function_to_minimize(param)
                    if(LH_temp>LH_temp2){
                      DOWN=T
                      LH_temp=LH_temp2
                    }else{
                      Boxr_s[1]=Boxr_s[1]+0.05
                      test.env$Boxr_s <- Boxr_s
                    }
                  }
                  while(DOWN){
                    if((Boxr_s[1]-0.05)>0){
                      Boxr_s[1]=Boxr_s[1]-0.05
                      test.env$Boxr_s <- Boxr_s
                      DOWN=F
                      LH_temp2=function_to_minimize(param)
                      if(LH_temp>LH_temp2){
                        DOWN=T
                        LH_temp=LH_temp2
                      }else{
                        Boxr_s[1]=Boxr_s[1]+0.05
                        test.env$Boxr_s <- Boxr_s
                      }
                    }else{
                      DOWN=F
                    }
                  }
                }


                UP=F
                if((Boxr_s[2]+0.05)<1){
                  Boxr_s[2]=Boxr_s[2]+0.05
                  test.env$Boxr_s <- Boxr_s
                  LH_temp2=function_to_minimize(param)
                  if(LH_temp>LH_temp2){
                    UP=T
                    LH_temp=LH_temp2
                  }else{
                    Boxr_s[2]=Boxr_s[2]-0.05
                    test.env$Boxr_s <- Boxr_s
                  }
                }

                if(UP){
                  while(UP){
                    if((Boxr_s[2]+0.05)<1){
                      Boxr_s[2]=Boxr_s[2]+0.05
                      test.env$Boxr_s <- Boxr_s
                      UP=F
                      LH_temp2=function_to_minimize(param)
                      if(LH_temp>LH_temp2){
                        UP=T
                        LH_temp=LH_temp2
                      }else{
                        Boxr_s[2]=Boxr_s[2]-0.05
                        test.env$Boxr_s <- Boxr_s
                      }
                    }else{
                      UP=F
                    }
                  }
                }else{
                  DOWN=F
                  if((Boxr_s[2]-0.05)>0){
                    Boxr_s[2]=Boxr_s[2]-0.05
                    test.env$Boxr_s <- Boxr_s
                    LH_temp2=function_to_minimize(param)
                    if(LH_temp>LH_temp2){
                      DOWN=T
                      LH_temp=LH_temp2
                    }else{
                      Boxr_s[2]=Boxr_s[2]+0.05
                      test.env$Boxr_s <- Boxr_s
                    }
                  }
                  while(DOWN){
                    if((Boxr_s[2]-0.05)>0){
                      Boxr_s[2]=Boxr_s[2]-0.05
                      test.env$Boxr_s <- Boxr_s
                      DOWN=F
                      LH_temp2=function_to_minimize(param)
                      if(LH_temp>LH_temp2){
                        DOWN=T
                        LH_temp=LH_temp2
                      }else{
                        Boxr_s[2]=Boxr_s[2]+0.05
                        test.env$Boxr_s <- Boxr_s
                      }
                    }else{
                      DOWN=F
                    }
                  }
                }



              }


              if(SF==3){
                LH_temp=function_to_minimize(param)

                if((Boxs_s[1]+0.05)<1){

                  Boxs_s[1]=Boxs_s[1]+0.05
                  test.env$Boxs_s <- Boxs_s
                  UP=F
                  LH_temp2=function_to_minimize(param)
                  if(LH_temp>LH_temp2){
                    UP=T
                    LH_temp=LH_temp2
                  }else{
                    Boxs_s[1]=Boxs_s[1]-0.05
                    test.env$Boxs_s <- Boxs_s
                  }
                  while(UP){
                    if((Boxs_s[1]+0.05)<1){
                      Boxs_s[1]=Boxs_s[1]+0.05
                      test.env$Boxs_s <- Boxs_s
                      UP=F
                      LH_temp2=function_to_minimize(param)
                      if(LH_temp>LH_temp2){
                        UP=T
                        LH_temp=LH_temp2
                      }else{
                        Boxs_s[1]=Boxs_s[1]-0.05
                        test.env$Boxs_s <- Boxs_s
                      }
                    }else{
                      UP=F
                    }
                  }

                }

                if((Boxs_s[1]-0.05)>0){

                  Boxs_s[1]=Boxs_s[1]-0.05
                  test.env$Boxs_s <- Boxs_s
                  DOWN=F
                  LH_temp2=function_to_minimize(param)
                  if(LH_temp>LH_temp2){
                    DOWN=T
                    LH_temp=LH_temp2
                  }else{
                    Boxs_s[1]=Boxs_s[1]+0.05
                    test.env$Boxs_s <- Boxs_s
                  }
                  while(DOWN){
                    if((Boxs_s[1]-0.05)<1){
                      Boxs_s[1]=Boxs_s[1]-0.05
                      test.env$Boxs_s <- Boxs_s
                      DOWN=F
                      LH_temp2=function_to_minimize(param)
                      if(LH_temp>LH_temp2){
                        DOWN=T
                        LH_temp=LH_temp2
                      }else{
                        Boxs_s[1]=Boxs_s[1]+0.05
                        test.env$Boxs_s <- Boxs_s
                      }
                    }else{
                      DOWN=F
                    }
                  }

                }

                if((Boxs_s[2]+0.05)<1){
                  Boxs_s[2]=Boxs_s[2]+0.05
                  test.env$Boxs_s <- Boxs_s
                  UP=F
                  LH_temp2=function_to_minimize(param)
                  if(LH_temp>LH_temp2){
                    UP=T
                    LH_temp=LH_temp2
                  }else{
                    Boxs_s[2]=Boxs_s[2]-0.05
                    test.env$Boxs_s <- Boxs_s
                  }
                  while(UP){
                    if((Boxs_s[2]+0.05)<1){
                      Boxs_s[2]=Boxs_s[2]+0.05
                      test.env$Boxs_s <- Boxs_s
                      UP=F
                      LH_temp2=function_to_minimize(param)
                      if(LH_temp>LH_temp2){
                        UP=T
                        LH_temp=LH_temp2
                      }else{
                        Boxs_s[2]=Boxs_s[2]-0.05
                        test.env$Boxs_s <- Boxs_s
                      }
                    }else{
                      UP=F
                    }
                  }
                }

                if((Boxs_s[2]-0.05)>0){
                  Boxs_s[2]=Boxs_s[2]-0.05
                  test.env$Boxs_s <- Boxs_s
                  DOWN=F
                  LH_temp2=function_to_minimize(param)
                  if(LH_temp>LH_temp2){
                    DOWN=T
                    LH_temp=LH_temp2
                  }else{
                    Boxs_s[2]=Boxs_s[2]+0.05
                    test.env$Boxs_s <- Boxs_s
                  }
                  while(DOWN){
                    if((Boxs_s[2]-0.05)>0){
                      Boxs_s[2]=Boxs_s[2]-0.05
                      test.env$Boxs_s <- Boxs_s
                      DOWN=F
                      LH_temp2=function_to_minimize(param)
                      if(LH_temp>LH_temp2){
                        DOWN=T
                        LH_temp=LH_temp2
                      }else{
                        Boxs_s[2]=Boxs_s[2]+0.05
                        test.env$Boxs_s <- Boxs_s
                      }
                    }else{
                      DOWN=F
                    }
                  }
                }

              }

              if(SB==3){
                LH_temp=function_to_minimize(param)

                if((BoxB_s[1]-0.05>0)){
                  BoxB_s[1]=BoxB_s[1]-0.05
                  test.env$BoxB_s <- BoxB_s
                  DOWN=F
                  LH_temp2=function_to_minimize(param)
                  if(LH_temp>LH_temp2){
                    DOWN=T
                    LH_temp=LH_temp2
                  }else{
                    BoxB_s[1]=BoxB_s[1]+0.05
                    test.env$BoxB_s <- BoxB_s
                  }
                  while(DOWN){
                    if((BoxB_s[1]-0.05)>0){
                      BoxB_s[1]=BoxB_s[1]-0.05
                      test.env$BoxB_s <- BoxB_s
                      DOWN=F
                      LH_temp2=function_to_minimize(param)
                      if(LH_temp>LH_temp2){
                        DOWN=T
                        LH_temp=LH_temp2
                      }else{
                        BoxB_s[1]=BoxB_s[1]+0.05
                        test.env$BoxB_s <- BoxB_s
                      }
                    }else{
                      DOWN=F
                    }
                  }
                }

                if((BoxB_s[1]+0.05<1)){
                  BoxB_s[1]=BoxB_s[1]+0.05
                  test.env$BoxB_s <- BoxB_s
                  UP=F
                  LH_temp2=function_to_minimize(param)
                  if(LH_temp>LH_temp2){
                    UP=T
                    LH_temp=LH_temp2
                  }else{
                    BoxB_s[1]=BoxB_s[1]-0.05
                    test.env$BoxB_s <- BoxB_s
                  }
                  while(UP){
                    if((BoxB_s[1]+0.05)<1){
                      BoxB_s[1]=BoxB_s[1]+0.05
                      test.env$BoxB_s <- BoxB_s
                      UP=F
                      LH_temp2=function_to_minimize(param)
                      if(LH_temp>LH_temp2){
                        UP=T
                        LH_temp=LH_temp2
                      }else{
                        BoxB_s[1]=BoxB_s[1]-0.05
                        test.env$BoxB_s <- BoxB_s
                      }
                    }else{
                      UP=F
                    }
                  }
                }

                if(BoxB_s[2]-0.05>0){
                  BoxB_s[2]=BoxB_s[2]-0.05
                  test.env$BoxB_s <- BoxB_s
                  DOWN=F
                  LH_temp2=function_to_minimize(param)
                  if(LH_temp>LH_temp2){
                    DOWN=T
                    LH_temp=LH_temp2
                  }else{
                    BoxB_s[2]=BoxB_s[2]+0.05
                    test.env$BoxB_s <- BoxB_s
                  }
                  while(DOWN){
                    if((BoxB_s[2]-0.05)>0){
                      BoxB_s[2]=BoxB_s[2]-0.05
                      test.env$BoxB_s <- BoxB_s
                      DOWN=F
                      LH_temp2=function_to_minimize(param)
                      if(LH_temp>LH_temp2){
                        DOWN=T
                        LH_temp=LH_temp2
                      }else{
                        BoxB_s[2]=BoxB_s[2]+0.05
                        test.env$BoxB_s <- BoxB_s
                      }
                    }else{
                      DOWN=F
                    }
                  }

                }

                if(BoxB_s[2]+0.05<1){
                  BoxB_s[2]=BoxB_s[2]+0.05
                  test.env$BoxB_s <- BoxB_s
                  UP=F
                  LH_temp2=function_to_minimize(param)
                  if(LH_temp>LH_temp2){
                    UP=T
                    LH_temp=LH_temp2
                  }else{
                    BoxB_s[2]=BoxB_s[2]-0.05
                    test.env$BoxB_s <- BoxB_s
                  }
                  while(UP){
                    if((BoxB_s[2]+0.05)<1){
                      BoxB_s[2]=BoxB_s[2]+0.05
                      test.env$BoxB_s <- BoxB_s
                      UP=F
                      LH_temp2=function_to_minimize(param)
                      if(LH_temp>LH_temp2){
                        UP=T
                        LH_temp=LH_temp2
                      }else{
                        BoxB_s[2]=BoxB_s[2]-0.05
                        test.env$BoxB_s <- BoxB_s
                      }
                    }else{
                      UP=F
                    }
                  }

                }

              }

              if(ER>1){
                for(t_r in max(1,(oldtr-1)):min((1+Klink),(oldtr+1))){
                  test.env$t_r <- t_r
                  if(SB>1){
                    for( t_b in max(1,(oldtb-1)):min((1+Klink),(oldtb+1))){
                      test.env$t_b <- t_b
                      if(SF>1){

                        for(t_s in max(1,(oldts-1)):min((1+Klink),(oldts+1))){
                          test.env$t_s <- t_s

                          sol_temp=function_to_minimize(param)
                          if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                            LH_temp=as.numeric(sol_temp)
                            oldtr=t_r
                            oldtb=t_b
                            oldts=t_s

                          }

                        }

                      }else{
                        sol_temp=function_to_minimize(param)
                        if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                          LH_temp=as.numeric(sol_temp)
                          oldtr=t_r
                          oldtb=t_b

                        }
                      }
                    }

                  }else{ # NO  SB
                    if(SF>1){
                      for(t_s in max(1,(oldts-1)):min((1+Klink),(oldts+1))){
                        test.env$t_s <- t_s
                        sol_temp=function_to_minimize(param)
                        if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                          LH_temp=as.numeric(sol_temp)
                          oldtr=t_r
                          oldts=t_s

                        }
                      }
                    }else{
                      sol_temp=function_to_minimize(param)
                      if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                        LH_temp=as.numeric(sol_temp)
                        oldtr=t_r

                      }
                    }
                  }
                }
              }else{ # No ER
                if(SB>1){
                  for( t_b in max(1,(oldtb-1)):min((1+Klink),(oldtb+1))){
                    test.env$t_b <- t_b
                    if(SF>1){

                      for(t_s in max(1,(oldts-1)):min((1+Klink),(oldts+1))){
                        test.env$t_s <- t_s
                        sol_temp=function_to_minimize(param)
                        if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                          LH_temp=as.numeric(sol_temp)
                          oldtb=t_b
                          oldts=t_s

                        }
                      }
                    }else{
                      sol_temp=function_to_minimize(param)
                      if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                        LH_temp=as.numeric(sol_temp)
                        oldtb=t_b

                      }
                    }
                  }
                }else{
                  if(SF>1){

                    for(t_s in max(1,(oldts-1)):min((1+Klink),(oldts+1))){
                      test.env$t_s <- t_s
                      sol_temp=function_to_minimize(param)
                      print(sol_temp)
                      if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                        LH_temp=as.numeric(sol_temp)
                        oldts=t_s


                      }
                    }
                  }else{

                    stop("How did you get here ?")

                  }
                }
              }
            }


            if(ER>1){
              test.env$t_r <- oldtr

              if(oldtr>Klink){
                oldrho=rep(Boxr_s[1],(Klink))
              }else{
                if(oldtr>1){
                  oldrho=c(rep(Boxr_s[1],(oldtr-1)),rep(Boxr_s[2],(Klink+1-oldtr)))
                }else{
                  oldrho=rep(Boxr_s[2],(Klink))
                }
              }



            }


            if(SF>1){

              test.env$t_s <- oldts
              test.env$Boxs_s <- Boxs_s

              print(oldts)
              print(Boxs_s)

              if(oldts>Klink){
                oldsigma=rep(Boxs_s[1],(Klink))
              }else{
                if(oldts>1){
                  oldsigma=c(rep(Boxs_s[1],(oldts-1)),rep(Boxs_s[2],(Klink+1-oldts)))
                }else{
                  oldsigma=rep(Boxs_s[2],(Klink))
                }
              }


            }

            if(SB>1){

              test.env$t_b <- oldtb
              if(oldtb>Klink){
                oldbeta=rep(BoxB_s[1],(Klink))
              }else{
                if(oldtb>1){
                  oldbeta=c(rep(BoxB_s[1],(oldtb-1)),rep(BoxB_s[2],(Klink+1-oldtb)))
                }else{
                  oldbeta=rep(BoxB_s[2],(Klink))
                }
              }


            }

            if(Popfix){
              if(ER<3){
                if(!is.list(oldrho)){
                  rho_=oldrho*sum(Boxr)
                  rho_=rho_-(Boxr[1])
                  rho_=10^(rho_)
                  rho_=rho_*Rho
                  rho=vector()
                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    rho[x:xx]= rho_[ix]
                  }
                }else{
                  rho_=list()
                  rho=list()
                  for(rr in 1:NC){
                    rho_[[rr]]=oldrho[[rr]]*sum(Boxr)
                    rho_[[rr]]=rho_[[rr]]-(Boxr[1])
                    rho_[[rr]]=10^(rho_[[rr]])
                    rho_[[rr]]=rho_[[rr]]*Rho[rr]

                    xx=0
                    rho[[rr]]=vector()
                    for(ix in 1:Klink){
                      x=xx+1
                      xx = xx + pop_vect[ix]
                      rho[[rr]][x:xx]= rho_[[rr]][ix]
                    }
                  }

                }
              }else{
                if(!is.list(oldrho)){
                  rho=vector()
                  if(oldtr==1){
                    rho_=oldrho*sum(Boxr_2)
                    rho_=rho_-(Boxr_2[1])
                    rho_=10^(rho_)
                    rho_=rho_*Rho
                  }
                  if(oldtr>Klink){
                    rho_=oldrho*sum(Boxr_1)
                    rho_=rho_-(Boxr_1[1])
                    rho_=10^(rho_)
                    rho_=rho_*Rho*correct_R
                  }
                  if(oldtr>1&oldtr<=Klink){
                    rho_=c(oldrho[1:(oldtr-1)]*sum(Boxr_1),oldrho[oldtr:Klink]*sum(Boxr_2))
                    rho_=c(rho_[1:(oldtr-1)]-(Boxr_1[1]),rho_[oldtr:Klink]-(Boxr_2[1]))
                    rho_=10^(rho_)
                    rho_=c(rho_[1:(oldtr-1)]*Rho,rho_[oldtr:Klink]*Rho*correct_R)

                  }




                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    rho[x:xx]= rho_[ix]
                  }
                }else{
                  rho_=list()
                  rho=list()
                  for(rr in 1:NC){


                    if(oldtr==1){
                      rho_[[rr]]=oldrho[[rr]]*sum(Boxr_2)
                      rho_[[rr]]=rho_[[rr]]-(Boxr_2[1])
                      rho_[[rr]]=10^(rho_[[rr]])
                      rho_[[rr]]=rho_[[rr]]*Rho[rr]
                    }
                    if(oldtr>Klink){
                      rho_[[rr]]=oldrho[[rr]]*sum(Boxr_1)
                      rho_[[rr]]=rho_[[rr]]-(Boxr_1[1])
                      rho_[[rr]]=10^(rho_[[rr]])
                      rho_[[rr]]=rho_[[rr]]*Rho[rr]*correct_R
                    }
                    if(oldtr>1&oldtr<=Klink){


                      rho_[[rr]]=c(oldrho[[rr]][1:(oldtr-1)]*sum(Boxr_1),oldrho[[rr]][oldtr:Klink]*sum(Boxr_2))
                      rho_[[rr]]=c(rho_[[rr]][1:(oldtr-1)]-(Boxr_1[1]),rho_[[rr]][oldtr:Klink]-(Boxr_2[1]))
                      rho_[[rr]]=10^(rho_[[rr]])
                      rho_[[rr]]=c(rho_[[rr]][1:(oldtr-1)]*Rho[rr],rho_[[rr]][oldtr:Klink]*Rho[rr]*correct_R)
                    }


                    xx=0
                    rho[[rr]]=vector()
                    for(ix in 1:Klink){
                      x=xx+1
                      xx = xx + pop_vect[ix]
                      rho[[rr]][x:xx]= rho_[[rr]][ix]
                    }
                  }

                }
              }


              if(SB>0){
                if(SB<3){
                  beta_=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1] )^2
                }else{
                  if(oldtb==1){
                    beta_=((oldbeta*(BoxB_2[2]-BoxB_2[1]))+BoxB_2[1] )^2
                  }else{
                    if(oldtb>Klink){
                      beta_=((oldbeta*(BoxB_1[2]-BoxB_1[1]))+BoxB_1[1] )^2
                    }else{
                      beta_= c( ((oldbeta[1:(oldtb-1)]*(BoxB_1[2]-BoxB_1[1]))+BoxB_1[1] )^2 , ((oldbeta[oldtb:Klink]*(BoxB_2[2]-BoxB_2[1]))+BoxB_2[1] )^2 )
                    }
                  }


                }

                beta=vector()
                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  beta[x:xx]=beta_[ix]
                }
              }
              if(SF>0){
                if(SF<3){
                  sigma_=oldsigma*(Boxs[2]-Boxs[1])
                  sigma_=sigma_+Boxs[1]
                }else{
                  if(oldts==1){
                    sigma_=oldsigma*(Boxs_2[2]-Boxs_2[1])
                    sigma_=sigma_+Boxs_2[1]
                  }else{
                    if(oldts>Klink){
                      sigma_=oldsigma*(Boxs_1[2]-Boxs_1[1])
                      sigma_=sigma_+Boxs_1[1]
                    }else{
                      sigma_= c(oldsigma[1:(oldts-1)]*(Boxs_1[2]-Boxs_1[1]) ,oldsigma[oldts:Klink]*(Boxs_2[2]-Boxs_2[1]))
                      sigma_= c( (sigma_[1:(oldts-1)]+Boxs_1[1]) , (sigma_[oldts:Klink]+Boxs_2[1]))
                    }
                  }
                }


                sigma=vector()
                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  sigma[x:xx]= sigma_[ix]
                }
              }
              print(c("sigma:",sigma,"beta :",beta))
              if(is.list(rho_)){
                print(c("rho/theta:",rho_[[1]]/theta))
              }else{
                print(c("rho/theta:",rho_/theta))
              }
              Keep_going=F
              if(it==1){
                diff_o=0
              }
              if(it>1){
                if(SF==1){
                  diff_o=mean(abs(sigma_o-sigma))
                }
                if(SF>1){
                  diff_o=0.0001
                }
                if(SB==1){
                  diff_o=max(diff_o,mean(abs(beta_o-beta)))
                }
                if(SB>1){
                  diff_o=max(diff_o,0.0001)
                }
                count_diff_o=0
                if(diff_o>=0.005){
                  if(it==maxIt){
                    count_diff_o=count_diff_o+1
                    maxIt=maxIt+1
                    if(count_diff_o>10){
                      maxBit=maxBit-1
                    }
                  }
                }
              }
              sigma_o=sigma
              beta_o=beta



              if(NC==1){
                builder=build_HMM_matrix_t(k,(rho),beta=beta,L=L,Pop=Pop,Xi=NA,Beta=Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
              }
              if(NC>1){
                builder=list()
                for(chr in 1:NC){
                  builder[[chr]]=build_HMM_matrix_t(k,(rho[[chr]]),beta=beta,L=L[chr],Pop=Pop,Xi=NA,Beta=Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
                }
              }
            }

            if(!Popfix){
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                oldXi[x:xx]=oldXi_[ix]
              }
              Xi_=oldXi*sum(BoxP)
              Xi_=Xi_-(BoxP[1])
              Xi_=10^Xi_
              if(ER<3){
                if(!is.list(oldrho)){
                  rho_=oldrho*sum(Boxr)
                  rho_=rho_-(Boxr[1])
                  rho_=10^(rho_)
                  rho_=rho_*Rho
                  rho=vector()
                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    rho[x:xx]= rho_[ix]
                  }
                }else{
                  rho_=list()
                  rho=list()
                  for(rr in 1:NC){
                    rho_[[rr]]=oldrho[[rr]]*sum(Boxr)
                    rho_[[rr]]=rho_[[rr]]-(Boxr[1])
                    rho_[[rr]]=10^(rho_[[rr]])
                    rho_[[rr]]=rho_[[rr]]*Rho[rr]

                    xx=0
                    rho[[rr]]=vector()
                    for(ix in 1:Klink){
                      x=xx+1
                      xx = xx + pop_vect[ix]
                      rho[[rr]][x:xx]= rho_[[rr]][ix]
                    }
                  }

                }
              }else{
                if(!is.list(oldrho)){
                  rho=vector()
                  if(oldtr==1){
                    rho_=oldrho*sum(Boxr_2)
                    rho_=rho_-(Boxr_2[1])
                    rho_=10^(rho_)
                    rho_=rho_*Rho
                  }
                  if(oldtr>Klink){
                    rho_=oldrho*sum(Boxr_1)
                    rho_=rho_-(Boxr_1[1])
                    rho_=10^(rho_)
                    rho_=rho_*Rho*correct_R
                  }
                  if((oldtr>1)&oldtr<=Klink){
                    rho_=c(oldrho[1:(oldtr-1)]*sum(Boxr_1),oldrho[oldtr:Klink]*sum(Boxr_2))
                    rho_=c(rho_[1:(oldtr-1)]-(Boxr_1[1]),rho_[oldtr:Klink]-(Boxr_2[1]))
                    rho_=10^(rho_)
                    rho_=c(rho_[1:(oldtr-1)]*Rho,rho_[oldtr:Klink]*Rho*correct_R)
                  }




                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    rho[x:xx]= rho_[ix]
                  }
                }else{
                  rho_=list()
                  rho=list()
                  for(rr in 1:NC){


                    if(oldtr==1){
                      rho_[[rr]]=oldrho[[rr]]*sum(Boxr_2)
                      rho_[[rr]]=rho_[[rr]]-(Boxr_2[1])
                      rho_[[rr]]=10^(rho_[[rr]])
                      rho_[[rr]]=rho_[[rr]]*Rho[rr]
                    }
                    if(oldtr>Klink){
                      rho_[[rr]]=oldrho[[rr]]*sum(Boxr_1)
                      rho_[[rr]]=rho_[[rr]]-(Boxr_1[1])
                      rho_[[rr]]=10^(rho_[[rr]])
                      rho_[[rr]]=rho_[[rr]]*Rho[rr]*correct_R
                    }
                    if((oldtr>1)&oldtr<=Klink){
                      rho_[[rr]]=c(oldrho[[rr]][1:(oldtr-1)]*sum(Boxr_1),oldrho[[rr]][oldtr:Klink]*sum(Boxr_2))
                      rho_[[rr]]=c(rho_[[rr]][1:(oldtr-1)]-(Boxr_1[1]),rho_[[rr]][oldtr:Klink]-(Boxr_2[1]))
                      rho_[[rr]]=10^(rho_[[rr]])
                      rho_[[rr]]=c(rho_[[rr]][1:(oldtr-1)]*Rho[rr],rho_[[rr]][oldtr:Klink]*Rho[rr]*correct_R)

                    }


                    xx=0
                    rho[[rr]]=vector()
                    for(ix in 1:Klink){
                      x=xx+1
                      xx = xx + pop_vect[ix]
                      rho[[rr]][x:xx]= rho_[[rr]][ix]
                    }
                  }

                }
              }
              if(SB>0){
                if(SB<3){
                  beta_=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1] )^2
                }else{
                  if(oldtb==1){
                    beta_=((oldbeta*(BoxB_2[2]-BoxB_2[1]))+BoxB_2[1] )^2
                  }else{
                    if(oldtb>Klink){
                      beta_=((oldbeta*(BoxB_1[2]-BoxB_1[1]))+BoxB_1[1] )^2
                    }else{
                      beta_= c( ((oldbeta[1:(oldtb-1)]*(BoxB_1[2]-BoxB_1[1]))+BoxB_1[1] )^2 , ((oldbeta[oldtb:Klink]*(BoxB_2[2]-BoxB_2[1]))+BoxB_2[1] )^2 )
                    }
                  }
                }

                beta=vector()
                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  beta[x:xx]=beta_[ix]
                }
              }
              if(SF>0){
                if(SF<3){
                  sigma_=oldsigma*(Boxs[2]-Boxs[1])
                  sigma_=sigma_+Boxs[1]
                }else{
                  if(oldts==1){
                    sigma_=oldsigma*(Boxs_2[2]-Boxs_2[1])
                    sigma_=sigma_+Boxs_2[1]
                  }else{
                    if(oldts>Klink){
                      sigma_=oldsigma*(Boxs_1[2]-Boxs_1[1])
                      sigma_=sigma_+Boxs_1[1]
                    }else{
                      sigma_= c(oldsigma[1:(oldts-1)]*(Boxs_1[2]-Boxs_1[1]) ,oldsigma[oldts:Klink]*(Boxs_2[2]-Boxs_2[1]) )
                      sigma_= c( (sigma_[1:(oldts-1)]+Boxs_1[1]) , (sigma_[oldts:Klink]+Boxs_2[1]))
                    }
                  }
                }
                sigma=vector()
                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  sigma[x:xx]= sigma_[ix]
                }
              }
              print(c("sigma:",sigma,"beta :",beta))
              Keep_going=F
              if(it==1){
                diff_o=0
              }
              if(it>1){
                if(SF>1){
                  diff_o=mean(abs(sigma_o-sigma))
                }
                if(SF==2){
                  diff_o=0.0001
                }
                if(SB==1){
                  diff_o=max(diff_o,mean(abs(beta_o-beta)))
                }
                if(SB>1){
                  diff_o=max(diff_o,0.0001)
                }
                count_diff_o=0
                if(diff_o>=0.005){
                  if(it==maxIt){
                    count_diff_o=count_diff_o+1
                    maxIt=maxIt+1
                    if(count_diff_o>10){
                      maxBit=maxBit-1
                    }
                  }
                }
              }
              sigma_o=sigma
              beta_o=beta
              # browser()
              if(NC==1){
                builder=build_HMM_matrix_t(k,(rho),beta=beta,L=L,Pop=Pop,Xi_,Beta=Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
              }
              if(NC>1){
                builder=list()
                for(chr in 1:NC){
                  builder[[chr]]=build_HMM_matrix_t(k,(rho[[chr]]),beta=beta,L=L[chr],Pop=Pop,Xi_,Beta=Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
                }
              }
            }


            if(ER>1){
              oldtr_s=oldtr
            }
            if(SF>1){
              oldts_s=oldts
            }
            if(SB>1){
              oldtb_s=oldtb
            }
            if(!Popfix){
              oldXi_s=oldXi_
            }
            if(ER>0){
              oldrho_s=oldrho
            }
            if(SB>0){
              oldbeta_s=oldbeta
            }
            if(SF>0){
              oldsigma_s=oldsigma
            }

              Q = builder[[1]]
              nu= builder[[2]]
              Tc=builder[[3]]
              print(oldsigma)
              g=build_emission_matrix(mu,mu_b,Tc=builder[[4]],t=builder[[3]],beta,FS)
              M=matrix(0,nrow=length(Tc),ncol=3)
              N=matrix(0,length(Tc),length(Tc))
              MLH=0
              q_=rep(0,length(Tc))
              s_t=Sys.time()
              test=Build_zip_Matrix_mailund(Q,g,Os[[1]][[2]],nu)
              e_t=Sys.time()
              print(e_t-s_t)

              for(i in 1:length(Os)){
                Os[[i]][[1]]=as.numeric(Os[[i]][[1]])
                fo=forward_zip_mailund(Os[[i]][[1]],g,nu,test[[1]])
                MLH=MLH+fo[[3]]
                c=exp(fo[[2]])
                ba=Backward_zip_mailund(Os[[i]][[1]],test[[3]],length(Tc),c)

                W_P=list()
                W_P_=list()
                count_oo=0
                for(oo in c(1,3)){
                  count_oo=count_oo+1
                  int=t(Q)%*%diag(g[,oo])
                  int=eigen(int)
                  W_P[[count_oo]]=int$vectors
                  W_P_[[count_oo]]=solve(W_P[[count_oo]])
                }
                symbol= c(0:2,10:40)
                for(ob in 1){
                  truc_M=matrix(0,nrow=length(Tc),ncol=3)
                  if(Os[[i]][[1]][(ob+1)]<=2){
                    truc_N=(fo[[1]][,ob]%*%(t(ba[,(ob+1)]*g[,(as.numeric(Os[[i]][[1]][(ob+1)])+1)]/c[(ob+1)])))
                    truc_M[,(as.numeric(Os[[i]][[1]][(ob+1)])+1)]=fo[[1]][,ob]*(test[[2]][[(as.numeric(Os[[i]][[1]][(ob+1)])+1)]]%*%(ba[,(ob+1)]/c[(ob+1)]))
                  }else{

                    if(Os[[i]][[1]][(ob+1)]<30){
                      truc_N=(t(W_P_[[1]])%*%(t(W_P[[1]])%*%fo[[1]][,ob]%*%t(ba[,(ob+1)]/c[(ob+1)])%*%t(W_P_[[1]])*test[[4]][[(as.numeric(Os[[i]][[1]][(ob+1)]))]])%*%(t(W_P[[1]]))%*%diag(g[,1]))
                      truc_M[,1]=diag(t(W_P_[[1]])%*%(t(W_P[[1]])%*%fo[[1]][,ob]%*%t(ba[,(ob+1)]/c[(ob+1)])%*%t(W_P_[[1]]))*test[[2]][[(as.numeric(Os[[i]][[1]][(ob+1)]))]]%*%t(W_P[[1]]))
                    }else{
                      truc_N=(t(W_P_[[2]])%*%(t(W_P[[2]])%*%fo[[1]][,ob]%*%t(ba[,(ob+1)]/c[(ob+1)])%*%t(W_P_[[2]])*test[[4]][[(as.numeric(Os[[i]][[1]][(ob+1)]))]])%*%(t(W_P[[2]]))%*%diag(g[,3]))
                      truc_M[,3]=diag(t(W_P_[[2]])%*%(t(W_P[[2]])%*%fo[[1]][,ob]%*%t(ba[,(ob+1)]/c[(ob+1)])%*%t(W_P_[[2]]))*test[[2]][[(as.numeric(Os[[i]][[1]][(ob+1)]))]]%*%t(W_P[[2]]))

                    }
                  }
                }
                #truc_N=sum_chi_corrected(fo[[1]][,ob],ba[,(ob+1)],test[[4]],Os[[i]][[1]][(ob+1)],g,W,c[(ob+1)])
                N=N+truc_N
                #truc_M=sum_M_cor(fo[[1]][,ob],ba[,(ob+1)],Os[[i]][[1]][(ob+1)],test[[2]],W,(c[(ob+1)]),test[[1]])
                M=M+truc_M

                for(sym in sort(symbol)){
                  ob=as.numeric(sym)
                  pos=which(as.numeric(Os[[i]][[1]][-c(1,length(Os[[i]][[1]]))])==ob)
                  if(length(pos)>0){
                    pos=pos+1
                    #print("expected L:")
                    #print(Os[[3]][which(Os[[3]][,1]==sym),2]*length(pos))
                    #print("ob:")
                    #print(ob)
                    if(ob<3){
                      # print("expected L:")
                      #  print(length(pos))
                      ba_t=t(t(ba[,(pos)])/c[(pos)])
                      truc=c(rowSums(fo[[1]][,(pos-1)]*(test[[1]][[(ob+1)]]%*%ba_t)))
                      truc=(truc/(sum(truc)))*length(pos)
                      M[,(ob+1)]=M[,(ob+1)]+ truc
                      truc_N=(fo[[1]][,(pos-1)]%*%(t(diag(g[,(ob+1)])%*%ba_t)))
                      # print("calculated L:")
                      #  print(sum(truc_N*t(Q)))
                      N=N+truc_N
                    }else{
                      if(ob<30){
                        A=(t(W_P[[1]])%*%fo[[1]][,(pos-1)]%*%t(t(t(ba[,(pos)])/c[(pos)]))%*%t(W_P_[[1]]))
                        A_=A*test[[2]][[(ob)]]
                        A_=(t(W_P_[[1]])%*%A_%*%t(W_P[[1]]))
                        M[,1]=M[,1]+(diag(A_))
                        A_=A*test[[4]][[(ob)]]
                        A_=(t(W_P_[[1]])%*%A_%*%t(W_P[[1]]))
                        truc_N=((A_%*%diag(g[,1])))
                      }else{
                        A=(t(W_P[[2]])%*%fo[[1]][,(pos-1)]%*%t(t(t(ba[,(pos)])/c[(pos)]))%*%t(W_P_[[2]]))
                        A_=A*test[[2]][[(ob)]]
                        A_=(t(W_P_[[2]])%*%A_%*%t(W_P[[2]]))
                        M[,3]=M[,3]+(diag(A_))
                        A_=A*test[[4]][[(ob)]]
                        A_=(t(W_P_[[2]])%*%A_%*%t(W_P[[2]]))
                        truc_N=((A_%*%diag(g[,3])))
                      }

                      #print("calculated L:")
                      #print(sum(truc_N*t(Q)))
                      N=N+truc_N
                    }
                  }
                }

                if(as.numeric(Os[[i]][[1]][length(Os[[i]][[1]])])<=3){
                  M[,(as.numeric(Os[[i]][[1]][length(Os[[i]][[1]])])+1)]=M[,(as.numeric(Os[[i]][[1]][length(Os[[i]][[1]])])+1)]+(fo[[1]][,length(Os[[i]][[1]])]*ba[,length(Os[[i]][[1]])])
                }else{
                  if(as.numeric(Os[[i]][[1]][length(Os[[i]][[1]])])<30){

                    M[,1]=M[,1]+((fo[[1]][,length(Os[[i]][[1]])]*ba[,length(Os[[i]][[1]])])/sum(fo[[1]][,length(Os[[i]][[1]])]*ba[,length(Os[[i]][[1]])]))
                  }else{
                    M[,3]=M[,3]+((fo[[1]][,length(Os[[i]][[1]])]*ba[,length(Os[[i]][[1]])])/sum(fo[[1]][,length(Os[[i]][[1]])]*ba[,length(Os[[i]][[1]])]))

                  }
                }
                q_=q_+((fo[[1]][,1]*ba[,1])/sum(fo[[1]][,1]*ba[,1]))
              }
              N=N*t(Q)
              if(is.complex(N)){
                N=Re(N)
              }

              if(is.complex(M)){
                M=Re(M)
              }
              Scale_N=(L-1)/sum(N)
              N=N*Scale_N
              Scale_M=L/sum(M)
              M=M*Scale_M
              q_=q_/sum(q_)
              if(SCALED){
                corrector_M=rowSums(M)
                M=diag(1/corrector_M)%*%M
                corrector_N=rowSums(N)
                N=diag(1/corrector_N)%*%N
              }



          }

          if(NC>1){

            test.env$ER <- ER
            test.env$SF <- SF
            test.env$SB <- SB
            test.env$Os <- Os



            function_to_minimize<-function(param){
              Boxr=get('Boxr', envir=test.env)
              mu=get('mu', envir=test.env)
              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)
              mu_b=get('mu_b', envir=test.env)
              FS=get('FS', envir=test.env)
              Klink=get('Klink', envir=test.env)
              Rho=get('Rho', envir=test.env)
              BoxB=get('BoxB', envir=test.env)
              Boxs=get('Boxs', envir=test.env)
              BoxP=get('BoxP', envir=test.env)
              pop_vect=get('pop_vect', envir=test.env)
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Beta=get('Beta', envir=test.env)
              Self=get('Self', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)
              Pop=get('Pop', envir=test.env)
              ER=get('ER', envir=test.env)
              SF=get('SF', envir=test.env)
              SB=get('SB', envir=test.env)
              Os=get('Os', envir=test.env)
              NC=get('NC', envir=test.env)
              start_position=0
              if(ER==1){

                rho=list()
                rho_=list()
                oldrho_param=param[(start_position+1):(start_position+(Klink*NC))]
                for(rr in 1:NC){
                  rho[[rr]]= oldrho_param[(1+((rr-1)*Klink)):(rr*Klink)]*sum(Boxr)
                  rho[[rr]]=rho[[rr]]-(Boxr[1])
                  rho[[rr]]=10^(rho[[rr]])
                  rho[[rr]]=rho[[rr]]*Rho[rr]

                  xx=0
                  rho_[[rr]]=vector()
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    rho_[[rr]][x:xx]= rho[[rr]][ix]
                  }
                }
                start_position=start_position+(Klink*NC)
              }
              if(ER==2){

                Boxr_s=get('Boxr_s', envir=test.env)

                #t_r=min(ceiling(param[(start_position+1)]*Klink),Klink)
                t_r=get('t_r', envir=test.env)

                rho=list()
                rho_=list()

                for(rr in 1:NC){

                  if(t_r>Klink){
                    oldrho_param=rep(Boxr_s[1],Klink)
                  }else{
                    if(t_r>1){
                      oldrho_param=c(rep(Boxr_s[1],(t_r-1)),rep(Boxr_s[2],(Klink-t_r+1)))
                    }else{
                      oldrho_param=rep(Boxr_s[2],Klink)
                    }
                  }


                  rho[[rr]]= oldrho_param[(1+((rr-1)*Klink)):(rr*Klink)]*sum(Boxr)
                  rho[[rr]]=rho[[rr]]-(Boxr[1])
                  rho[[rr]]=10^(rho[[rr]])
                  rho[[rr]]=rho[[rr]]*Rho[rr]

                  xx=0
                  rho_[[rr]]=vector()
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    rho_[[rr]][x:xx]= rho[[rr]][ix]
                  }
                }
              }
              if(ER==0){
                rho_=list()
                for(rr in 1:NC){
                  rho_[[rr]]=rep(Rho[rr],n)
                }
              }
              if(ER==3){

                Boxr_s=get('Boxr_s', envir=test.env)
                Boxr_1=get('Boxr_1', envir=test.env)
                Boxr_2=get('Boxr_2', envir=test.env)
                correct_R=get('correct_R', envir=test.env)
                t_r=get('t_r', envir=test.env)

                rho=list()
                rho_=list()

                for(rr in 1:NC){

                  if(t_r>Klink){
                    oldrho_param=rep(Boxr_s[1],Klink)
                    rho[[rr]]= oldrho_param[(1+((rr-1)*Klink)):(rr*Klink)]*sum(Boxr_1)
                    rho[[rr]]=rho[[rr]]-(Boxr_1[1])
                    rho[[rr]]=10^(rho[[rr]])
                    rho[[rr]]=rho[[rr]]*Rho[rr]
                  }else{
                    if(t_r>1){
                      oldrho_param=c(rep(Boxr_s[1],(t_r-1)),rep(Boxr_s[2],(Klink-t_r+1)))
                      rho[[rr]]=  c(( oldrho_param[(1+((rr-1)*Klink)):((t_r-1)+((rr-1)*Klink))]*sum(Boxr_1))  , ( oldrho_param[((t_r)+((rr-1)*Klink)):(rr*Klink)]*sum(Boxr_2)) )
                      rho[[rr]]=c(  rho[[rr]][1:(t_r-1)]-(Boxr_1[1]) ,  rho[[rr]][t_r:Klink]-(Boxr_2[1]) )
                      rho[[rr]]=10^(rho[[rr]])
                      rho[[rr]]=c(rho[[rr]][1:(t_r-1)]*Rho[rr],rho[[rr]][t_r:Klink]*Rho[rr]*correct_R)
                    }else{
                      oldrho_param=rep(Boxr_s[2],Klink)
                      rho[[rr]]= oldrho_param[(1+((rr-1)*Klink)):(rr*Klink)]*sum(Boxr_2)
                      rho[[rr]]=rho[[rr]]-(Boxr_2[1])
                      rho[[rr]]=10^(rho[[rr]])
                      rho[[rr]]=rho[[rr]]*Rho[rr]
                    }
                  }




                  xx=0
                  rho_[[rr]]=vector()
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    rho_[[rr]][x:xx]= rho[[rr]][ix]
                  }
                }
              }
              if(SF==1){
                sigma_=numeric(n)
                sigma=param[(start_position+1):(start_position+Klink)]
                start_position=start_position+Klink
                sigma=sigma*(Boxs[2]-Boxs[1])
                sigma=sigma+Boxs[1]
                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  sigma_[x:xx]=sigma[ix]
                }
              }
              if(SF==2){
                Boxs_s=get('Boxs_s', envir=test.env)
                sigma_=numeric(n)

                #t_s=min(ceiling(param[(start_position+1)]*Klink),Klink)
                t_s=get('t_s', envir=test.env)
                if(t_s>Klink){
                  sigma=rep(Boxs_s[1],Klink)
                }else{
                  if(t_s>1){
                    sigma=c(rep(Boxs_s[1],(t_s-1)),rep(Boxs_s[2],(Klink-t_s+1)))
                  }else{
                    sigma=rep(Boxs_s[2],Klink)
                  }
                }
                #start_position=start_position+1
                sigma=sigma*(Boxs[2]-Boxs[1])
                sigma=sigma+Boxs[1]
                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  sigma_[x:xx]=sigma[ix]
                }

              }
              if(SF==3){
                Boxs_s=get('Boxs_s', envir=test.env)
                Boxs_1=get('Boxs_1', envir=test.env)
                Boxs_2=get('Boxs_2', envir=test.env)
                sigma_=numeric(n)

                t_s=get('t_s', envir=test.env)
                if(t_s>Klink){
                  sigma=rep(Boxs_s[1],Klink)
                  sigma=sigma*(Boxs_1[2]-Boxs_1[1])
                  sigma=sigma+Boxs_1[1]
                }else{
                  if(t_s>1){
                    sigma=c(rep(Boxs_s[1],(t_s-1)),rep(Boxs_s[2],(Klink-t_s+1)))
                    sigma= c(sigma[1:(t_s-1)]*(Boxs_1[2]-Boxs_1[1]),sigma[t_s:Klink]*(Boxs_2[2]-Boxs_2[1]) )
                    sigma= c(sigma[1:(t_s-1)]+Boxs_1[1],sigma[t_s:Klink]+Boxs_2[1])
                  }else{
                    sigma=rep(Boxs_s[2],Klink)
                    sigma=sigma*(Boxs_2[2]-Boxs_2[1])
                    sigma=sigma+Boxs_2[1]
                  }
                }
                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  sigma_[x:xx]=sigma[ix]
                }
              }
              if(SF==0){
                sigma_=rep(sigma,n)
              }
              if(SB==1){
                beta_=numeric(n)
                beta=((param[(start_position+1):(start_position+Klink)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
                start_position=start_position+(Klink)
                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  beta_[x:xx]=beta[ix]

                }
              }
              if(SB==2){
                beta_=numeric(n)
                BoxB_s=get('BoxB_s', envir=test.env)
                #t_b=min(ceiling(param[(start_position+1)]*Klink),Klink)
                t_b=get('t_b', envir=test.env)
                if(t_b>Klink){
                  beta=rep(BoxB_s[1],Klink)
                }else{
                  if(t_b>1){
                    beta=c(rep(BoxB_s[1],(t_b-1)),rep(BoxB_s[2],(Klink-t_b+1)))
                  }else{
                    beta=rep(BoxB_s[2],Klink)
                  }
                }

                beta=((beta*(BoxB[2]-BoxB[1]))+BoxB[1])^2
                # start_position=start_position+1
                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  beta_[x:xx]=beta[ix]

                }
              }
              if(SB==0){
                beta_=rep(beta,n)
              }
              if(SB==3){
                beta_=numeric(n)
                BoxB_s=get('BoxB_s', envir=test.env)
                BoxB_1=get('BoxB_1', envir=test.env)
                BoxB_2=get('BoxB_2', envir=test.env)
                t_b=get('t_b', envir=test.env)
                if(t_b>Klink){
                  beta=rep(BoxB_s[1],Klink)
                  beta=((beta*(BoxB_1[2]-BoxB_1[1]))+BoxB_1[1])^2
                }else{
                  if(t_b>1){
                    beta=c(rep(BoxB_s[1],(t_b-1)),rep(BoxB_s[2],(Klink-t_b+1)))
                    beta=c((((beta[1:(t_b-1)]*(BoxB_1[2]-BoxB_1[1]))+BoxB_1[1])^2),(((beta[t_b:Klink]*(BoxB_2[2]-BoxB_2[1]))+BoxB_2[1])^2))
                  }else{
                    beta=rep(BoxB_s[2],Klink)
                    beta=((beta*(BoxB_2[2]-BoxB_2[1]))+BoxB_2[1])^2
                  }
                }


                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  beta_[x:xx]=beta[ix]

                }
              }
              if(!Pop){
                Xi=numeric(n)
                Xi_=param[(start_position+1):(start_position+Klink)]
                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  Xi[x:xx]=Xi_[ix]
                }
                Xi=Xi*sum(BoxP)
                Xi=Xi-(BoxP[1])
                Xi=10^Xi
              }else{
                Xi=rep(1,n)
              }

              MLH=0


              for(chr in 1:NC){
                builder=build_HMM_matrix_t(k,(rho[[chr]]),beta=beta_,L=L[chr],Pop=Pop,Xi,Beta=Beta,scale=window_scaling,sigma =sigma_,Sigma = Self,Big_Window=Big_Window,npair=npair)
                Q = builder[[1]]
                nu= builder[[2]]
                Tc=builder[[3]]
                g=build_emission_matrix(mu[chr],mu_b,Tc=builder[[4]],t=builder[[3]],beta,FS)




                q_=rep(0,length(Tc))
                test=Build_zip_Matrix_mailund(Q,g,Os[[chr]][[1]][[2]],nu,do_all=F)

                for(i in 1:length(Os[[chr]])){
                  fo=forward_zip_mailund(Os[[chr]][[i]][[1]],g,nu,test[[1]])
                  MLH=MLH-fo[[3]]
                }
              }
              return(MLH)
            }

            param=c()
            if(ER==1){
              for(rr in 1:NC){
                param=c(param,oldrho[[rr]])
              }
            }



            if(SF==1){
              param=c(param,oldsigma)
            }

            if(SB==1){
              param=c(param,oldbeta)
            }

            if(!Popfix){
              param=c(param,oldXi_)
            }

            LH_temp=0

            if(it==1){

              if(ER==3){
                LH_temp=function_to_minimize(param)
                UP=F
                if((Boxr_s[1]+0.05)<1){
                  Boxr_s[1]=Boxr_s[1]+0.05
                  test.env$Boxr_s <- Boxr_s
                  LH_temp2=function_to_minimize(param)
                  if(LH_temp>LH_temp2){
                    UP=T
                    LH_temp=LH_temp2
                  }else{
                    Boxr_s[1]=Boxr_s[1]-0.05
                    test.env$Boxr_s <- Boxr_s
                  }
                }

                if(UP){
                  while(UP){
                    if((Boxr_s[1]+0.05)<1){
                      Boxr_s[1]=Boxr_s[1]+0.05
                      test.env$Boxr_s <- Boxr_s
                      UP=F
                      LH_temp2=function_to_minimize(param)
                      if(LH_temp>LH_temp2){
                        UP=T
                        LH_temp=LH_temp2
                      }else{
                        Boxr_s[1]=Boxr_s[1]-0.05
                        test.env$Boxr_s <- Boxr_s
                      }
                    }else{
                      UP=F
                    }
                  }
                }else{
                  DOWN=F
                  if((Boxr_s[1]-0.05)>0){
                    Boxr_s[1]=Boxr_s[1]-0.05
                    test.env$Boxr_s <- Boxr_s
                    LH_temp2=function_to_minimize(param)
                    if(LH_temp>LH_temp2){
                      DOWN=T
                      LH_temp=LH_temp2
                    }else{
                      Boxr_s[1]=Boxr_s[1]+0.05
                      test.env$Boxr_s <- Boxr_s
                    }
                  }
                  while(DOWN){
                    if((Boxr_s[1]-0.05)>0){
                      Boxr_s[1]=Boxr_s[1]-0.05
                      test.env$Boxr_s <- Boxr_s
                      DOWN=F
                      LH_temp2=function_to_minimize(param)
                      if(LH_temp>LH_temp2){
                        DOWN=T
                        LH_temp=LH_temp2
                      }else{
                        Boxr_s[1]=Boxr_s[1]+0.05
                        test.env$Boxr_s <- Boxr_s
                      }
                    }else{
                      DOWN=F
                    }
                  }
                }


                UP=F
                if((Boxr_s[2]+0.05)<1){
                  Boxr_s[2]=Boxr_s[2]+0.05
                  test.env$Boxr_s <- Boxr_s
                  LH_temp2=function_to_minimize(param)
                  if(LH_temp>LH_temp2){
                    UP=T
                    LH_temp=LH_temp2
                  }else{
                    Boxr_s[2]=Boxr_s[2]-0.05
                    test.env$Boxr_s <- Boxr_s
                  }
                }

                if(UP){
                  while(UP){
                    if((Boxr_s[2]+0.05)<1){
                      Boxr_s[2]=Boxr_s[2]+0.05
                      test.env$Boxr_s <- Boxr_s
                      UP=F
                      LH_temp2=function_to_minimize(param)
                      if(LH_temp>LH_temp2){
                        UP=T
                        LH_temp=LH_temp2
                      }else{
                        Boxr_s[2]=Boxr_s[2]-0.05
                        test.env$Boxr_s <- Boxr_s
                      }
                    }else{
                      UP=F
                    }
                  }
                }else{
                  DOWN=F
                  if((Boxr_s[2]-0.05)>0){
                    Boxr_s[2]=Boxr_s[2]-0.05
                    test.env$Boxr_s <- Boxr_s
                    LH_temp2=function_to_minimize(param)
                    if(LH_temp>LH_temp2){
                      DOWN=T
                      LH_temp=LH_temp2
                    }else{
                      Boxr_s[2]=Boxr_s[2]+0.05
                      test.env$Boxr_s <- Boxr_s
                    }
                  }
                  while(DOWN){
                    if((Boxr_s[2]-0.05)>0){
                      Boxr_s[2]=Boxr_s[2]-0.05
                      test.env$Boxr_s <- Boxr_s
                      DOWN=F
                      LH_temp2=function_to_minimize(param)
                      if(LH_temp>LH_temp2){
                        DOWN=T
                        LH_temp=LH_temp2
                      }else{
                        Boxr_s[2]=Boxr_s[2]+0.05
                        test.env$Boxr_s <- Boxr_s
                      }
                    }else{
                      DOWN=F
                    }
                  }
                }



              }

              if(SF==3){
                LH_temp=function_to_minimize(param)
                Boxs_s[1]=Boxs_s[1]+0.05
                test.env$Boxs_s <- Boxs_s
                UP=F
                LH_temp2=function_to_minimize(param)
                if(LH_temp>LH_temp2){
                  UP=T
                  LH_temp=LH_temp2
                }else{
                  Boxs_s[1]=Boxs_s[1]-0.05
                  test.env$Boxs_s <- Boxs_s
                }
                while(UP){
                  if((Boxs_s[1]+0.05)<1){
                    Boxs_s[1]=Boxs_s[1]+0.05
                    test.env$Boxs_s <- Boxs_s
                    UP=F
                    LH_temp2=function_to_minimize(param)
                    if(LH_temp>LH_temp2){
                      UP=T
                      LH_temp=LH_temp2
                    }else{
                      Boxs_s[1]=Boxs_s[1]-0.05
                      test.env$Boxs_s <- Boxs_s
                    }
                  }else{
                    UP=F
                  }
                }
                Boxs_s[2]=Boxs_s[2]+0.05
                test.env$Boxs_s <- Boxs_s
                UP=F
                LH_temp2=function_to_minimize(param)
                if(LH_temp>LH_temp2){
                  UP=T
                  LH_temp=LH_temp2
                }else{
                  Boxs_s[2]=Boxs_s[2]-0.05
                  test.env$Boxs_s <- Boxs_s
                }
                while(UP){
                  if((Boxs_s[2]+0.05)<1){
                    Boxs_s[2]=Boxs_s[2]+0.05
                    test.env$Boxs_s <- Boxs_s
                    UP=F
                    LH_temp2=function_to_minimize(param)
                    if(LH_temp>LH_temp2){
                      UP=T
                      LH_temp=LH_temp2
                    }else{
                      Boxs_s[2]=Boxs_s[2]-0.05
                      test.env$Boxs_s <- Boxs_s
                    }
                  }else{
                    UP=F
                  }
                }


              }

              if(SB==3){
                LH_temp=function_to_minimize(param)
                BoxB_s[1]=BoxB_s[1]-0.05
                test.env$BoxB_s <- BoxB_s
                DOWN=F
                LH_temp2=function_to_minimize(param)
                if(LH_temp>LH_temp2){
                  DOWN=T
                  LH_temp=LH_temp2
                }else{
                  BoxB_s[1]=BoxB_s[1]+0.05
                  test.env$BoxB_s <- BoxB_s
                }
                while(DOWN){
                  if((BoxB_s[1]-0.05)>0){
                    BoxB_s[1]=BoxB_s[1]-0.05
                    test.env$BoxB_s <- BoxB_s
                    DOWN=F
                    LH_temp2=function_to_minimize(param)
                    if(LH_temp>LH_temp2){
                      DOWN=T
                      LH_temp=LH_temp2
                    }else{
                      BoxB_s[1]=BoxB_s[1]+0.05
                      test.env$BoxB_s <- BoxB_s
                    }
                  }else{
                    DOWN=F
                  }
                }
                BoxB_s[2]=BoxB_s[2]-0.05
                test.env$BoxB_s <- BoxB_s
                DOWN=F
                LH_temp2=function_to_minimize(param)
                if(LH_temp>LH_temp2){
                  DOWN=T
                  LH_temp=LH_temp2
                }else{
                  BoxB_s[2]=BoxB_s[2]+0.05
                  test.env$BoxB_s <- BoxB_s
                }
                while(DOWN){
                  if((BoxB_s[2]-0.05)>0){
                    BoxB_s[2]=BoxB_s[2]-0.05
                    test.env$BoxB_s <- BoxB_s
                    DOWN=F
                    LH_temp2=function_to_minimize(param)
                    if(LH_temp>LH_temp2){
                      DOWN=T
                      LH_temp=LH_temp2
                    }else{
                      BoxB_s[2]=BoxB_s[2]+0.05
                      test.env$BoxB_s <- BoxB_s
                    }
                  }else{
                    DOWN=F
                  }
                }


              }


              if(ER>1){
                for(t_r in 1:(1+Klink)){
                  test.env$t_r <- t_r
                  if(SB>1){
                    for( t_b in 1:(1+Klink)){
                      test.env$t_b <- t_b
                      if(SF>1){

                        for(t_s in 1:(1+Klink)){
                          test.env$t_s <- t_s

                          sol_temp=function_to_minimize(param)
                          if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                            LH_temp=as.numeric(sol_temp)
                            oldtr=t_r
                            oldtb=t_b
                            oldts=t_s

                          }

                        }

                      }else{
                        sol_temp=function_to_minimize(param)
                        if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                          LH_temp=as.numeric(sol_temp)
                          oldtr=t_r
                          oldtb=t_b

                        }
                      }
                    }

                  }else{ # NO  SB
                    if(SF>1){
                      for(t_s in 1:(1+Klink)){
                        test.env$t_s <- t_s
                        sol_temp=function_to_minimize(param)
                        if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                          LH_temp=as.numeric(sol_temp)
                          oldtr=t_r
                          oldts=t_s

                        }
                      }
                    }else{
                      sol_temp=function_to_minimize(param)
                      if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                        LH_temp=as.numeric(sol_temp)
                        oldtr=t_r

                      }
                    }
                  }
                }
              }else{ # No ER
                if(SB>1){
                  for( t_b in 1:(1+Klink)){
                    test.env$t_b <- t_b
                    if(SF>1){

                      for(t_s in 1:(1+Klink)){
                        test.env$t_s <- t_s
                        sol_temp=function_to_minimize(param)
                        if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                          LH_temp=as.numeric(sol_temp)
                          oldtb=t_b
                          oldts=t_s

                        }
                      }
                    }else{
                      sol_temp=function_to_minimize(param)
                      if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                        LH_temp=as.numeric(sol_temp)
                        oldtb=t_b

                      }
                    }
                  }
                }else{
                  if(SF>1){

                    for(t_s in 1:(1+Klink)){
                      test.env$t_s <- t_s
                      sol_temp=function_to_minimize(param)
                      print(sol_temp)
                      if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                        LH_temp=as.numeric(sol_temp)
                        oldts=t_s


                      }
                    }
                  }else{

                    stop("How did you get here ?")

                  }
                }
              }
            }else{

              if(ER==3){
                LH_temp=function_to_minimize(param)
                UP=F
                if((Boxr_s[1]+0.05)<1){
                  Boxr_s[1]=Boxr_s[1]+0.05
                  test.env$Boxr_s <- Boxr_s
                  LH_temp2=function_to_minimize(param)
                  if(LH_temp>LH_temp2){
                    UP=T
                    LH_temp=LH_temp2
                  }else{
                    Boxr_s[1]=Boxr_s[1]-0.05
                    test.env$Boxr_s <- Boxr_s
                  }
                }

                if(UP){
                  while(UP){
                    if((Boxr_s[1]+0.05)<1){
                      Boxr_s[1]=Boxr_s[1]+0.05
                      test.env$Boxr_s <- Boxr_s
                      UP=F
                      LH_temp2=function_to_minimize(param)
                      if(LH_temp>LH_temp2){
                        UP=T
                        LH_temp=LH_temp2
                      }else{
                        Boxr_s[1]=Boxr_s[1]-0.05
                        test.env$Boxr_s <- Boxr_s
                      }
                    }else{
                      UP=F
                    }
                  }
                }else{
                  DOWN=F
                  if((Boxr_s[1]-0.05)>0){
                    Boxr_s[1]=Boxr_s[1]-0.05
                    test.env$Boxr_s <- Boxr_s
                    LH_temp2=function_to_minimize(param)
                    if(LH_temp>LH_temp2){
                      DOWN=T
                      LH_temp=LH_temp2
                    }else{
                      Boxr_s[1]=Boxr_s[1]+0.05
                      test.env$Boxr_s <- Boxr_s
                    }
                  }
                  while(DOWN){
                    if((Boxr_s[1]-0.05)>0){
                      Boxr_s[1]=Boxr_s[1]-0.05
                      test.env$Boxr_s <- Boxr_s
                      DOWN=F
                      LH_temp2=function_to_minimize(param)
                      if(LH_temp>LH_temp2){
                        DOWN=T
                        LH_temp=LH_temp2
                      }else{
                        Boxr_s[1]=Boxr_s[1]+0.05
                        test.env$Boxr_s <- Boxr_s
                      }
                    }else{
                      DOWN=F
                    }
                  }
                }


                UP=F
                if((Boxr_s[2]+0.05)<1){
                  Boxr_s[2]=Boxr_s[2]+0.05
                  test.env$Boxr_s <- Boxr_s
                  LH_temp2=function_to_minimize(param)
                  if(LH_temp>LH_temp2){
                    UP=T
                    LH_temp=LH_temp2
                  }else{
                    Boxr_s[2]=Boxr_s[2]-0.05
                    test.env$Boxr_s <- Boxr_s
                  }
                }

                if(UP){
                  while(UP){
                    if((Boxr_s[2]+0.05)<1){
                      Boxr_s[2]=Boxr_s[2]+0.05
                      test.env$Boxr_s <- Boxr_s
                      UP=F
                      LH_temp2=function_to_minimize(param)
                      if(LH_temp>LH_temp2){
                        UP=T
                        LH_temp=LH_temp2
                      }else{
                        Boxr_s[2]=Boxr_s[2]-0.05
                        test.env$Boxr_s <- Boxr_s
                      }
                    }else{
                      UP=F
                    }
                  }
                }else{
                  DOWN=F
                  if((Boxr_s[2]-0.05)>0){
                    Boxr_s[2]=Boxr_s[2]-0.05
                    test.env$Boxr_s <- Boxr_s
                    LH_temp2=function_to_minimize(param)
                    if(LH_temp>LH_temp2){
                      DOWN=T
                      LH_temp=LH_temp2
                    }else{
                      Boxr_s[2]=Boxr_s[2]+0.05
                      test.env$Boxr_s <- Boxr_s
                    }
                  }
                  while(DOWN){
                    if((Boxr_s[2]-0.05)>0){
                      Boxr_s[2]=Boxr_s[2]-0.05
                      test.env$Boxr_s <- Boxr_s
                      DOWN=F
                      LH_temp2=function_to_minimize(param)
                      if(LH_temp>LH_temp2){
                        DOWN=T
                        LH_temp=LH_temp2
                      }else{
                        Boxr_s[2]=Boxr_s[2]+0.05
                        test.env$Boxr_s <- Boxr_s
                      }
                    }else{
                      DOWN=F
                    }
                  }
                }



              }


              if(SF==3){
                LH_temp=function_to_minimize(param)

                if((Boxs_s[1]+0.05)<1){

                  Boxs_s[1]=Boxs_s[1]+0.05
                  test.env$Boxs_s <- Boxs_s
                  UP=F
                  LH_temp2=function_to_minimize(param)
                  if(LH_temp>LH_temp2){
                    UP=T
                    LH_temp=LH_temp2
                  }else{
                    Boxs_s[1]=Boxs_s[1]-0.05
                    test.env$Boxs_s <- Boxs_s
                  }
                  while(UP){
                    if((Boxs_s[1]+0.05)<1){
                      Boxs_s[1]=Boxs_s[1]+0.05
                      test.env$Boxs_s <- Boxs_s
                      UP=F
                      LH_temp2=function_to_minimize(param)
                      if(LH_temp>LH_temp2){
                        UP=T
                        LH_temp=LH_temp2
                      }else{
                        Boxs_s[1]=Boxs_s[1]-0.05
                        test.env$Boxs_s <- Boxs_s
                      }
                    }else{
                      UP=F
                    }
                  }

                }

                if((Boxs_s[1]-0.05)>0){

                  Boxs_s[1]=Boxs_s[1]-0.05
                  test.env$Boxs_s <- Boxs_s
                  DOWN=F
                  LH_temp2=function_to_minimize(param)
                  if(LH_temp>LH_temp2){
                    DOWN=T
                    LH_temp=LH_temp2
                  }else{
                    Boxs_s[1]=Boxs_s[1]+0.05
                    test.env$Boxs_s <- Boxs_s
                  }
                  while(DOWN){
                    if((Boxs_s[1]-0.05)<1){
                      Boxs_s[1]=Boxs_s[1]-0.05
                      test.env$Boxs_s <- Boxs_s
                      DOWN=F
                      LH_temp2=function_to_minimize(param)
                      if(LH_temp>LH_temp2){
                        DOWN=T
                        LH_temp=LH_temp2
                      }else{
                        Boxs_s[1]=Boxs_s[1]+0.05
                        test.env$Boxs_s <- Boxs_s
                      }
                    }else{
                      DOWN=F
                    }
                  }

                }


                if((Boxs_s[2]+0.05)<1){
                  Boxs_s[2]=Boxs_s[2]+0.05
                  test.env$Boxs_s <- Boxs_s
                  UP=F
                  LH_temp2=function_to_minimize(param)
                  if(LH_temp>LH_temp2){
                    UP=T
                    LH_temp=LH_temp2
                  }else{
                    Boxs_s[2]=Boxs_s[2]-0.05
                    test.env$Boxs_s <- Boxs_s
                  }
                  while(UP){
                    if((Boxs_s[2]+0.05)<1){
                      Boxs_s[2]=Boxs_s[2]+0.05
                      test.env$Boxs_s <- Boxs_s
                      UP=F
                      LH_temp2=function_to_minimize(param)
                      if(LH_temp>LH_temp2){
                        UP=T
                        LH_temp=LH_temp2
                      }else{
                        Boxs_s[2]=Boxs_s[2]-0.05
                        test.env$Boxs_s <- Boxs_s
                      }
                    }else{
                      UP=F
                    }
                  }
                }

                if((Boxs_s[2]-0.05)>0){
                  Boxs_s[2]=Boxs_s[2]-0.05
                  test.env$Boxs_s <- Boxs_s
                  DOWN=F
                  LH_temp2=function_to_minimize(param)
                  if(LH_temp>LH_temp2){
                    DOWN=T
                    LH_temp=LH_temp2
                  }else{
                    Boxs_s[2]=Boxs_s[2]+0.05
                    test.env$Boxs_s <- Boxs_s
                  }
                  while(DOWN){
                    if((Boxs_s[2]-0.05)>0){
                      Boxs_s[2]=Boxs_s[2]-0.05
                      test.env$Boxs_s <- Boxs_s
                      DOWN=F
                      LH_temp2=function_to_minimize(param)
                      if(LH_temp>LH_temp2){
                        DOWN=T
                        LH_temp=LH_temp2
                      }else{
                        Boxs_s[2]=Boxs_s[2]+0.05
                        test.env$Boxs_s <- Boxs_s
                      }
                    }else{
                      DOWN=F
                    }
                  }
                }



              }

              if(SB==3){
                LH_temp=function_to_minimize(param)

                if((BoxB_s[1]-0.05>0)){
                  BoxB_s[1]=BoxB_s[1]-0.05
                  test.env$BoxB_s <- BoxB_s
                  DOWN=F
                  LH_temp2=function_to_minimize(param)
                  if(LH_temp>LH_temp2){
                    DOWN=T
                    LH_temp=LH_temp2
                  }else{
                    BoxB_s[1]=BoxB_s[1]+0.05
                    test.env$BoxB_s <- BoxB_s
                  }
                  while(DOWN){
                    if((BoxB_s[1]-0.05)>0){
                      BoxB_s[1]=BoxB_s[1]-0.05
                      test.env$BoxB_s <- BoxB_s
                      DOWN=F
                      LH_temp2=function_to_minimize(param)
                      if(LH_temp>LH_temp2){
                        DOWN=T
                        LH_temp=LH_temp2
                      }else{
                        BoxB_s[1]=BoxB_s[1]+0.05
                        test.env$BoxB_s <- BoxB_s
                      }
                    }else{
                      DOWN=F
                    }
                  }
                }

                if((BoxB_s[1]+0.05<1)){
                  BoxB_s[1]=BoxB_s[1]+0.05
                  test.env$BoxB_s <- BoxB_s
                  UP=F
                  LH_temp2=function_to_minimize(param)
                  if(LH_temp>LH_temp2){
                    UP=T
                    LH_temp=LH_temp2
                  }else{
                    BoxB_s[1]=BoxB_s[1]-0.05
                    test.env$BoxB_s <- BoxB_s
                  }
                  while(UP){
                    if((BoxB_s[1]+0.05)<1){
                      BoxB_s[1]=BoxB_s[1]+0.05
                      test.env$BoxB_s <- BoxB_s
                      UP=F
                      LH_temp2=function_to_minimize(param)
                      if(LH_temp>LH_temp2){
                        UP=T
                        LH_temp=LH_temp2
                      }else{
                        BoxB_s[1]=BoxB_s[1]-0.05
                        test.env$BoxB_s <- BoxB_s
                      }
                    }else{
                      UP=F
                    }
                  }
                }

                if(BoxB_s[2]-0.05>0){
                  BoxB_s[2]=BoxB_s[2]-0.05
                  test.env$BoxB_s <- BoxB_s
                  DOWN=F
                  LH_temp2=function_to_minimize(param)
                  if(LH_temp>LH_temp2){
                    DOWN=T
                    LH_temp=LH_temp2
                  }else{
                    BoxB_s[2]=BoxB_s[2]+0.05
                    test.env$BoxB_s <- BoxB_s
                  }
                  while(DOWN){
                    if((BoxB_s[2]-0.05)>0){
                      BoxB_s[2]=BoxB_s[2]-0.05
                      test.env$BoxB_s <- BoxB_s
                      DOWN=F
                      LH_temp2=function_to_minimize(param)
                      if(LH_temp>LH_temp2){
                        DOWN=T
                        LH_temp=LH_temp2
                      }else{
                        BoxB_s[2]=BoxB_s[2]+0.05
                        test.env$BoxB_s <- BoxB_s
                      }
                    }else{
                      DOWN=F
                    }
                  }

                }

                if(BoxB_s[2]+0.05<1){
                  BoxB_s[2]=BoxB_s[2]+0.05
                  test.env$BoxB_s <- BoxB_s
                  UP=F
                  LH_temp2=function_to_minimize(param)
                  if(LH_temp>LH_temp2){
                    UP=T
                    LH_temp=LH_temp2
                  }else{
                    BoxB_s[2]=BoxB_s[2]-0.05
                    test.env$BoxB_s <- BoxB_s
                  }
                  while(UP){
                    if((BoxB_s[2]+0.05)<1){
                      BoxB_s[2]=BoxB_s[2]+0.05
                      test.env$BoxB_s <- BoxB_s
                      UP=F
                      LH_temp2=function_to_minimize(param)
                      if(LH_temp>LH_temp2){
                        UP=T
                        LH_temp=LH_temp2
                      }else{
                        BoxB_s[2]=BoxB_s[2]-0.05
                        test.env$BoxB_s <- BoxB_s
                      }
                    }else{
                      UP=F
                    }
                  }

                }

              }

              if(ER>1){
                for(t_r in max(1,(oldtr-1)):min((1+Klink),(oldtr+1))){
                  test.env$t_r <- t_r
                  if(SB>1){
                    for( t_b in max(1,(oldtb-1)):min((1+Klink),(oldtb+1))){
                      test.env$t_b <- t_b
                      if(SF>1){

                        for(t_s in max(1,(oldts-1)):min((1+Klink),(oldts+1))){
                          test.env$t_s <- t_s

                          sol_temp=function_to_minimize(param)
                          if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                            LH_temp=as.numeric(sol_temp)
                            oldtr=t_r
                            oldtb=t_b
                            oldts=t_s

                          }

                        }

                      }else{
                        sol_temp=function_to_minimize(param)
                        if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                          LH_temp=as.numeric(sol_temp)
                          oldtr=t_r
                          oldtb=t_b

                        }
                      }
                    }

                  }else{ # NO  SB
                    if(SF>1){
                      for(t_s in max(1,(oldts-1)):min((1+Klink),(oldts+1))){
                        test.env$t_s <- t_s
                        sol_temp=function_to_minimize(param)
                        if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                          LH_temp=as.numeric(sol_temp)
                          oldtr=t_r
                          oldts=t_s

                        }
                      }
                    }else{
                      sol_temp=function_to_minimize(param)
                      if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                        LH_temp=as.numeric(sol_temp)
                        oldtr=t_r

                      }
                    }
                  }
                }
              }else{ # No ER
                if(SB>1){
                  for( t_b in max(1,(oldtb-1)):min((1+Klink),(oldtb+1))){
                    test.env$t_b <- t_b
                    if(SF>1){

                      for(t_s in max(1,(oldts-1)):min((1+Klink),(oldts+1))){
                        test.env$t_s <- t_s
                        sol_temp=function_to_minimize(param)
                        if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                          LH_temp=as.numeric(sol_temp)
                          oldtb=t_b
                          oldts=t_s

                        }
                      }
                    }else{
                      sol_temp=function_to_minimize(param)
                      if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                        LH_temp=as.numeric(sol_temp)
                        oldtb=t_b

                      }
                    }
                  }
                }else{
                  if(SF>1){

                    for(t_s in max(1,(oldts-1)):min((1+Klink),(oldts+1))){
                      test.env$t_s <- t_s
                      sol_temp=function_to_minimize(param)
                      print(sol_temp)
                      if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                        LH_temp=as.numeric(sol_temp)
                        oldts=t_s


                      }
                    }
                  }else{

                    stop("How did you get here ?")

                  }
                }
              }
            }

            if(ER>1){
              test.env$t_r <- oldtr

              if(oldtr>Klink){
                oldrho=rep(Boxr_s[1],(Klink))
              }else{
                if(oldtr>1){
                  oldrho=c(rep(Boxr_s[1],(oldtr-1)),rep(Boxr_s[2],(Klink+1-oldtr)))
                }else{
                  oldrho=rep(Boxr_s[2],(Klink))
                }
              }



            }


            if(SF>1){
              # oldts=ceiling(sol[(start_position+1)]*Klink)
              #   start_position=start_position+1
              test.env$t_s <- oldts

              if(oldts>Klink){
                oldsigma=rep(Boxs_s[1],(Klink))
              }else{
                if(oldts>1){
                  oldsigma=c(rep(Boxs_s[1],(oldts-1)),rep(Boxs_s[2],(Klink+1-oldts)))
                }else{
                  oldsigma=rep(Boxs_s[2],(Klink))
                }
              }
            }



            if(SB>1){
              #    oldtb=ceiling(sol[(start_position+1)]*Klink)
              #   start_position=start_position+1
              test.env$t_b <- oldtb

              if(oldts>Klink){
                oldbeta=rep(BoxB_s[1],(Klink))
              }else{
                if(oldtb>1){
                  oldbeta=c(rep(BoxB_s[1],(oldtb-1)),rep(BoxB_s[2],(Klink+1-oldtb)))
                }else{
                  oldbeta=rep(BoxB_s[2],(Klink))
                }
              }


            }

            if(Popfix){
              if(ER<3){
                if(!is.list(oldrho)){
                  rho_=oldrho*sum(Boxr)
                  rho_=rho_-(Boxr[1])
                  rho_=10^(rho_)
                  rho_=rho_*Rho
                  rho=vector()
                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    rho[x:xx]= rho_[ix]
                  }
                }else{
                  rho_=list()
                  rho=list()
                  for(rr in 1:NC){
                    rho_[[rr]]=oldrho[[rr]]*sum(Boxr)
                    rho_[[rr]]=rho_[[rr]]-(Boxr[1])
                    rho_[[rr]]=10^(rho_[[rr]])
                    rho_[[rr]]=rho_[[rr]]*Rho[rr]

                    xx=0
                    rho[[rr]]=vector()
                    for(ix in 1:Klink){
                      x=xx+1
                      xx = xx + pop_vect[ix]
                      rho[[rr]][x:xx]= rho_[[rr]][ix]
                    }
                  }

                }
              }else{
                if(!is.list(oldrho)){
                  rho=vector()
                  if(oldtr==1){
                    rho_=oldrho*sum(Boxr_2)
                    rho_=rho_-(Boxr_2[1])
                    rho_=10^(rho_)
                    rho_=rho_*Rho
                  }
                  if(oldtr>Klink){
                    rho_=oldrho*sum(Boxr_1)
                    rho_=rho_-(Boxr_1[1])
                    rho_=10^(rho_)
                    rho_=rho_*Rho*correct_R
                  }
                  if(oldtr>1&oldtr<=Klink){
                    rho_=c(oldrho[1:(oldtr-1)]*sum(Boxr_1),oldrho[oldtr:Klink]*sum(Boxr_2))
                    rho_=c(rho_[1:(oldtr-1)]-(Boxr_1[1]),rho_[oldtr:Klink]-(Boxr_2[1]))
                    rho_=10^(rho_)
                    rho_=c(rho_[1:(oldtr-1)]*Rho,rho_[oldtr:Klink]*Rho*correct_R)

                  }




                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    rho[x:xx]= rho_[ix]
                  }
                }else{
                  rho_=list()
                  rho=list()
                  for(rr in 1:NC){


                    if(oldtr==1){
                      rho_[[rr]]=oldrho[[rr]]*sum(Boxr_2)
                      rho_[[rr]]=rho_[[rr]]-(Boxr_2[1])
                      rho_[[rr]]=10^(rho_[[rr]])
                      rho_[[rr]]=rho_[[rr]]*Rho[rr]
                    }
                    if(oldtr>Klink){
                      rho_[[rr]]=oldrho[[rr]]*sum(Boxr_1)
                      rho_[[rr]]=rho_[[rr]]-(Boxr_1[1])
                      rho_[[rr]]=10^(rho_[[rr]])
                      rho_[[rr]]=rho_[[rr]]*Rho[rr]*correct_R
                    }
                    if(oldtr>1&oldtr<=Klink){


                      rho_[[rr]]=c(oldrho[[rr]][1:(oldtr-1)]*sum(Boxr_1),oldrho[[rr]][oldtr:Klink]*sum(Boxr_2))
                      rho_[[rr]]=c(rho_[[rr]][1:(oldtr-1)]-(Boxr_1[1]),rho_[[rr]][oldtr:Klink]-(Boxr_2[1]))
                      rho_[[rr]]=10^(rho_[[rr]])
                      rho_[[rr]]=c(rho_[[rr]][1:(oldtr-1)]*Rho[rr],rho_[[rr]][oldtr:Klink]*Rho[rr]*correct_R)
                    }


                    xx=0
                    rho[[rr]]=vector()
                    for(ix in 1:Klink){
                      x=xx+1
                      xx = xx + pop_vect[ix]
                      rho[[rr]][x:xx]= rho_[[rr]][ix]
                    }
                  }

                }
              }


              if(SB>0){
                if(SB<3){
                  beta_=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1] )^2
                }else{
                  if(oldtb==1){
                    beta_=((oldbeta*(BoxB_2[2]-BoxB_2[1]))+BoxB_2[1] )^2
                  }else{
                    if(oldtb>Klink){
                      beta_=((oldbeta*(BoxB_1[2]-BoxB_1[1]))+BoxB_1[1] )^2
                    }else{
                      beta_= c( ((oldbeta[1:(oldtb-1)]*(BoxB_1[2]-BoxB_1[1]))+BoxB_1[1] )^2 , ((oldbeta[oldtb:Klink]*(BoxB_2[2]-BoxB_2[1]))+BoxB_2[1] )^2 )
                    }
                  }


                }

                beta=vector()
                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  beta[x:xx]=beta_[ix]
                }
              }
              if(SF>0){
                if(SF<3){
                  sigma_=oldsigma*(Boxs[2]-Boxs[1])
                  sigma_=sigma_+Boxs[1]
                }else{
                  if(oldts==1){
                    sigma_=oldsigma*(Boxs_2[2]-Boxs_2[1])
                    sigma_=sigma_+Boxs_2[1]
                  }else{
                    if(oldts>Klink){
                      sigma_=oldsigma*(Boxs_1[2]-Boxs_1[1])
                      sigma_=sigma_+Boxs_1[1]
                    }else{
                      sigma_= c(oldsigma[1:(oldts-1)]*(Boxs_1[2]-Boxs_1[1]) ,oldsigma[oldts:Klink]*(Boxs_2[2]-Boxs_2[1]))
                      sigma_= c( (sigma_[1:(oldts-1)]+Boxs_1[1]) , (sigma_[oldts:Klink]+Boxs_2[1]))
                    }
                  }
                }


                sigma=vector()
                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  sigma[x:xx]= sigma_[ix]
                }
              }
              print(c("sigma:",sigma,"beta :",beta))
              if(is.list(rho_)){
                print(c("rho/theta:",rho_[[1]]/theta))
              }else{
                print(c("rho/theta:",rho_/theta))
              }
              Keep_going=F
              if(it==1){
                diff_o=0
              }
              if(it>1){
                if(SF==1){
                  diff_o=mean(abs(sigma_o-sigma))
                }
                if(SF>1){
                  diff_o=0.0001
                }
                if(SB==1){
                  diff_o=max(diff_o,mean(abs(beta_o-beta)))
                }
                if(SB>1){
                  diff_o=max(diff_o,0.0001)
                }
                count_diff_o=0
                if(diff_o>=0.005){
                  if(it==maxIt){
                    count_diff_o=count_diff_o+1
                    maxIt=maxIt+1
                    if(count_diff_o>10){
                      maxBit=maxBit-1
                    }
                  }
                }
              }
              sigma_o=sigma
              beta_o=beta



              if(NC==1){
                builder=build_HMM_matrix_t(k,(rho),beta=beta,L=L,Pop=Pop,Xi=NA,Beta=Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
              }
              if(NC>1){
                builder=list()
                for(chr in 1:NC){
                  builder[[chr]]=build_HMM_matrix_t(k,(rho[[chr]]),beta=beta,L=L[chr],Pop=Pop,Xi=NA,Beta=Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
                }
              }
            }
            if(!Popfix){
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                oldXi[x:xx]=oldXi_[ix]
              }
              Xi_=oldXi*sum(BoxP)
              Xi_=Xi_-(BoxP[1])
              Xi_=10^Xi_
              if(ER<3){
                if(!is.list(oldrho)){
                  rho_=oldrho*sum(Boxr)
                  rho_=rho_-(Boxr[1])
                  rho_=10^(rho_)
                  rho_=rho_*Rho
                  rho=vector()
                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    rho[x:xx]= rho_[ix]
                  }
                }else{
                  rho_=list()
                  rho=list()
                  for(rr in 1:NC){
                    rho_[[rr]]=oldrho[[rr]]*sum(Boxr)
                    rho_[[rr]]=rho_[[rr]]-(Boxr[1])
                    rho_[[rr]]=10^(rho_[[rr]])
                    rho_[[rr]]=rho_[[rr]]*Rho[rr]

                    xx=0
                    rho[[rr]]=vector()
                    for(ix in 1:Klink){
                      x=xx+1
                      xx = xx + pop_vect[ix]
                      rho[[rr]][x:xx]= rho_[[rr]][ix]
                    }
                  }

                }
              }else{
                if(!is.list(oldrho)){
                  rho=vector()
                  if(oldtr==1){
                    rho_=oldrho*sum(Boxr_2)
                    rho_=rho_-(Boxr_2[1])
                    rho_=10^(rho_)
                    rho_=rho_*Rho
                  }
                  if(oldtr>Klink){
                    rho_=oldrho*sum(Boxr_1)
                    rho_=rho_-(Boxr_1[1])
                    rho_=10^(rho_)
                    rho_=rho_*Rho*correct_R
                  }
                  if((oldtr>1)&oldtr<=Klink){
                    rho_=c(oldrho[1:(oldtr-1)]*sum(Boxr_1),oldrho[oldtr:Klink]*sum(Boxr_2))
                    rho_=c(rho_[1:(oldtr-1)]-(Boxr_1[1]),rho_[oldtr:Klink]-(Boxr_2[1]))
                    rho_=10^(rho_)
                    rho_=c(rho_[1:(oldtr-1)]*Rho,rho_[oldtr:Klink]*Rho*correct_R)
                  }




                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    rho[x:xx]= rho_[ix]
                  }
                }else{
                  rho_=list()
                  rho=list()
                  for(rr in 1:NC){


                    if(oldtr==1){
                      rho_[[rr]]=oldrho[[rr]]*sum(Boxr_2)
                      rho_[[rr]]=rho_[[rr]]-(Boxr_2[1])
                      rho_[[rr]]=10^(rho_[[rr]])
                      rho_[[rr]]=rho_[[rr]]*Rho[rr]
                    }
                    if(oldtr>Klink){
                      rho_[[rr]]=oldrho[[rr]]*sum(Boxr_1)
                      rho_[[rr]]=rho_[[rr]]-(Boxr_1[1])
                      rho_[[rr]]=10^(rho_[[rr]])
                      rho_[[rr]]=rho_[[rr]]*Rho[rr]*correct_R
                    }
                    if((oldtr>1)&oldtr<=Klink){
                      rho_[[rr]]=c(oldrho[[rr]][1:(oldtr-1)]*sum(Boxr_1),oldrho[[rr]][oldtr:Klink]*sum(Boxr_2))
                      rho_[[rr]]=c(rho_[[rr]][1:(oldtr-1)]-(Boxr_1[1]),rho_[[rr]][oldtr:Klink]-(Boxr_2[1]))
                      rho_[[rr]]=10^(rho_[[rr]])
                      rho_[[rr]]=c(rho_[[rr]][1:(oldtr-1)]*Rho[rr],rho_[[rr]][oldtr:Klink]*Rho[rr]*correct_R)

                    }


                    xx=0
                    rho[[rr]]=vector()
                    for(ix in 1:Klink){
                      x=xx+1
                      xx = xx + pop_vect[ix]
                      rho[[rr]][x:xx]= rho_[[rr]][ix]
                    }
                  }

                }
              }
              if(SB>0){
                if(SB<3){
                  beta_=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1] )^2
                }else{
                  if(oldtb==1){
                    beta_=((oldbeta*(BoxB_2[2]-BoxB_2[1]))+BoxB_2[1] )^2
                  }else{
                    if(oldtb>Klink){
                      beta_=((oldbeta*(BoxB_1[2]-BoxB_1[1]))+BoxB_1[1] )^2
                    }else{
                      beta_= c( ((oldbeta[1:(oldtb-1)]*(BoxB_1[2]-BoxB_1[1]))+BoxB_1[1] )^2 , ((oldbeta[oldtb:Klink]*(BoxB_2[2]-BoxB_2[1]))+BoxB_2[1] )^2 )
                    }
                  }
                }

                beta=vector()
                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  beta[x:xx]=beta_[ix]
                }
              }
              if(SF>0){
                if(SF<3){
                  sigma_=oldsigma*(Boxs[2]-Boxs[1])
                  sigma_=sigma_+Boxs[1]
                }else{
                  if(oldts==1){
                    sigma_=oldsigma*(Boxs_2[2]-Boxs_2[1])
                    sigma_=sigma_+Boxs_2[1]
                  }else{
                    if(oldts>Klink){
                      sigma_=oldsigma*(Boxs_1[2]-Boxs_1[1])
                      sigma_=sigma_+Boxs_1[1]
                    }else{
                      sigma_= c(oldsigma[1:(oldts-1)]*(Boxs_1[2]-Boxs_1[1]) ,oldsigma[oldts:Klink]*(Boxs_2[2]-Boxs_2[1]) )
                      sigma_= c( (sigma_[1:(oldts-1)]+Boxs_1[1]) , (sigma_[oldts:Klink]+Boxs_2[1]))
                    }
                  }
                }
                sigma=vector()
                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  sigma[x:xx]= sigma_[ix]
                }
              }
              print(c("sigma:",sigma,"beta :",beta))
              Keep_going=F
              if(it==1){
                diff_o=0
              }
              if(it>1){
                if(SF>1){
                  diff_o=mean(abs(sigma_o-sigma))
                }
                if(SF==2){
                  diff_o=0.0001
                }
                if(SB==1){
                  diff_o=max(diff_o,mean(abs(beta_o-beta)))
                }
                if(SB>1){
                  diff_o=max(diff_o,0.0001)
                }
                count_diff_o=0
                if(diff_o>=0.005){
                  if(it==maxIt){
                    count_diff_o=count_diff_o+1
                    maxIt=maxIt+1
                    if(count_diff_o>10){
                      maxBit=maxBit-1
                    }
                  }
                }
              }
              sigma_o=sigma
              beta_o=beta
              # browser()
              if(NC==1){
                builder=build_HMM_matrix_t(k,(rho),beta=beta,L=L,Pop=Pop,Xi_,Beta=Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
              }
              if(NC>1){
                builder=list()
                for(chr in 1:NC){
                  builder[[chr]]=build_HMM_matrix_t(k,(rho[[chr]]),beta=beta,L=L[chr],Pop=Pop,Xi_,Beta=Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
                }
              }
            }


            if(ER>1){
              oldtr_s=oldtr
            }
            if(SF>1){
              oldts_s=oldts
            }
            if(SB>1){
              oldtb_s=oldtb
            }
            if(!Popfix){
              oldXi_s=oldXi_
            }
            if(ER>0){
              oldrho_s=oldrho
            }
            if(SB>0){
              oldbeta_s=oldbeta
            }
            if(SF>0){
              oldsigma_s=oldsigma
            }

              Q=list()
              nu=list()
              Tc=list()
              g=list()
              M=list()
              N=list()
              MLH=list()
              q_=list()
              for(chr in 1:NC){
                Q[[chr]] = builder[[chr]][[1]]
                nu[[chr]]= builder[[chr]][[2]]
                Tc[[chr]]=builder[[chr]][[3]]
                g[[chr]]=build_emission_matrix(mu[chr],mu_b,Tc=builder[[chr]][[4]],t=builder[[chr]][[3]],beta,FS)


                M[[chr]]=matrix(0,nrow=length(Tc[[chr]]),ncol=3)
                N[[chr]]=matrix(0,length(Tc[[chr]]),length(Tc[[chr]]))
                MLH[[chr]]=0
                q_[[chr]]=rep(0,length(Tc[[chr]]))
                test=Build_zip_Matrix_mailund(Q[[chr]],g[[chr]],Os[[chr]][[1]][[2]],nu[[chr]])

                for(i in 1:length(Os[[chr]])){
                  Os[[chr]][[i]][[1]]=as.numeric(Os[[chr]][[i]][[1]])
                  fo=forward_zip_mailund(Os[[chr]][[i]][[1]],g[[chr]],nu[[chr]],test[[1]])
                  MLH[[chr]]=MLH[[chr]]+fo[[3]]
                  c=exp(fo[[2]])
                  ba=Backward_zip_mailund(Os[[chr]][[i]][[1]],test[[3]],length(Tc[[chr]]),c)
                  W_P=list()
                  W_P_=list()
                  count_oo=0
                  for(oo in c(1,3)){
                    count_oo=count_oo+1
                    int=t(Q[[chr]])%*%diag(g[[chr]][,oo])
                    int=eigen(int)
                    W_P[[count_oo]]=int$vectors
                    W_P_[[count_oo]]=solve(W_P[[count_oo]])
                  }
                  symbol= c(0:2,10:40)
                  for(ob in 1){
                    truc_M=matrix(0,nrow=length(Tc[[chr]]),ncol=3)
                    if(as.numeric(Os[[chr]][[i]][[1]][(ob+1)])<=4){
                      truc_N=(fo[[1]][,ob]%*%(t(ba[,(ob+1)]*g[[chr]][,(as.numeric(Os[[chr]][[i]][[1]][(ob+1)])+1)]/c[(ob+1)])))
                      truc_M[,(as.numeric(Os[[chr]][[i]][[1]][(ob+1)])+1)]=fo[[1]][,ob]*(test[[2]][[(as.numeric(Os[[chr]][[i]][[1]][(ob+1)])+1)]]%*%(ba[,(ob+1)]/c[(ob+1)]))
                    }else{
                      if(as.numeric(Os[[chr]][[i]][[1]][(ob+1)])<30){
                        truc_N=(t(W_P_[[1]])%*%(t(W_P[[1]])%*%fo[[1]][,ob]%*%t(ba[,(ob+1)]/c[(ob+1)])%*%t(W_P_[[1]])*test[[4]][[(as.numeric(Os[[chr]][[i]][[1]][(ob+1)]))]])%*%(t(W_P[[1]]))%*%diag(g[[chr]][,1]))
                        truc_M[,1]=diag(t(W_P_[[1]])%*%(t(W_P[[1]])%*%fo[[1]][,ob]%*%t(ba[,(ob+1)]/c[(ob+1)])%*%t(W_P_[[1]]))*test[[2]][[(as.numeric(Os[[chr]][[i]][[1]][(ob+1)]))]]%*%t(W_P[[1]]))
                      }else{
                        truc_N=(t(W_P_[[2]])%*%(t(W_P[[2]])%*%fo[[1]][,ob]%*%t(ba[,(ob+1)]/c[(ob+1)])%*%t(W_P_[[2]])*test[[4]][[(as.numeric(Os[[chr]][[i]][[1]][(ob+1)]))]])%*%(t(W_P[[2]]))%*%diag(g[[chr]][,3]))
                        truc_M[,3]=diag(t(W_P_[[2]])%*%(t(W_P[[2]])%*%fo[[1]][,ob]%*%t(ba[,(ob+1)]/c[(ob+1)])%*%t(W_P_[[2]]))*test[[2]][[(as.numeric(Os[[chr]][[i]][[1]][(ob+1)]))]]%*%t(W_P[[2]]))

                      }

                    }
                    N[[chr]]=N[[chr]]+truc_N
                    M[[chr]]=M[[chr]]+truc_M
                  }
                  for(sym in symbol){
                    ob=as.numeric(sym)
                    pos=which(as.numeric(Os[[chr]][[i]][[1]][-c(1,length(Os[[chr]][[i]][[1]]))])==ob)
                    if(length(pos)>0){
                      pos=pos+1
                      if(ob<3){
                        ba_t=t(t(ba[,(pos)])/c[(pos)])
                        truc=c(rowSums(fo[[1]][,(pos-1)]*(test[[1]][[(ob+1)]]%*%ba_t)))
                        truc=(truc/(sum(truc)))*length(pos)
                        M[[chr]][,(ob+1)]=M[[chr]][,(ob+1)]+ truc
                        N[[chr]]=N[[chr]]+(fo[[1]][,(pos-1)]%*%(t(diag(g[[chr]][,(ob+1)])%*%ba_t)))
                      }else{
                        if(ob<30){
                          A=(t(W_P[[1]])%*%fo[[1]][,(pos-1)]%*%t(t(t(ba[,(pos)])/c[(pos)]))%*%t(W_P_[[1]]))
                          A_=A*test[[2]][[(ob)]]
                          A_=(t(W_P_[[1]])%*%A_%*%t(W_P[[1]]))
                          M[[chr]][,1]=M[[chr]][,1]+(diag(A_))
                          A_=A*test[[4]][[(ob)]]
                          A_=(t(W_P_[[1]])%*%A_%*%t(W_P[[1]]))
                          N[[chr]]=N[[chr]]+((A_%*%diag(g[[chr]][,1])))
                        }else{
                          A=(t(W_P[[2]])%*%fo[[1]][,(pos-1)]%*%t(t(t(ba[,(pos)])/c[(pos)]))%*%t(W_P_[[2]]))
                          A_=A*test[[2]][[(ob)]]
                          A_=(t(W_P_[[2]])%*%A_%*%t(W_P[[2]]))
                          M[[chr]][,3]=M[[chr]][,3]+(diag(A_))
                          A_=A*test[[4]][[(ob)]]
                          A_=(t(W_P_[[2]])%*%A_%*%t(W_P[[2]]))
                          N[[chr]]=N[[chr]]+((A_%*%diag(g[[chr]][,3])))
                        }
                      }
                    }
                  }
                  if(as.numeric(Os[[chr]][[i]][[1]][length(Os[[chr]][[i]][[1]])])<=3){
                    M[[chr]][,(as.numeric(Os[[chr]][[i]][[1]][length(Os[[chr]][[i]][[1]])])+1)]=M[[chr]][,(as.numeric(Os[[chr]][[i]][[1]][length(Os[[chr]][[i]][[1]])])+1)]+(fo[[1]][,length(Os[[chr]][[i]][[1]])]*ba[,length(Os[[chr]][[i]][[1]])])
                  }
                  if(as.numeric(Os[[chr]][[i]][[1]][length(Os[[chr]][[i]][[1]])])>3){
                    if(as.numeric(Os[[chr]][[i]][[1]][length(Os[[chr]][[i]][[1]])])<30){
                      M[[chr]][,1]=M[[chr]][,1]+((fo[[1]][,length(Os[[chr]][[i]][[1]])]*ba[,length(Os[[chr]][[i]][[1]])])/sum(fo[[1]][,length(Os[[chr]][[i]][[1]])]*ba[,length(Os[[chr]][[i]][[1]])]))

                    }else{
                      M[[chr]][,3]=M[[chr]][,3]+((fo[[1]][,length(Os[[chr]][[i]][[1]])]*ba[,length(Os[[chr]][[i]][[1]])])/sum(fo[[1]][,length(Os[[chr]][[i]][[1]])]*ba[,length(Os[[chr]][[i]][[1]])]))

                    }
                  }
                  q_[[chr]]=q_[[chr]]+((fo[[1]][,1]*ba[,(1)])/sum(fo[[1]][,1]*ba[,(1)]))
                }

                N[[chr]]=N[[chr]]*t(Q[[chr]])
                if(is.complex(N[[chr]])){
                  N[[chr]]=Re(N[[chr]])
                }

                if(is.complex(M[[chr]])){
                  M[[chr]]=Re(M[[chr]])
                }
                Scale_N=(L[chr]-1)/sum(N[[chr]])
                N[[chr]]=N[[chr]]*Scale_N

                Scale_M=L[chr]/sum(M[[chr]])
                M[[chr]]=M[[chr]]*Scale_M
                q_[[chr]]=q_[[chr]]/sum(q_[[chr]])
                if(SCALED){
                  corrector_M=rowSums(M[[chr]])
                  M[[chr]]=diag(1/corrector_M)%*%M[[chr]]
                  corrector_N=rowSums(N[[chr]])
                  N[[chr]]=diag(1/corrector_N)%*%N[[chr]]
                }


              }

          }

        }

        if(it>1){
          print(paste(" old Likelihood: ",oldMLH))
        }
        if(NC==1){
          print(paste(" New Likelihood: ",MLH))

          if(it>1){

            if(oldMLH >= MLH|MLH=="NaN"){
            browser()
              if(it>2){

                if(!Popfix){
                  oldXi_=oldXi_s
                }
                if(ER>0&ER<3){
                  oldrho=oldrho_s
                }
                if(SB>0&SB<3){
                  oldbeta=oldbeta_s
                }
                if(SF>0&SF<3){
                  oldsigma=oldsigma_s
                }

                if(ER>1){
                  oldtr=oldtr_s
                }
                if(SF>1){
                  oldts=oldts_s
                }
                if(SB>1){
                  oldtb=oldtb_s
                }
              }
              if(it==2){
                print("Algortihm has converge but may need more data for better results ")
                MB=maxBit
              }
              it=maxIt
              Do_BW=F
            }

          }
          oldMLH=MLH
        }
        if(NC>1){
          MLH1=0
          for(chr in 1:length(MLH)){
            MLH1=MLH[[chr]]+MLH1
          }
          print(paste("New Likelihood: ",MLH1))
          if(it>1){
            if(oldMLH >= MLH1|MLH1=="NaN"){
              if(it>1){

                if(!Popfix){
                  oldXi_=oldXi_s
                }
                if(ER>0&ER<3){
                  oldrho=oldrho_s
                }
                if(SB>0&SB<3){
                  oldbeta=oldbeta_s
                }
                if(SF>0&SF<3){
                  oldsigma=oldsigma_s
                }
                if(ER>1){
                  oldtr=oldtr_s
                }
                if(SF>1){
                  oldts=oldts_s
                }
                if(SB>1){
                  oldtb=oldtb_s
                }

              }
              if(it==2){
                print("Algortihm has converge but may need more data for better results ")

                MB=maxBit
              }
              it=maxIt
              Do_BW=F
            }

          }
          oldMLH=MLH1
        }

            test.env$Big_Xi <- N
            test.env$Big_M <-M
            test.env$q_ <-q_




          lr=length(oldrho)
          test.env$lr<-lr

    if(Do_BW){
       if(NC==1){

              test.env$ER <- ER
              test.env$SF <- SF
              test.env$SB <- SB
              test.env$Os <- Os


              function_to_minimize<-function(param){
                matrix_param=get('matrix_param', envir=test.env)
                Boxr=get('Boxr', envir=test.env)
                mu=get('mu', envir=test.env)
                npair=get('npair', envir=test.env)
                Big_Window=get('Big_Window', envir=test.env)
                mu_b=get('mu_b', envir=test.env)
                FS=get('FS', envir=test.env)
                Klink=get('Klink', envir=test.env)
                Rho=get('Rho', envir=test.env)
                BoxB=get('BoxB', envir=test.env)
                Boxs=get('Boxs', envir=test.env)
                BoxP=get('BoxP', envir=test.env)
                pop_vect=get('pop_vect', envir=test.env)
                L=get('L', envir=test.env)
                n=get('k', envir=test.env)
                Beta=get('Beta', envir=test.env)
                Self=get('Self', envir=test.env)
                window_scaling=get('window_scaling', envir=test.env)
                Pop=get('Pop', envir=test.env)
                ER=get('ER', envir=test.env)
                SF=get('SF', envir=test.env)
                SB=get('SB', envir=test.env)
                Os=get('Os', envir=test.env)
                q_=get('q_', envir=test.env)
                hs_vect=get('hs_vect', envir=test.env)
                Big_M=get('Big_M', envir=test.env)
                BW=get('BW', envir=test.env)
                Big_Xi=get('Big_Xi', envir=test.env)
                X_star=get('X_star', envir=test.env)

                start_position=0
                if(ER==1){
                  rho_=numeric(n)
                  rho=param[(start_position+1):(start_position+Klink)]
                  rho=rho*sum(Boxr)
                  rho=rho-(Boxr[1])
                  rho=10^(rho)
                  rho=rho*Rho
                  start_position=start_position+Klink
                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    rho_[x:xx]=rho[ix]

                  }

                }
                if(ER==2){

                  Boxr_s=get('Boxr_s', envir=test.env)

                  rho_=numeric(n)
                  #t_r=min(ceiling(param[(start_position+1)]*Klink),Klink)
                  t_r=get('t_r', envir=test.env)

                  if(t_r>Klink){
                    rho=rep(Boxr_s[1],Klink)
                  }else{
                    if(t_r>1){
                      rho=c(rep(Boxr_s[1],(t_r-1)),rep(Boxr_s[2],(Klink-t_r+1)))
                    }else{
                      rho=rep(Boxr_s[2],Klink)
                    }
                  }


                  rho=rho*sum(Boxr)
                  rho=rho-(Boxr[1])
                  rho=10^(rho)
                  rho=rho*Rho
                  #start_position=start_position+1
                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    rho_[x:xx]=rho[ix]

                  }
                }
                if(ER==3){
                  t_r=get('t_r', envir=test.env)
                  Boxr_s=param[(start_position+1):(start_position+2)]
                  start_position=start_position+2
                  Boxr_1=get('Boxr_1', envir=test.env)
                  Boxr_2=get('Boxr_2', envir=test.env)
                  correct_R=get('correct_R', envir=test.env)
                  rho_=numeric(n)
                  #t_r=min(ceiling(param[(start_position+1)]*Klink),Klink)


                  if(t_r>Klink){

                    rho=rep(Boxr_s[1],Klink)
                    rho=rho*sum(Boxr_1)
                    rho=rho-(Boxr_1[1])
                    rho=10^(rho)
                    rho=rho*Rho
                  }else{
                    if(t_r>1){
                      rho=c(rep(Boxr_s[1],(t_r-1)),rep(Boxr_s[2],(Klink-t_r+1)))
                      rho=c(rho[1:(t_r-1)]*sum(Boxr_1),rho[t_r:Klink]*sum(Boxr_2))
                      rho=c(rho[1:(t_r-1)]-(Boxr_1[1]),rho[t_r:Klink]-(Boxr_2[1]))
                      rho=10^(rho)
                      rho=c(rho[1:(t_r-1)]*Rho,rho[t_r:Klink]*Rho*correct_R)
                    }else{
                      rho=rep(Boxr_s[2],Klink)
                      rho=rho*sum(Boxr_2)
                      rho=rho-(Boxr_2[1])
                      rho=10^(rho)
                      rho=rho*Rho*correct_R
                    }
                  }
                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    rho_[x:xx]=rho[ix]

                  }
                }
                if(ER==0){
                  rho_=rep(Rho,n)
                }
                if(SF==1){
                  sigma_=numeric(n)
                  sigma=param[(start_position+1):(start_position+Klink)]
                  start_position=start_position+Klink
                  sigma=sigma*(Boxs[2]-Boxs[1])
                  sigma=sigma+Boxs[1]
                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    sigma_[x:xx]=sigma[ix]
                  }
                }
                if(SF==2){
                  Boxs_s=get('Boxs_s', envir=test.env)
                  sigma_=numeric(n)

                  #t_s=min(ceiling(param[(start_position+1)]*Klink),Klink)
                  t_s=get('t_s', envir=test.env)
                  if(t_s>Klink){
                    sigma=rep(Boxs_s[1],Klink)
                  }else{
                    if(t_s>1){
                      sigma=c(rep(Boxs_s[1],(t_s-1)),rep(Boxs_s[2],(Klink-t_s+1)))
                    }else{
                      sigma=rep(Boxs_s[2],Klink)
                    }
                  }
                  #start_position=start_position+1
                  sigma=sigma*(Boxs[2]-Boxs[1])
                  sigma=sigma+Boxs[1]
                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    sigma_[x:xx]=sigma[ix]
                  }

                }
                if(SF==3){
                  Boxs_s=param[(start_position+1):(start_position+2)]
                  start_position=start_position+2
                  Boxs_1=get('Boxs_1', envir=test.env)
                  Boxs_2=get('Boxs_2', envir=test.env)
                  sigma_=numeric(n)
                  t_s=get('t_s', envir=test.env)

                  if(t_s>Klink){
                    sigma=rep(Boxs_s[1],Klink)
                    sigma=sigma*(Boxs_1[2]-Boxs_1[1])
                    sigma=sigma+Boxs_1[1]
                  }else{
                    if(t_s>1){
                      sigma=c(rep(Boxs_s[1],(t_s-1)),rep(Boxs_s[2],(Klink-t_s+1)))
                      sigma= c(sigma[1:(t_s-1)]*(Boxs_1[2]-Boxs_1[1]),sigma[t_s:Klink]*(Boxs_2[2]-Boxs_2[1]) )
                      sigma= c(sigma[1:(t_s-1)]+Boxs_1[1],sigma[t_s:Klink]+Boxs_2[1])
                    }else{
                      sigma=rep(Boxs_s[2],Klink)
                      sigma=sigma*(Boxs_2[2]-Boxs_2[1])
                      sigma=sigma+Boxs_2[1]
                    }
                  }
                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    sigma_[x:xx]=sigma[ix]
                  }
                }
                if(SF==0){
                  sigma_=rep(sigma,n)
                }
                if(SB==1){
                  beta_=numeric(n)
                  beta=((param[(start_position+1):(start_position+Klink)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
                  start_position=start_position+(Klink)
                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    beta_[x:xx]=beta[ix]

                  }
                }
                if(SB==2){
                  beta_=numeric(n)
                  BoxB_s=get('BoxB_s', envir=test.env)
                  #t_b=min(ceiling(param[(start_position+1)]*Klink),Klink)
                  t_b=get('t_b', envir=test.env)
                  if(t_b>Klink){
                    beta=rep(BoxB_s[1],Klink)
                  }else{
                    if(t_b>1){
                      beta=c(rep(BoxB_s[1],(t_b-1)),rep(BoxB_s[2],(Klink-t_b+1)))
                    }else{
                      beta=rep(BoxB_s[2],Klink)
                    }
                  }

                  beta=((beta*(BoxB[2]-BoxB[1]))+BoxB[1])^2
                  # start_position=start_position+1
                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    beta_[x:xx]=beta[ix]

                  }
                }
                if(SB==0){
                  beta_=rep(beta,n)
                }
                if(SB==3){
                  beta_=numeric(n)
                  BoxB_s=param[(start_position+1):(start_position+2)]
                  start_position=start_position+2
                  BoxB_1=get('BoxB_1', envir=test.env)
                  BoxB_2=get('BoxB_2', envir=test.env)
                  t_b=get('t_b', envir=test.env)
                  if(t_b>Klink){
                    beta=rep(BoxB_s[1],Klink)
                    beta=((beta*(BoxB_1[2]-BoxB_1[1]))+BoxB_1[1])^2
                  }else{
                    if(t_b>1){
                      beta=c(rep(BoxB_s[1],(t_b-1)),rep(BoxB_s[2],(Klink-t_b+1)))
                      beta=c((((beta[1:(t_b-1)]*(BoxB_1[2]-BoxB_1[1]))+BoxB_1[1])^2),(((beta[t_b:Klink]*(BoxB_2[2]-BoxB_2[1]))+BoxB_2[1])^2))
                    }else{
                      beta=rep(BoxB_s[2],Klink)
                      beta=((beta*(BoxB_2[2]-BoxB_2[1]))+BoxB_2[1])^2
                    }
                  }


                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    beta_[x:xx]=beta[ix]

                  }
                }
                if(!Pop){
                  Xi=numeric(n)
                  Xi_=param[(start_position+1):(start_position+Klink)]
                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    Xi[x:xx]=Xi_[ix]
                  }
                  Xi=Xi*sum(BoxP)
                  Xi=Xi-(BoxP[1])
                  Xi=10^Xi
                }else{
                  Xi=rep(1,n)
                }
                # browser()
                builder=build_HMM_matrix_t(n,rho_,beta=beta_,Pop = Pop,Xi=Xi,L=L,Beta=Beta,scale=window_scaling,sigma = sigma_,Sigma = Self,Big_Window=Big_Window,npair=npair)
                Q=builder[[1]]
                Q=t(Q)
                A=as.vector(Q)
                keep=which(A>0&as.vector(Big_Xi)>0)
                A=A[keep]
                Big_Xi=as.vector(Big_Xi)
                Big_Xi=Big_Xi[keep]

                Tc=builder[[3]]
                g=build_emission_matrix(mu,mu_b,Tc=builder[[4]],t=builder[[3]],beta,FS)

                LH=0
                x=as.vector(g)
                keep=which(x>0)
                x=x[keep]
                m=as.vector(Big_M)
                m=m[keep]
                a=0
                nu=builder[[2]]
                if(BW){
                  LH=-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
                }
                if(!BW){
                  LH=-sum(log(A)*Big_Xi)

                }

                if(!is.na(matrix_param)){
                  Q_copy=Q
                  for(nb_matrix in 1:length(matrix_param)){
                    #Q_star=sapply(1:matrix_param[[nb_matrix]][2], function(x){Q%^%x})

                    Q_s=diag(1,n)
                    if(!is.na(hs_vect)){

                      for(iii in 1:length(hs_vect) ){
                        Q_copy[,min(hs_vect[[iii]])]=rowSums(Q_copy[,hs_vect[[iii]]])
                        rm_v=c(sort(hs_vect[[iii]])[-1])
                        Q_copy=Q_copy[,-rm_v]
                        #browser()
                        Q_copy[min(hs_vect[[iii]]),]=colSums(diag(nu[hs_vect[[iii]]]/sum(nu[hs_vect[[iii]]]))%*%Q_copy[hs_vect[[iii]],])#/length(hs_vect[[iii]])
                        Q_copy=Q_copy[-rm_v,]
                      }
                    }

                    Q_s=diag(1,dim(Q_copy)[1])
                    #print(dim(Q_copy))
                    Q_star=matrix(0,dim(Q_s)[1],dim(Q_s)[1])
                    for(xx in 1:matrix_param[[nb_matrix]][2]){
                      Q_s=Q_s%*%Q_copy
                      Q_star=Q_star+Q_s
                    }
                    # Q_star=rowSums(Q_star)
                    # Q_star=matrix(Q_star,n,n)

                    a_temp=sum(abs(as.numeric(X_star[[nb_matrix]])-as.numeric(Q_star)))
                    scale=matrix_param[[nb_matrix]][1]*LH/a_temp
                    a=a+abs(a_temp*scale)

                  }

                }



                LH=LH+a

                return(LH)
              }


              param=c()
              if(ER==1){
                param=c(param,oldrho)

              }
              if(ER==3){
                param=c(param,Boxr_s)

              }
              if(SF==1){
                param=c(param,oldsigma)

              }
              if(SF==3){
                param=c(param,Boxs_s)
              }
              if(SB==1){
                param=c(param,oldbeta)
              }
              if(SB==3){
                param=c(param,BoxB_s)
              }
              if(!Popfix){
                param=c(param,oldXi_)
              }
              if(length(param)>0){
                if(max(c(ER,SB,SF))<2){
                sol= BB::BBoptim(param,function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=length(param),M=c(20)))

                sol=as.matrix(sol[[1]])
                start_position=0
                sol=as.numeric(sol[1:length(param),1])

              }else{
                sol= BB::BBoptim(param,function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=10+length(param),M=c(20)))

                sol=as.matrix(sol[[1]])
                start_position=0
                sol=as.numeric(sol[1:length(param),1])
              }

              if(ER==1){
                rho=sol[(start_position+1):(start_position+Klink)]
                start_position=start_position+Klink
                # browser()
                oldrho=rho
              }
              if(ER==3){
                Boxr_s=sol[(start_position+1):(start_position+2)]
                test.env$Boxr_s <- Boxr_s
                start_position=start_position+2
                if(oldtr>Klink){
                  oldrho=rep(Boxr_s[1],(Klink))
                }else{
                  if(oldtr>1){
                    oldrho=c(rep(Boxr_s[1],(oldtr-1)),rep(Boxr_s[2],(Klink+1-oldtr)))
                  }else{
                    oldrho=rep(Boxr_s[2],(Klink))
                  }
                }
              }
              if(SF==1){
                sigma_=sol[(start_position+1):(start_position+Klink)]
                start_position=start_position+Klink
                oldsigma=sigma_
              }

              if(SF==3){
                Boxs_s=sol[(start_position+1):(start_position+2)]
                test.env$Boxs_s <- Boxs_s
                start_position=start_position+2
                if(oldts>Klink){
                  oldsigma=rep(Boxs_s[1],(Klink))
                }else{
                  if(oldts>1){
                    oldsigma=c(rep(Boxs_s[1],(oldts-1)),rep(Boxs_s[2],(Klink+1-oldts)))
                  }else{
                    oldsigma=rep(Boxs_s[2],(Klink))
                  }
                }
              }

              if(SB==1){
                beta_=sol[(start_position+1):(start_position+Klink)]
                start_position=start_position+Klink
                oldbeta=beta_
              }

              if(SB==3){
                BoxB_s=sol[(start_position+1):(start_position+2)]
                test.env$BoxB_s <- BoxB_s
                start_position=start_position+2
                if(oldtb>Klink){
                  oldbeta=rep(BoxB_s[1],(Klink))
                }else{
                  if(oldtb>1){
                    oldbeta=c(rep(BoxB_s[1],(oldtb-1)),rep(BoxB_s[2],(Klink+1-oldtb)))
                  }else{
                    oldbeta=rep(BoxB_s[2],(Klink))
                  }
                }
              }


              if(!Popfix){
                Xi_=sol[(start_position+1):(start_position+Klink)]
                start_position=start_position+Klink
                oldXi_=Xi_
              }

              }


            }


            if(NC>1){

              test.env$ER <- ER
              test.env$SF <- SF
              test.env$SB <- SB
              test.env$Os <- Os


              function_to_minimize<-function(param){
                Boxr=get('Boxr', envir=test.env)
                mu=get('mu', envir=test.env)
                npair=get('npair', envir=test.env)
                Big_Window=get('Big_Window', envir=test.env)
                mu_b=get('mu_b', envir=test.env)
                FS=get('FS', envir=test.env)
                Klink=get('Klink', envir=test.env)
                Rho=get('Rho', envir=test.env)
                BoxB=get('BoxB', envir=test.env)
                Boxs=get('Boxs', envir=test.env)
                BoxP=get('BoxP', envir=test.env)
                pop_vect=get('pop_vect', envir=test.env)
                L=get('L', envir=test.env)
                n=get('k', envir=test.env)
                Beta=get('Beta', envir=test.env)
                Self=get('Self', envir=test.env)
                window_scaling=get('window_scaling', envir=test.env)
                Pop=get('Pop', envir=test.env)
                ER=get('ER', envir=test.env)
                SF=get('SF', envir=test.env)
                SB=get('SB', envir=test.env)
                Os=get('Os', envir=test.env)
                q_=get('q_', envir=test.env)
                Big_M=get('Big_M', envir=test.env)
                BW=get('BW', envir=test.env)
                Big_Xi=get('Big_Xi', envir=test.env)
                NC=get('NC', envir=test.env)
                a=0
                start_position=0
                if(ER==1){
                  rho=list()
                  rho_=list()
                  oldrho_param=param[(start_position+1):(start_position+(Klink*NC))]
                  for(rr in 1:NC){
                    rho[[rr]]= oldrho_param[(1+((rr-1)*Klink)):(rr*Klink)]*sum(Boxr)
                    rho[[rr]]=rho[[rr]]-(Boxr[1])
                    rho[[rr]]=10^(rho[[rr]])
                    rho[[rr]]=rho[[rr]]*Rho[rr]

                    xx=0
                    rho_[[rr]]=vector()
                    for(ix in 1:Klink){
                      x=xx+1
                      xx = xx + pop_vect[ix]
                      rho_[[rr]][x:xx]= rho[[rr]][ix]
                    }
                  }
                  start_position=start_position+(Klink*NC)
                }
                if(ER==2){

                  Boxr_s=get('Boxr_s', envir=test.env)





                  rho=list()
                  rho_=list()

                  t_r=get('t_r', envir=test.env)
                  for(rr in 1:NC){

                    if(t_r>Klink){
                      rho[[rr]]=rep(Boxr_s[1],Klink)
                    }else{
                      if(t_r>1){
                        rho[[rr]]=c(rep(Boxr_s[1],(t_r-1)),rep(Boxr_s[2],(Klink-t_r+1)))
                      }else{
                        rho[[rr]]=rep(Boxr_s[2],Klink)
                      }
                    }



                    rho[[rr]]= rho[[rr]]*sum(Boxr)
                    rho[[rr]]=rho[[rr]]-(Boxr[1])
                    rho[[rr]]=10^(rho[[rr]])
                    rho[[rr]]=rho[[rr]]*Rho[rr]

                    xx=0
                    rho_[[rr]]=vector()
                    for(ix in 1:Klink){
                      x=xx+1
                      xx = xx + pop_vect[ix]
                      rho_[[rr]][x:xx]= rho[[rr]][ix]
                    }
                  }
                  #  start_position=start_position+1
                }
                if(ER==3){

                  Boxr_s=get('Boxr_s', envir=test.env)
                  Boxr_1=get('Boxr_1', envir=test.env)
                  Boxr_2=get('Boxr_2', envir=test.env)
                  correct_R=get('correct_R', envir=test.env)
                  t_r=get('t_r', envir=test.env)

                  rho=list()
                  rho_=list()

                  for(rr in 1:NC){

                    if(t_r>Klink){
                      oldrho_param=rep(Boxr_s[1],Klink)
                      rho[[rr]]= oldrho_param[(1+((rr-1)*Klink)):(rr*Klink)]*sum(Boxr_1)
                      rho[[rr]]=rho[[rr]]-(Boxr_1[1])
                      rho[[rr]]=10^(rho[[rr]])
                      rho[[rr]]=rho[[rr]]*Rho[rr]
                    }else{
                      if(t_r>1){
                        oldrho_param=c(rep(Boxr_s[1],(t_r-1)),rep(Boxr_s[2],(Klink-t_r+1)))
                        rho[[rr]]=  c(( oldrho_param[(1+((rr-1)*Klink)):((t_r-1)+((rr-1)*Klink))]*sum(Boxr_1))  , ( oldrho_param[((t_r)+((rr-1)*Klink)):(rr*Klink)]*sum(Boxr_2)) )
                        rho[[rr]]=c(  rho[[rr]][1:(t_r-1)]-(Boxr_1[1]) ,  rho[[rr]][t_r:Klink]-(Boxr_2[1]) )
                        rho[[rr]]=10^(rho[[rr]])
                        rho[[rr]]=c(rho[[rr]][1:(t_r-1)]*Rho[rr],rho[[rr]][t_r:Klink]*Rho[rr]*correct_R)
                      }else{
                        oldrho_param=rep(Boxr_s[2],Klink)
                        rho[[rr]]= oldrho_param[(1+((rr-1)*Klink)):(rr*Klink)]*sum(Boxr_2)
                        rho[[rr]]=rho[[rr]]-(Boxr_2[1])
                        rho[[rr]]=10^(rho[[rr]])
                        rho[[rr]]=rho[[rr]]*Rho[rr]
                      }
                    }




                    xx=0
                    rho_[[rr]]=vector()
                    for(ix in 1:Klink){
                      x=xx+1
                      xx = xx + pop_vect[ix]
                      rho_[[rr]][x:xx]= rho[[rr]][ix]
                    }
                  }
                }
                if(ER==0){
                  rho_=list()
                  for(rr in 1:NC){
                    rho_[[rr]]=rep(Rho[rr],n)
                  }
                }
                if(SF==1){
                  sigma_=numeric(n)
                  sigma=param[(start_position+1):(start_position+(Klink))]
                  start_position=start_position+(Klink)
                  sigma=sigma*(Boxs[2]-Boxs[1])
                  sigma=sigma+Boxs[1]
                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    sigma_[x:xx]=sigma[ix]
                  }

                }



                if(SF==2){
                  Boxs_s=get('Boxs_s', envir=test.env)
                  sigma_=numeric(n)

                  t_s=get('t_s', envir=test.env)
                  if(t_s>Klink){
                    sigma=rep(Boxs_s[1],Klink)
                  }else{
                    if(t_s>1){
                      sigma=c(rep(Boxs_s[1],(t_s-1)),rep(Boxs_s[2],(Klink-t_s+1)))
                    }else{
                      sigma=rep(Boxs_s[2],Klink)
                    }
                  }
                  # start_position=start_position+1
                  sigma=sigma*(Boxs[2]-Boxs[1])
                  sigma=sigma+Boxs[1]
                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    sigma_[x:xx]=sigma[ix]
                  }
                }
                if(SF==3){
                  Boxs_s=param[(start_position+1):(start_position+2)]
                  start_position=start_position+2
                  Boxs_1=get('Boxs_1', envir=test.env)
                  Boxs_2=get('Boxs_2', envir=test.env)
                  sigma_=numeric(n)
                  t_s=get('t_s', envir=test.env)

                  if(t_s>Klink){
                    sigma=rep(Boxs_s[1],Klink)
                    sigma=sigma*(Boxs_1[2]-Boxs_1[1])
                    sigma=sigma+Boxs_1[1]
                  }else{
                    if(t_s>1){
                      sigma=c(rep(Boxs_s[1],(t_s-1)),rep(Boxs_s[2],(Klink-t_s+1)))
                      sigma= c(sigma[1:(t_s-1)]*(Boxs_1[2]-Boxs_1[1]),sigma[t_s:Klink]*(Boxs_2[2]-Boxs_2[1]) )
                      sigma= c(sigma[1:(t_s-1)]+Boxs_1[1],sigma[t_s:Klink]+Boxs_2[1])
                    }else{
                      sigma=rep(Boxs_s[2],Klink)
                      sigma=sigma*(Boxs_2[2]-Boxs_2[1])
                      sigma=sigma+Boxs_2[1]
                    }
                  }
                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    sigma_[x:xx]=sigma[ix]
                  }
                }
                if(SF==0){
                  sigma_=rep(sigma,n)
                }
                if(SB==1){
                  beta_=numeric(n)
                  beta=((param[(start_position+1):(start_position+(Klink))]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
                  start_position=start_position+(Klink)
                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    beta_[x:xx]=beta[ix]

                  }
                }
                if(SB==2){
                  beta_=numeric(n)
                  BoxB_s=get('BoxB_s', envir=test.env)

                  t_b=get('t_b', envir=test.env)
                  if(t_b>Klink){
                    beta=rep(BoxB_s[1],Klink)
                  }else{
                    if(t_b>1){
                      beta=c(rep(BoxB_s[1],(t_b-1)),rep(BoxB_s[2],(Klink-t_b+1)))
                    }else{
                      beta=rep(BoxB_s[2],Klink)
                    }
                  }

                  beta=((beta*(BoxB[2]-BoxB[1]))+BoxB[1])^2
                  #   start_position=start_position+1
                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    beta_[x:xx]=beta[ix]

                  }
                }
                if(SB==3){
                  beta_=numeric(n)
                  BoxB_s=param[(start_position+1):(start_position+2)]
                  start_position=start_position+2
                  BoxB_1=get('BoxB_1', envir=test.env)
                  BoxB_2=get('BoxB_2', envir=test.env)
                  t_b=get('t_b', envir=test.env)
                  if(t_b>Klink){
                    beta=rep(BoxB_s[1],Klink)
                    beta=((beta*(BoxB_1[2]-BoxB_1[1]))+BoxB_1[1])^2
                  }else{
                    if(t_b>1){
                      beta=c(rep(BoxB_s[1],(t_b-1)),rep(BoxB_s[2],(Klink-t_b+1)))
                      beta=c((((beta[1:(t_b-1)]*(BoxB_1[2]-BoxB_1[1]))+BoxB_1[1])^2),(((beta[t_b:Klink]*(BoxB_2[2]-BoxB_2[1]))+BoxB_2[1])^2))
                    }else{
                      beta=rep(BoxB_s[2],Klink)
                      beta=((beta*(BoxB_2[2]-BoxB_2[1]))+BoxB_2[1])^2
                    }
                  }


                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    beta_[x:xx]=beta[ix]

                  }
                }
                if(SB==0){
                  beta_=rep(beta,n)
                }

                if(!Pop){
                  Xi=numeric(n)
                  Xi_=param[(start_position+1):(start_position+Klink)]
                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    Xi[x:xx]=Xi_[ix]
                  }
                  Xi=Xi*sum(BoxP)
                  Xi=Xi-(BoxP[1])
                  Xi=10^Xi
                }else{
                  Xi=rep(1,n)
                }




                LH=0


                for(chr in 1:NC){

                  builder=build_HMM_matrix_t(n,(rho_[[chr]]),beta=beta_,Pop = Pop,Xi=Xi,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma_,Sigma = Self,Big_Window=Big_Window,npair=npair)
                  Q=builder[[1]]
                  Q=t(Q)
                  A=as.vector(Q)
                  keep=which(as.vector(Big_Xi[[chr]])>0)
                  A=A[keep]
                  Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                  Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                  Tc=builder[[3]]
                  g=build_emission_matrix(mu[chr],mu_b,Tc=builder[[4]],t=builder[[3]],beta,FS)
                  x=as.vector(g)
                  keep=which(x>0)
                  x=x[keep]
                  m=as.vector(Big_M[[chr]])
                  m=m[keep]
                  q_=get('q_', envir=test.env)
                  nu=builder[[2]]
                  if(BW){

                    LH=LH-sum(log(A)*Big_Xi[[chr]])-sum(log(x)*m)-sum(log(nu)*q_[[chr]])
                  }
                  if(!BW){

                    LH=LH-sum(log(A)*Big_Xi[[chr]])
                  }


                  if(!is.na(matrix_param)){
                    Q_copy=Q
                    for(nb_matrix in 1:length(matrix_param)){
                      #Q_star=sapply(1:matrix_param[[nb_matrix]][2], function(x){Q%^%x})

                      Q_s=diag(1,n)
                      if(!is.na(hs_vect)){

                        for(iii in 1:length(hs_vect) ){
                          Q_copy[,min(hs_vect[[iii]])]=rowSums(Q_copy[,hs_vect[[iii]]])
                          rm_v=c(sort(hs_vect[[iii]])[-1])
                          Q_copy=Q_copy[,-rm_v]
                          #browser()
                          Q_copy[min(hs_vect[[iii]]),]=colSums(diag(nu[hs_vect[[iii]]]/sum(nu[hs_vect[[iii]]]))%*%Q_copy[hs_vect[[iii]],])#/length(hs_vect[[iii]])
                          Q_copy=Q_copy[-rm_v,]
                        }
                      }

                      Q_s=diag(1,dim(Q_copy)[1])
                      #print(dim(Q_copy))
                      Q_star=matrix(0,dim(Q_s)[1],dim(Q_s)[1])
                      for(xx in 1:matrix_param[[nb_matrix]][2]){
                        Q_s=Q_s%*%Q_copy
                        Q_star=Q_star+Q_s
                      }


                      a_temp=sum(abs(as.numeric(X_star[[chr]][[nb_matrix]])-as.numeric(Q_star)))
                      scale=matrix_param[[nb_matrix]][1]*LH/a_temp
                      a=a+abs(a_temp*scale)

                    }

                  }



                  LH=LH+a


                }

                return(LH)
              }


              param=c()
              if(ER==1){
                for(rr in 1:NC){
                  param=c(param,oldrho[[rr]])
                }
              }
              if(ER==3){
                param=c(param,Boxr_s)

              }
              if(SF==1){
                param=c(param,oldsigma)
              }
              if(SF==3){
                param=c(param,Boxs_s)
              }
              if(SB==1){
                param=c(param,oldbeta)
              }
              if(SB==3){
                param=c(param,BoxB_s)
              }

              if(!Popfix){
                param=c(param,oldXi_)
              }


              if(length(param)>0){

                sol= BB::BBoptim(param,function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=10+length(param),M=c(20)))
                sol=as.matrix(sol[[1]])
                start_position=0
                sol=as.numeric(sol[1:length(param),1])
              if(ER==1){
                rho=sol[(start_position+1):(start_position+(Klink*NC))]
                start_position=start_position+(Klink*NC)
                if(ER==1){
                  for(rr in 1:NC){
                    oldrho[[rr]]=rho[(1+((1-rr)*Klink)):(rr*Klink)]
                  }
                }
              }
              if(ER==3){

                Boxr_s=sol[(start_position+1):(start_position+2)]
                test.env$Boxr_s <- Boxr_s
                start_position=start_position+2
                for(rr in 1:NC){
                  if(oldtr>Klink){
                    oldrho[[rr]]=rep(Boxr_s[1],(Klink))
                  }else{
                    if(oldtr>1){
                      oldrho[[rr]]=c(rep(Boxr_s[1],(oldtr-1)),rep(Boxr_s[2],(Klink+1-oldtr)))
                    }else{
                      oldrho[[rr]]=rep(Boxr_s[2],(Klink))
                    }
                  }
                }

              }
              if(SF==1){
                sigma_=sol[(start_position+1):(start_position+Klink)]
                start_position=start_position+Klink
                oldsigma=sigma_
              }
              if(SF==3){
                Boxs_s=sol[(start_position+1):(start_position+2)]
                test.env$Boxs_s <- Boxs_s
                start_position=start_position+2
                if(oldts>Klink){
                  oldsigma=rep(Boxs_s[1],(Klink))
                }else{
                  if(oldts>1){
                    oldsigma=c(rep(Boxs_s[1],(oldts-1)),rep(Boxs_s[2],(Klink+1-oldts)))
                  }else{
                    oldsigma=rep(Boxs_s[2],(Klink))
                  }
                }
              }
              if(SB==1){
                beta_=sol[(start_position+1):(start_position+Klink)]
                start_position=start_position+Klink
                oldbeta=beta_
              }
              if(SB==3){
                BoxB_s=sol[(start_position+1):(start_position+2)]
                test.env$BoxB_s <- BoxB_s
                start_position=start_position+2
                if(oldtb>Klink){
                  oldbeta=rep(BoxB_s[1],(Klink))
                }else{
                  if(oldtb>1){
                    oldbeta=c(rep(BoxB_s[1],(oldtb-1)),rep(BoxB_s[2],(Klink+1-oldtb)))
                  }else{
                    oldbeta=rep(BoxB_s[2],(Klink))
                  }
                }
              }

              if(!Popfix){
                Xi_=sol[(start_position+1):(start_position+Klink)]
                start_position=start_position+Klink
                oldXi_=Xi_
              }

              }






            }
    }






        if(diff_o>=0.003){
          diff=(max(diff_o,diff))
        }
        diff_conv=c(diff_conv,diff_o)
        end_time <- Sys.time()
        print(end_time-start_time)
      }

    }else{

      if(max(c(ER,SB,SF))<2){

      if(NC==1){



        test.env$ER <- ER
        test.env$SF <- SF
        test.env$SB <- SB
        test.env$Os <- Os



        function_to_minimize<-function(param){
          Boxr=get('Boxr', envir=test.env)
          mu=get('mu', envir=test.env)
          npair=get('npair', envir=test.env)
          Big_Window=get('Big_Window', envir=test.env)
          mu_b=get('mu_b', envir=test.env)
          FS=get('FS', envir=test.env)
          Klink=get('Klink', envir=test.env)
          Rho=get('Rho', envir=test.env)
          BoxB=get('BoxB', envir=test.env)
          Boxs=get('Boxs', envir=test.env)
          BoxP=get('BoxP', envir=test.env)
          pop_vect=get('pop_vect', envir=test.env)
          L=get('L', envir=test.env)
          n=get('k', envir=test.env)
          Beta=get('Beta', envir=test.env)
          Self=get('Self', envir=test.env)
          window_scaling=get('window_scaling', envir=test.env)
          Pop=get('Pop', envir=test.env)
          ER=get('ER', envir=test.env)
          SF=get('SF', envir=test.env)
          SB=get('SB', envir=test.env)
          Os=get('Os', envir=test.env)
          start_position=0
          if(ER==1){
            rho_=numeric(n)
            rho=param[(start_position+1):(start_position+Klink)]
            rho=rho*sum(Boxr)
            rho=rho-(Boxr[1])
            rho=10^(rho)
            rho=rho*Rho
            start_position=start_position+Klink
            xx=0
            for(ix in 1:Klink){
              x=xx+1
              xx = xx + pop_vect[ix]
              rho_[x:xx]=rho[ix]

            }

          }
          if(ER==2){

            Boxr_s=get('Boxr_s', envir=test.env)

            rho_=numeric(n)
            t_r=get('t_r', envir=test.env)

            if(t_r>Klink){
              rho=rep(Boxr_s[1],Klink)
            }else{
              if(t_r>1){
                rho=c(rep(Boxr_s[1],(t_r-1)),rep(Boxr_s[2],(Klink-t_r+1)))
              }else{
                rho=rep(Boxr_s[2],Klink)
              }
            }


            rho=rho*sum(Boxr)
            rho=rho-(Boxr[1])
            rho=10^(rho)
            rho=rho*Rho
            start_position=start_position+1
            xx=0
            for(ix in 1:Klink){
              x=xx+1
              xx = xx + pop_vect[ix]
              rho_[x:xx]=rho[ix]

            }
          }
          if(ER==0){
            rho_=rep(Rho,n)
          }
          if(SF==1){
            sigma_=numeric(n)
            sigma=param[(start_position+1):(start_position+Klink)]
            start_position=start_position+Klink
            sigma=sigma*(Boxs[2]-Boxs[1])
            sigma=sigma+Boxs[1]
            xx=0
            for(ix in 1:Klink){
              x=xx+1
              xx = xx + pop_vect[ix]
              sigma_[x:xx]=sigma[ix]
            }
          }
          if(SF==2){
            Boxs_s=get('Boxs_s', envir=test.env)
            sigma_=numeric(n)
            t_s=get('t_s', envir=test.env)
            if(t_s>1){
              sigma=c(rep(Boxs_s[1],(t_s-1)),rep(Boxs_s[2],(Klink-t_s+1)))
            }else{
              sigma=rep(Boxs_s[2],Klink)
            }
            start_position=start_position+1
            sigma=sigma*(Boxs[2]-Boxs[1])
            sigma=sigma+Boxs[1]
            xx=0
            for(ix in 1:Klink){
              x=xx+1
              xx = xx + pop_vect[ix]
              sigma_[x:xx]=sigma[ix]
            }
          }
          if(SF==0){
            sigma_=rep(sigma,n)
          }
          if(SB==1){
            beta_=numeric(n)
            beta=((param[(start_position+1):(start_position+Klink)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
            start_position=start_position+(Klink)
            xx=0
            for(ix in 1:Klink){
              x=xx+1
              xx = xx + pop_vect[ix]
              beta_[x:xx]=beta[ix]

            }
          }
          if(SB==2){
            beta_=numeric(n)
            BoxB_s=get('BoxB_s', envir=test.env)

            t_b=get('t_b', envir=test.env)
            if(t_b>1){
              beta=c(rep(BoxB_s[1],(t_b-1)),rep(BoxB_s[2],(Klink-t_b+1)))
            }else{
              beta=rep(BoxB_s[2],Klink)
            }

            beta=((beta*(BoxB[2]-BoxB[1]))+BoxB[1])^2
            start_position=start_position+1
            xx=0
            for(ix in 1:Klink){
              x=xx+1
              xx = xx + pop_vect[ix]
              beta_[x:xx]=beta[ix]

            }
          }
          if(SB==0){
            beta_=rep(beta,n)
          }
          if(!Pop){
            Xi=numeric(n)
            Xi_=param[(start_position+1):(start_position+Klink)]
            xx=0
            for(ix in 1:Klink){
              x=xx+1
              xx = xx + pop_vect[ix]
              Xi[x:xx]=Xi_[ix]
            }
            Xi=Xi*sum(BoxP)
            Xi=Xi-(BoxP[1])
            Xi=10^Xi
          }else{
            Xi=rep(1,n)
          }
          builder=build_HMM_matrix_t(n,rho_,beta=beta_,Pop = Pop,Xi=Xi,L=L,Beta=Beta,scale=window_scaling,sigma = sigma_,Sigma = Self,Big_Window=Big_Window,npair=npair)
          Q = builder[[1]]
          nu= builder[[2]]
          Tc=builder[[3]]
          g=build_emission_matrix(mu,mu_b,Tc=builder[[4]],t=builder[[3]],beta,FS)

          MLH=0
          test=Build_zip_Matrix_LH_mailund(Q,g,Os[[1]][[2]],nu)
          for(i in 1:length(Os)){
            fo=forward_zip_mailund(Os[[i]][[1]],g,nu,test[[1]])
            MLH=MLH-fo[[3]]
          }
          return(MLH)
        }



        param=c()
        if(ER==1){
          param=c(param,oldrho)

        }
        if(SF==1){
          param=c(param,oldsigma)
        }
        if(SB==1){
          param=c(param,oldbeta)
        }
        if(!Popfix){
          param=c(param,oldXi_)
        }

        sol= BB::BBoptim(param,function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=100+length(param),M=c(20)))
        LH=as.numeric(as.matrix(sol[[2]]))
        sol=as.matrix(sol[[1]])
        start_position=0


        sol=as.numeric(sol[1:length(param),1])
        if(ER==1){
          rho=sol[(start_position+1):(start_position+Klink)]
          start_position=start_position+Klink
          oldrho=rho
        }
        if(SF==1){
          sigma_=sol[(start_position+1):(start_position+Klink)]
          start_position=start_position+Klink
          oldsigma=sigma_
        }
        if(SB==1){
          beta_=sol[(start_position+1):(start_position+Klink)]
          start_position=start_position+Klink
          oldbeta=beta_
        }
        if(!Popfix){
          Xi_=sol[(start_position+1):(start_position+Klink)]
          start_position=start_position+Klink
          oldXi_=Xi_
        }







      }


      if(NC>1){

        test.env$ER <- ER
        test.env$SF <- SF
        test.env$SB <- SB
        test.env$Os <- Os



        function_to_minimize<-function(param){
          Boxr=get('Boxr', envir=test.env)
          mu=get('mu', envir=test.env)
          npair=get('npair', envir=test.env)
          Big_Window=get('Big_Window', envir=test.env)
          mu_b=get('mu_b', envir=test.env)
          FS=get('FS', envir=test.env)
          Klink=get('Klink', envir=test.env)
          Rho=get('Rho', envir=test.env)
          BoxB=get('BoxB', envir=test.env)
          Boxs=get('Boxs', envir=test.env)
          BoxP=get('BoxP', envir=test.env)
          pop_vect=get('pop_vect', envir=test.env)
          L=get('L', envir=test.env)
          n=get('k', envir=test.env)
          Beta=get('Beta', envir=test.env)
          Self=get('Self', envir=test.env)
          window_scaling=get('window_scaling', envir=test.env)
          Pop=get('Pop', envir=test.env)
          ER=get('ER', envir=test.env)
          SF=get('SF', envir=test.env)
          SB=get('SB', envir=test.env)
          Os=get('Os', envir=test.env)
          NC=get('NC', envir=test.env)
          start_position=0
          if(ER==1){
            rho=list()
            rho_=list()
            oldrho_param=param[(start_position+1):(start_position+(Klink*NC))]
            for(rr in 1:NC){
              rho[[rr]]= oldrho_param[(1+((rr-1)*Klink)):(rr*Klink)]*sum(Boxr)
              rho[[rr]]=rho[[rr]]-(Boxr[1])
              rho[[rr]]=10^(rho[[rr]])
              rho[[rr]]=rho[[rr]]*Rho[rr]

              xx=0
              rho_[[rr]]=vector()
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                rho_[[rr]][x:xx]= rho[[rr]][ix]
              }
            }
            start_position=start_position+(Klink*NC)
          }
          if(ER==2){

            Boxr_s=get('Boxr_s', envir=test.env)





            rho=list()
            rho_=list()

            t_r=get('t_r', envir=test.env)
            for(rr in 1:NC){

              if(t_r>Klink){
                rho[[rr]]=rep(Boxr_s[1],Klink)
              }else{
                if(t_r>1){
                  rho[[rr]]=c(rep(Boxr_s[1],(t_r-1)),rep(Boxr_s[2],(Klink-t_r+1)))
                }else{
                  rho[[rr]]=rep(Boxr_s[2],Klink)
                }
              }



              rho[[rr]]= rho[[rr]]*sum(Boxr)
              rho[[rr]]=rho[[rr]]-(Boxr[1])
              rho[[rr]]=10^(rho[[rr]])
              rho[[rr]]=rho[[rr]]*Rho[rr]

              xx=0
              rho_[[rr]]=vector()
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                rho_[[rr]][x:xx]= rho[[rr]][ix]
              }
            }
            #  start_position=start_position+1
          }

          if(ER==0){
            rho_=list()
            for(rr in 1:NC){
              rho_[[rr]]=rep(Rho[rr],n)
            }
          }
          if(SF==1){
            sigma_=numeric(n)
            sigma=param[(start_position+1):(start_position+Klink)]
            start_position=start_position+Klink
            sigma=sigma*(Boxs[2]-Boxs[1])
            sigma=sigma+Boxs[1]
            xx=0
            for(ix in 1:Klink){
              x=xx+1
              xx = xx + pop_vect[ix]
              sigma_[x:xx]=sigma[ix]
            }
          }
          if(SF==2){
            Boxs_s=get('Boxs_s', envir=test.env)
            sigma_=numeric(n)
            t_s=get('t_s', envir=test.env)
            if(t_s>1){
              sigma=c(rep(Boxs_s[1],(t_s-1)),rep(Boxs_s[2],(Klink-t_s+1)))
            }else{
              sigma=rep(Boxs_s[2],Klink)
            }
            start_position=start_position+1
            sigma=sigma*(Boxs[2]-Boxs[1])
            sigma=sigma+Boxs[1]
            xx=0
            for(ix in 1:Klink){
              x=xx+1
              xx = xx + pop_vect[ix]
              sigma_[x:xx]=sigma[ix]
            }
          }
          if(SF==0){
            sigma_=rep(sigma,n)
          }
          if(SB==1){
            beta_=numeric(n)
            beta=((param[(start_position+1):(start_position+Klink)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
            start_position=start_position+(Klink)
            xx=0
            for(ix in 1:Klink){
              x=xx+1
              xx = xx + pop_vect[ix]
              beta_[x:xx]=beta[ix]

            }
          }
          if(SB==2){
            beta_=numeric(n)
            BoxB_s=get('BoxB_s', envir=test.env)
            t_b=get('t_b', envir=test.env)
            if(t_b>1){
              beta=c(rep(BoxB_s[1],(t_b-1)),rep(BoxB_s[2],(Klink-t_b+1)))
            }else{
              beta=rep(BoxB_s[2],Klink)
            }

            beta=((beta*(BoxB[2]-BoxB[1]))+BoxB[1])^2
            start_position=start_position+1
            xx=0
            for(ix in 1:Klink){
              x=xx+1
              xx = xx + pop_vect[ix]
              beta_[x:xx]=beta[ix]

            }
          }
          if(SB==0){
            beta_=rep(beta,n)
          }
          if(!Pop){
            Xi=numeric(n)
            Xi_=param[(start_position+1):(start_position+Klink)]
            xx=0
            for(ix in 1:Klink){
              x=xx+1
              xx = xx + pop_vect[ix]
              Xi[x:xx]=Xi_[ix]
            }
            Xi=Xi*sum(BoxP)
            Xi=Xi-(BoxP[1])
            Xi=10^Xi
          }else{
            Xi=rep(1,n)
          }
          MLH=0
          for(chr in 1:NC){

          builder=build_HMM_matrix_t(n,(rho_[[chr]]),beta=beta_,Pop = Pop,Xi=Xi,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma_,Sigma = Self,Big_Window=Big_Window,npair=npair)
          Q = builder[[1]]
          nu= builder[[2]]
          Tc=builder[[3]]
          g=build_emission_matrix(mu[chr],mu_b,Tc=builder[[4]],t=builder[[3]],beta,FS)


          test=Build_zip_Matrix_LH_mailund(Q,g,Os[[chr]][[1]][[2]],nu)
          for(i in 1:length(Os[[chr]])){
            fo=forward_zip_mailund(Os[[chr]][[i]][[1]],g,nu,test[[1]])
            MLH=MLH-fo[[3]]
          }
          }
          return(MLH)
        }



        param=c()
        if(ER==1){
          for(rr in 1:NC){
            param=c(param,oldrho[[rr]])
          }
        }
        if(SF==1){
          param=c(param,oldsigma)
        }
        if(SB==1){
          param=c(param,oldbeta)
        }
        if(!Popfix){
          param=c(param,oldXi_)
        }

        sol= BB::BBoptim(param,function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=length(param),M=c(20)))
        LH=as.numeric(as.matrix(sol[[2]]))
        sol=as.matrix(sol[[1]])
        start_position=0


        sol=as.numeric(sol[1:length(param),1])
        if(ER==1){
          rho=sol[(start_position+1):(start_position+Klink)]
          start_position=start_position+Klink
          if(ER==1){
            for(rr in 1:NC){
              oldrho[[rr]]=rho[(1+((1-rr)*Klink)):(rr*Klink)]
            }
          }
        }
        if(SF==1){
          sigma_=sol[(start_position+1):(start_position+Klink)]
          start_position=start_position+Klink
          oldsigma=sigma_
        }
        if(SB==1){
          beta_=sol[(start_position+1):(start_position+Klink)]
          start_position=start_position+Klink
          oldbeta=beta_
        }
        if(!Popfix){
          Xi_=sol[(start_position+1):(start_position+Klink)]
          start_position=start_position+Klink
          oldXi_=Xi_
        }







      }
      }else{
        stop("Not finished yet.")
        if(Popfix){
          if(!is.list(oldrho)){
            rho_=oldrho*sum(Boxr)
            rho_=rho_-(Boxr[1])
            rho_=10^(rho_)
            rho_=rho_*Rho
            rho=vector()
            xx=0
            for(ix in 1:Klink){
              x=xx+1
              xx = xx + pop_vect[ix]
              rho[x:xx]= rho_[ix]
            }
          }else{
            rho_=list()
            rho=list()
            for(rr in 1:NC){
              rho_[[rr]]=oldrho[[rr]]*sum(Boxr)
              rho_[[rr]]=rho_[[rr]]-(Boxr[1])
              rho_[[rr]]=10^(rho_[[rr]])
              rho_[[rr]]=rho_[[rr]]*Rho[rr]

              xx=0
              rho[[rr]]=vector()
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                rho[[rr]][x:xx]= rho_[[rr]][ix]
              }
            }

          }

          if(SB>0){
            beta_=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1] )^2
            beta=vector()
            xx=0
            for(ix in 1:Klink){
              x=xx+1
              xx = xx + pop_vect[ix]
              beta[x:xx]=beta_[ix]
            }
          }
          if(SF>0){
            sigma_=oldsigma*(Boxs[2]-Boxs[1])
            sigma_=sigma_+Boxs[1]
            sigma=vector()
            xx=0
            for(ix in 1:Klink){
              x=xx+1
              xx = xx + pop_vect[ix]
              sigma[x:xx]= sigma_[ix]
            }
          }
          print(c("sigma:",sigma,"beta :",beta))
          if(is.list(rho_)){
            print(c("rho/theta:",rho_[[1]]/theta))
          }else{
            print(c("rho/theta:",rho_/theta))
          }
          Keep_going=F
          if(it==1){
            diff_o=0
          }
          if(it>1){
            if(SF==1){
              diff_o=mean(abs(sigma_o-sigma))
            }
            if(SF==2){
              diff_o=0.0001
            }
            if(SB==1){
              diff_o=max(diff_o,mean(abs(beta_o-beta)))
            }
            if(SB==2){
              diff_o=max(diff_o,0.0001)
            }
            count_diff_o=0
            if(diff_o>=0.005){
              if(it==maxIt){
                count_diff_o=count_diff_o+1
                maxIt=maxIt+1
                if(count_diff_o>10){
                  maxBit=maxBit-1
                }
              }
            }
          }
          sigma_o=sigma
          beta_o=beta



          if(NC==1){
            builder=build_HMM_matrix_t(k,(rho),beta=beta,L=L,Pop=Pop,Xi=NA,Beta=Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
          }
          if(NC>1){
            builder=list()
            for(chr in 1:NC){
              builder[[chr]]=build_HMM_matrix_t(k,(rho[[chr]]),beta=beta,L=L[chr],Pop=Pop,Xi=NA,Beta=Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
            }
          }
        }
        if(!Popfix){
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            oldXi[x:xx]=oldXi_[ix]
          }
          Xi_=oldXi*sum(BoxP)
          Xi_=Xi_-(BoxP[1])
          Xi_=10^Xi_
          if(!is.list(oldrho)){
            rho_=oldrho*sum(Boxr)
            rho_=rho_-(Boxr[1])
            rho_=10^(rho_)
            rho_=rho_*Rho
            rho=vector()
            xx=0
            for(ix in 1:Klink){
              x=xx+1
              xx = xx + pop_vect[ix]
              rho[x:xx]= rho_[ix]
            }
          }else{
            rho_=list()
            rho=list()
            for(rr in 1:NC){
              rho_[[rr]]=oldrho[[rr]]*sum(Boxr)
              rho_[[rr]]=rho_[[rr]]-(Boxr[1])
              rho_[[rr]]=10^(rho_[[rr]])
              rho_[[rr]]=rho_[[rr]]*Rho[rr]
              rho[[rr]]=vector()
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                rho[[rr]][x:xx]= rho_[[rr]][ix]
              }
            }

          }
          if(SB>0){
            beta_=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1] )^2
            beta=vector()
            xx=0
            for(ix in 1:Klink){
              x=xx+1
              xx = xx + pop_vect[ix]
              beta[x:xx]=beta_[ix]
            }
          }
          if(SF>0){
            sigma_=oldsigma*(Boxs[2]-Boxs[1])
            sigma_=sigma_+Boxs[1]
            sigma=vector()
            xx=0
            for(ix in 1:Klink){
              x=xx+1
              xx = xx + pop_vect[ix]
              sigma[x:xx]= sigma_[ix]
            }
          }
          print(c("sigma:",sigma,"beta :",beta))
          Keep_going=F
          if(it==1){
            diff_o=0
          }
          if(it>1){
            if(SF==1){
              diff_o=mean(abs(sigma_o-sigma))
            }
            if(SF==2){
              diff_o=0.0001
            }
            if(SB==1){
              diff_o=max(diff_o,mean(abs(beta_o-beta)))
            }
            if(SB==2){
              diff_o=max(diff_o,0.0001)
            }
            count_diff_o=0
            if(diff_o>=0.005){
              if(it==maxIt){
                count_diff_o=count_diff_o+1
                maxIt=maxIt+1
                if(count_diff_o>10){
                  maxBit=maxBit-1
                }
              }
            }
          }
          sigma_o=sigma
          beta_o=beta
          # browser()
          if(NC==1){
            builder=build_HMM_matrix_t(k,(rho),beta=beta,L=L,Pop=Pop,Xi_,Beta=Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
          }
          if(NC>1){
            builder=list()
            for(chr in 1:NC){
              builder[[chr]]=build_HMM_matrix_t(k,(rho[[chr]]),beta=beta,L=L[chr],Pop=Pop,Xi_,Beta=Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
            }
          }
        }

        if(NC==1){

          test.env$ER <- ER
          test.env$SF <- SF
          test.env$SB <- SB
          test.env$Os <- Os



          function_to_minimize<-function(param){
            Boxr=get('Boxr', envir=test.env)
            mu=get('mu', envir=test.env)
            npair=get('npair', envir=test.env)
            Big_Window=get('Big_Window', envir=test.env)
            mu_b=get('mu_b', envir=test.env)
            FS=get('FS', envir=test.env)
            Klink=get('Klink', envir=test.env)
            Rho=get('Rho', envir=test.env)
            BoxB=get('BoxB', envir=test.env)
            Boxs=get('Boxs', envir=test.env)
            BoxP=get('BoxP', envir=test.env)
            pop_vect=get('pop_vect', envir=test.env)
            L=get('L', envir=test.env)
            n=get('k', envir=test.env)
            Beta=get('Beta', envir=test.env)
            Self=get('Self', envir=test.env)
            window_scaling=get('window_scaling', envir=test.env)
            Pop=get('Pop', envir=test.env)
            ER=get('ER', envir=test.env)
            SF=get('SF', envir=test.env)
            SB=get('SB', envir=test.env)
            Os=get('Os', envir=test.env)
            start_position=0
            if(ER==1){
              rho_=numeric(n)
              rho=param[(start_position+1):(start_position+Klink)]
              rho=rho*sum(Boxr)
              rho=rho-(Boxr[1])
              rho=10^(rho)
              rho=rho*Rho
              start_position=start_position+Klink
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                rho_[x:xx]=rho[ix]

              }

            }
            if(ER==2){

              Boxr_s=get('Boxr_s', envir=test.env)

              rho_=numeric(n)
              #t_r=min(ceiling(param[(start_position+1)]*Klink),Klink)
              t_r=get('t_r', envir=test.env)

              if(t_r>Klink){
                rho=rep(Boxr_s[1],Klink)
              }else{
                if(t_r>1){
                  rho=c(rep(Boxr_s[1],(t_r-1)),rep(Boxr_s[2],(Klink-t_r+1)))
                }else{
                  rho=rep(Boxr_s[2],Klink)
                }
              }


              rho=rho*sum(Boxr)
              rho=rho-(Boxr[1])
              rho=10^(rho)
              rho=rho*Rho
              #start_position=start_position+1
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                rho_[x:xx]=rho[ix]

              }
            }
            if(ER==0){
              rho_=rep(Rho,n)
            }
            if(SF==1){
              sigma_=numeric(n)
              sigma=param[(start_position+1):(start_position+Klink)]
              start_position=start_position+Klink
              sigma=sigma*(Boxs[2]-Boxs[1])
              sigma=sigma+Boxs[1]
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                sigma_[x:xx]=sigma[ix]
              }
            }
            if(SF==2){
              Boxs_s=get('Boxs_s', envir=test.env)
              sigma_=numeric(n)

              #t_s=min(ceiling(param[(start_position+1)]*Klink),Klink)
              t_s=get('t_s', envir=test.env)
              if(t_s>Klink){
                sigma=rep(Boxs_s[1],Klink)
              }else{
                if(t_s>1){
                  sigma=c(rep(Boxs_s[1],(t_s-1)),rep(Boxs_s[2],(Klink-t_s+1)))
                }else{
                  sigma=rep(Boxs_s[2],Klink)
                }
              }
              #start_position=start_position+1
              sigma=sigma*(Boxs[2]-Boxs[1])
              sigma=sigma+Boxs[1]
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                sigma_[x:xx]=sigma[ix]
              }

            }
            if(SF==0){
              sigma_=rep(sigma,n)
            }
            if(SB==1){
              beta_=numeric(n)
              beta=((param[(start_position+1):(start_position+Klink)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
              start_position=start_position+(Klink)
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                beta_[x:xx]=beta[ix]

              }
            }
            if(SB==2){
              beta_=numeric(n)
              BoxB_s=get('BoxB_s', envir=test.env)
              #t_b=min(ceiling(param[(start_position+1)]*Klink),Klink)
              t_b=get('t_b', envir=test.env)
              if(t_b>Klink){
                beta=rep(BoxB_s[1],Klink)
              }else{
                if(t_b>1){
                  beta=c(rep(BoxB_s[1],(t_b-1)),rep(BoxB_s[2],(Klink-t_b+1)))
                }else{
                  beta=rep(BoxB_s[2],Klink)
                }
              }

              beta=((beta*(BoxB[2]-BoxB[1]))+BoxB[1])^2
              # start_position=start_position+1
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                beta_[x:xx]=beta[ix]

              }
            }
            if(SB==0){
              beta_=rep(beta,n)
            }
            if(!Pop){
              Xi=numeric(n)
              Xi_=param[(start_position+1):(start_position+Klink)]
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                Xi[x:xx]=Xi_[ix]
              }
              Xi=Xi*sum(BoxP)
              Xi=Xi-(BoxP[1])
              Xi=10^Xi
            }else{
              Xi=rep(1,n)
            }
            builder=build_HMM_matrix_t(n,rho_,beta=beta_,Pop = Pop,Xi=Xi,L=L,Beta=Beta,scale=window_scaling,sigma = sigma_,Sigma = Self,Big_Window=Big_Window,npair=npair)
            Q = builder[[1]]
            nu= builder[[2]]
            Tc=builder[[3]]
            g=build_emission_matrix(mu,mu_b,Tc=builder[[4]],t=builder[[3]],beta,FS)
            MLH=0
            test=Build_zip_Matrix_mailund(Q,g,Os[[1]][[2]],nu,do_all=F)
            for(i in 1:length(Os)){
              fo=forward_zip_mailund(Os[[i]][[1]],g,nu,test[[1]])
              MLH=MLH-fo[[3]]
            }
            return(MLH)
          }

          param=c()
          if(ER==1){
            param=c(param,oldrho)

          }

          if(SF==1){
            param=c(param,oldsigma)
          }

          if(SB==1){
            param=c(param,oldbeta)
          }

          if(!Popfix){
            param=c(param,oldXi_)
          }

          LH_temp=0




            if(ER==2){
              for(t_r in 1:(1+Klink)){
                test.env$t_r <- t_r
                if(SB==2){
                  for( t_b in 1:(1+Klink)){
                    test.env$t_b <- t_b
                    if(SF==2){

                      for(t_s in 1:(1+Klink)){
                        test.env$t_s <- t_s

                        sol_temp=function_to_minimize(param)
                        if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                          LH_temp=as.numeric(sol_temp)
                          oldtr=t_r
                          oldtb=t_b
                          oldts=t_s

                        }

                      }

                    }else{
                      sol_temp=function_to_minimize(param)
                      if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                        LH_temp=as.numeric(sol_temp)
                        oldtr=t_r
                        oldtb=t_b

                      }
                    }
                  }

                }else{ # NO  SB
                  if(SF==2){
                    for(t_s in 1:(1+Klink)){
                      test.env$t_s <- t_s
                      sol_temp=function_to_minimize(param)
                      if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                        LH_temp=as.numeric(sol_temp)
                        oldtr=t_r
                        oldts=t_s

                      }
                    }
                  }else{
                    sol_temp=function_to_minimize(param)
                    if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                      LH_temp=as.numeric(sol_temp)
                      oldtr=t_r

                    }
                  }
                }
              }
            }else{ # No ER
              if(SB==2){
                for( t_b in 1:(1+Klink)){
                  test.env$t_b <- t_b
                  if(SF==2){

                    for(t_s in 1:(1+Klink)){
                      test.env$t_s <- t_s
                      sol_temp=function_to_minimize(param)
                      if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                        LH_temp=as.numeric(sol_temp)
                        oldtb=t_b
                        oldts=t_s

                      }
                    }
                  }else{
                    sol_temp=function_to_minimize(param)
                    if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                      LH_temp=as.numeric(sol_temp)
                      oldtb=t_b

                    }
                  }
                }
              }else{
                if(SF==2){

                  for(t_s in 1:(1+Klink)){
                    test.env$t_s <- t_s
                    sol_temp=function_to_minimize(param)
                    print(sol_temp)
                    if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                      LH_temp=as.numeric(sol_temp)
                      oldts=t_s


                    }
                  }
                }else{

                  stop("How did you get here ?")

                }
              }
            }


          if(ER==2){
            test.env$t_r <- oldtr

            if(oldtr>Klink){
              oldrho=rep(Boxr_s[1],(Klink))
            }else{
              if(oldtr>1){
                oldrho=c(rep(Boxr_s[1],(oldtr-1)),rep(Boxr_s[2],(Klink+1-oldtr)))
              }else{
                oldrho=rep(Boxr_s[2],(Klink))
              }
            }



          }


          if(SF==2){

            test.env$t_s <- oldts

            if(oldts>Klink){
              oldsigma=rep(Boxs_s[1],(Klink))
            }else{
              if(oldts>1){
                oldsigma=c(rep(Boxs_s[1],(oldts-1)),rep(Boxs_s[2],(Klink+1-oldts)))
              }else{
                oldsigma=rep(Boxs_s[2],(Klink))
              }
            }


          }



          if(SB==2){

            test.env$t_b <- oldtb
            if(oldtb>Klink){
              oldbeta=rep(BoxB_s[1],(Klink))
            }else{
              if(oldtb>1){
                oldbeta=c(rep(BoxB_s[1],(oldtb-1)),rep(BoxB_s[2],(Klink+1-oldtb)))
              }else{
                oldbeta=rep(BoxB_s[2],(Klink))
              }
            }


          }

          if(Popfix){
            if(!is.list(oldrho)){
              rho_=oldrho*sum(Boxr)
              rho_=rho_-(Boxr[1])
              rho_=10^(rho_)
              rho_=rho_*Rho
              rho=vector()
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                rho[x:xx]= rho_[ix]
              }
            }else{
              rho_=list()
              rho=list()
              for(rr in 1:NC){
                rho_[[rr]]=oldrho[[rr]]*sum(Boxr)
                rho_[[rr]]=rho_[[rr]]-(Boxr[1])
                rho_[[rr]]=10^(rho_[[rr]])
                rho_[[rr]]=rho_[[rr]]*Rho[rr]

                xx=0
                rho[[rr]]=vector()
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  rho[[rr]][x:xx]= rho_[[rr]][ix]
                }
              }

            }

            if(SB>0){
              beta_=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1] )^2
              beta=vector()
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                beta[x:xx]=beta_[ix]
              }
            }
            if(SF>0){
              sigma_=oldsigma*(Boxs[2]-Boxs[1])
              sigma_=sigma_+Boxs[1]
              sigma=vector()
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                sigma[x:xx]= sigma_[ix]
              }
            }
            print(c("sigma:",sigma,"beta :",beta))
            if(is.list(rho_)){
              print(c("rho/theta:",rho_[[1]]/theta))
            }else{
              print(c("rho/theta:",rho_/theta))
            }
            Keep_going=F
            if(it==1){
              diff_o=0
            }
            if(it>1){
              if(SF==1){
                diff_o=mean(abs(sigma_o-sigma))
              }
              if(SF==2){
                diff_o=0.0001
              }
              if(SB==1){
                diff_o=max(diff_o,mean(abs(beta_o-beta)))
              }
              if(SB==2){
                diff_o=max(diff_o,0.0001)
              }
              count_diff_o=0
              if(diff_o>=0.005){
                if(it==maxIt){
                  count_diff_o=count_diff_o+1
                  maxIt=maxIt+1
                  if(count_diff_o>10){
                    maxBit=maxBit-1
                  }
                }
              }
            }
            sigma_o=sigma
            beta_o=beta



            if(NC==1){
              builder=build_HMM_matrix_t(k,(rho),beta=beta,L=L,Pop=Pop,Xi=NA,Beta=Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
            }
            if(NC>1){
              builder=list()
              for(chr in 1:NC){
                builder[[chr]]=build_HMM_matrix_t(k,(rho[[chr]]),beta=beta,L=L[chr],Pop=Pop,Xi=NA,Beta=Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
              }
            }
          }
          if(!Popfix){
            xx=0
            for(ix in 1:Klink){
              x=xx+1
              xx = xx + pop_vect[ix]
              oldXi[x:xx]=oldXi_[ix]
            }
            Xi_=oldXi*sum(BoxP)
            Xi_=Xi_-(BoxP[1])
            Xi_=10^Xi_
            if(!is.list(oldrho)){
              rho_=oldrho*sum(Boxr)
              rho_=rho_-(Boxr[1])
              rho_=10^(rho_)
              rho_=rho_*Rho
              rho=vector()
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                rho[x:xx]= rho_[ix]
              }
            }else{
              rho_=list()
              rho=list()
              for(rr in 1:NC){
                rho_[[rr]]=oldrho[[rr]]*sum(Boxr)
                rho_[[rr]]=rho_[[rr]]-(Boxr[1])
                rho_[[rr]]=10^(rho_[[rr]])
                rho_[[rr]]=rho_[[rr]]*Rho[rr]
                rho[[rr]]=vector()
                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  rho[[rr]][x:xx]= rho_[[rr]][ix]
                }
              }

            }
            if(SB>0){
              beta_=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1] )^2
              beta=vector()
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                beta[x:xx]=beta_[ix]
              }
            }
            if(SF>0){
              sigma_=oldsigma*(Boxs[2]-Boxs[1])
              sigma_=sigma_+Boxs[1]
              sigma=vector()
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                sigma[x:xx]= sigma_[ix]
              }
            }
            print(c("sigma:",sigma,"beta :",beta))
            Keep_going=F
            if(it==1){
              diff_o=0
            }
            if(it>1){
              if(SF==1){
                diff_o=mean(abs(sigma_o-sigma))
              }
              if(SF==2){
                diff_o=0.0001
              }
              if(SB==1){
                diff_o=max(diff_o,mean(abs(beta_o-beta)))
              }
              if(SB==2){
                diff_o=max(diff_o,0.0001)
              }
              count_diff_o=0
              if(diff_o>=0.005){
                if(it==maxIt){
                  count_diff_o=count_diff_o+1
                  maxIt=maxIt+1
                  if(count_diff_o>10){
                    maxBit=maxBit-1
                  }
                }
              }
            }
            sigma_o=sigma
            beta_o=beta
            #
            if(NC==1){
              builder=build_HMM_matrix_t(k,(rho),beta=beta,L=L,Pop=Pop,Xi_,Beta=Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
            }
            if(NC>1){
              builder=list()
              for(chr in 1:NC){
                builder[[chr]]=build_HMM_matrix_t(k,(rho[[chr]]),beta=beta,L=L[chr],Pop=Pop,Xi_,Beta=Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
              }
            }
          }





            test.env$ER <- ER
            test.env$SF <- SF
            test.env$SB <- SB
            test.env$Os <- Os



            function_to_minimize<-function(param){
              Boxr=get('Boxr', envir=test.env)
              mu=get('mu', envir=test.env)
              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)
              mu_b=get('mu_b', envir=test.env)
              FS=get('FS', envir=test.env)
              Klink=get('Klink', envir=test.env)
              Rho=get('Rho', envir=test.env)
              BoxB=get('BoxB', envir=test.env)
              Boxs=get('Boxs', envir=test.env)
              BoxP=get('BoxP', envir=test.env)
              pop_vect=get('pop_vect', envir=test.env)
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Beta=get('Beta', envir=test.env)
              Self=get('Self', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)
              Pop=get('Pop', envir=test.env)
              ER=get('ER', envir=test.env)
              SF=get('SF', envir=test.env)
              SB=get('SB', envir=test.env)
              Os=get('Os', envir=test.env)
              start_position=0
              if(ER==1){
                rho_=numeric(n)
                rho=param[(start_position+1):(start_position+Klink)]
                rho=rho*sum(Boxr)
                rho=rho-(Boxr[1])
                rho=10^(rho)
                rho=rho*Rho
                start_position=start_position+Klink
                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  rho_[x:xx]=rho[ix]

                }

              }
              if(ER==2){

                Boxr_s=get('Boxr_s', envir=test.env)

                rho_=numeric(n)
                t_r=get('t_r', envir=test.env)

                if(t_r>Klink){
                  rho=rep(Boxr_s[1],Klink)
                }else{
                  if(t_r>1){
                    rho=c(rep(Boxr_s[1],(t_r-1)),rep(Boxr_s[2],(Klink-t_r+1)))
                  }else{
                    rho=rep(Boxr_s[2],Klink)
                  }
                }


                rho=rho*sum(Boxr)
                rho=rho-(Boxr[1])
                rho=10^(rho)
                rho=rho*Rho
                start_position=start_position+1
                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  rho_[x:xx]=rho[ix]

                }
              }
              if(ER==0){
                rho_=rep(Rho,n)
              }
              if(SF==1){
                sigma_=numeric(n)
                sigma=param[(start_position+1):(start_position+Klink)]
                start_position=start_position+Klink
                sigma=sigma*(Boxs[2]-Boxs[1])
                sigma=sigma+Boxs[1]
                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  sigma_[x:xx]=sigma[ix]
                }
              }
              if(SF==2){
                Boxs_s=get('Boxs_s', envir=test.env)
                sigma_=numeric(n)

                t_s=get('t_s', envir=test.env)
                if(t_s>1){
                  sigma=c(rep(Boxs_s[1],(t_s-1)),rep(Boxs_s[2],(Klink-t_s+1)))
                }else{
                  sigma=rep(Boxs_s[2],Klink)
                }
                start_position=start_position+1
                sigma=sigma*(Boxs[2]-Boxs[1])
                sigma=sigma+Boxs[1]
                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  sigma_[x:xx]=sigma[ix]
                }
              }
              if(SF==0){
                sigma_=rep(sigma,n)
              }
              if(SB==1){
                beta_=numeric(n)
                beta=((param[(start_position+1):(start_position+Klink)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
                start_position=start_position+(Klink)
                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  beta_[x:xx]=beta[ix]

                }
              }
              if(SB==2){
                beta_=numeric(n)
                BoxB_s=get('BoxB_s', envir=test.env)
                t_b=get('t_b', envir=test.env)
                if(t_b>1){
                  beta=c(rep(BoxB_s[1],(t_b-1)),rep(BoxB_s[2],(Klink-t_b+1)))
                }else{
                  beta=rep(BoxB_s[2],Klink)
                }

                beta=((beta*(BoxB[2]-BoxB[1]))+BoxB[1])^2
                start_position=start_position+1
                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  beta_[x:xx]=beta[ix]

                }
              }
              if(SB==0){
                beta_=rep(beta,n)
              }
              if(!Pop){
                Xi=numeric(n)
                Xi_=param[(start_position+1):(start_position+Klink)]
                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  Xi[x:xx]=Xi_[ix]
                }
                Xi=Xi*sum(BoxP)
                Xi=Xi-(BoxP[1])
                Xi=10^Xi
              }else{
                Xi=rep(1,n)
              }
              builder=build_HMM_matrix_t(n,rho_,beta=beta_,Pop = Pop,Xi=Xi,L=L,Beta=Beta,scale=window_scaling,sigma = sigma_,Sigma = Self,Big_Window=Big_Window,npair=npair)
              Q = builder[[1]]
              nu= builder[[2]]
              Tc=builder[[3]]
              g=build_emission_matrix(mu,mu_b,Tc=builder[[4]],t=builder[[3]],beta,FS)

              MLH=0
              test=Build_zip_Matrix_mailund(Q,g,Os[[1]][[2]],nu,do_all=F)
              for(i in 1:length(Os)){
                fo=forward_zip_mailund(Os[[i]][[1]],g,nu,test[[1]])
                MLH=MLH-fo[[3]]
              }
              return(MLH)
            }



            param=c()
            if(ER==1){
              param=c(param,oldrho)

            }
            if(SF==1){
              param=c(param,oldsigma)
            }
            if(SB==1){
              param=c(param,oldbeta)
            }
            if(!Popfix){
              param=c(param,oldXi_)
            }

            sol= BB::BBoptim(param,function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=length(param),M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            start_position=0


            sol=as.numeric(sol[1:length(param),1])
            if(ER==1){
              rho=sol[(start_position+1):(start_position+Klink)]
              start_position=start_position+Klink
              oldrho=rho
            }
            if(SF==1){
              sigma_=sol[(start_position+1):(start_position+Klink)]
              start_position=start_position+Klink
              oldsigma=sigma_
            }
            if(SB==1){
              beta_=sol[(start_position+1):(start_position+Klink)]
              start_position=start_position+Klink
              oldbeta=beta_
            }
            if(!Popfix){
              Xi_=sol[(start_position+1):(start_position+Klink)]
              start_position=start_position+Klink
              oldXi_=Xi_
            }









        }

        if(NC>1){

          test.env$ER <- ER
          test.env$SF <- SF
          test.env$SB <- SB
          test.env$Os <- Os



          function_to_minimize<-function(param){
            Boxr=get('Boxr', envir=test.env)
            mu=get('mu', envir=test.env)
            npair=get('npair', envir=test.env)
            Big_Window=get('Big_Window', envir=test.env)
            mu_b=get('mu_b', envir=test.env)
            FS=get('FS', envir=test.env)
            Klink=get('Klink', envir=test.env)
            Rho=get('Rho', envir=test.env)
            BoxB=get('BoxB', envir=test.env)
            Boxs=get('Boxs', envir=test.env)
            BoxP=get('BoxP', envir=test.env)
            pop_vect=get('pop_vect', envir=test.env)
            L=get('L', envir=test.env)
            n=get('k', envir=test.env)
            Beta=get('Beta', envir=test.env)
            Self=get('Self', envir=test.env)
            window_scaling=get('window_scaling', envir=test.env)
            Pop=get('Pop', envir=test.env)
            ER=get('ER', envir=test.env)
            SF=get('SF', envir=test.env)
            SB=get('SB', envir=test.env)
            Os=get('Os', envir=test.env)
            NC=get('NC', envir=test.env)
            start_position=0
            if(ER==1){

              rho=list()
              rho_=list()
              oldrho_param=param[(start_position+1):(start_position+(Klink*NC))]
              for(rr in 1:NC){
                rho[[rr]]= oldrho_param[(1+((rr-1)*Klink)):(rr*Klink)]*sum(Boxr)
                rho[[rr]]=rho[[rr]]-(Boxr[1])
                rho[[rr]]=10^(rho[[rr]])
                rho[[rr]]=rho[[rr]]*Rho[rr]

                xx=0
                rho_[[rr]]=vector()
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  rho_[[rr]][x:xx]= rho[[rr]][ix]
                }
              }
              start_position=start_position+(Klink*NC)
            }
            if(ER==2){

              Boxr_s=get('Boxr_s', envir=test.env)

              #t_r=min(ceiling(param[(start_position+1)]*Klink),Klink)
              t_r=get('t_r', envir=test.env)

              rho=list()
              rho_=list()

              for(rr in 1:NC){

                if(t_r>Klink){
                  oldrho_param=rep(Boxr_s[1],Klink)
                }else{
                  if(t_r>1){
                    oldrho_param=c(rep(Boxr_s[1],(t_r-1)),rep(Boxr_s[2],(Klink-t_r+1)))
                  }else{
                    oldrho_param=rep(Boxr_s[2],Klink)
                  }
                }


                rho[[rr]]= oldrho_param[(1+((rr-1)*Klink)):(rr*Klink)]*sum(Boxr)
                rho[[rr]]=rho[[rr]]-(Boxr[1])
                rho[[rr]]=10^(rho[[rr]])
                rho[[rr]]=rho[[rr]]*Rho[rr]

                xx=0
                rho_[[rr]]=vector()
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  rho_[[rr]][x:xx]= rho[[rr]][ix]
                }
              }
            }
            if(ER==0){
              rho_=list()
              for(rr in 1:NC){
                rho_[[rr]]=rep(Rho[rr],n)
              }
            }
            if(SF==1){
              sigma_=numeric(n)
              sigma=param[(start_position+1):(start_position+Klink)]
              start_position=start_position+Klink
              sigma=sigma*(Boxs[2]-Boxs[1])
              sigma=sigma+Boxs[1]
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                sigma_[x:xx]=sigma[ix]
              }
            }
            if(SF==2){
              Boxs_s=get('Boxs_s', envir=test.env)
              sigma_=numeric(n)

              #t_s=min(ceiling(param[(start_position+1)]*Klink),Klink)
              t_s=get('t_s', envir=test.env)
              if(t_s>Klink){
                sigma=rep(Boxs_s[1],Klink)
              }else{
                if(t_s>1){
                  sigma=c(rep(Boxs_s[1],(t_s-1)),rep(Boxs_s[2],(Klink-t_s+1)))
                }else{
                  sigma=rep(Boxs_s[2],Klink)
                }
              }
              #start_position=start_position+1
              sigma=sigma*(Boxs[2]-Boxs[1])
              sigma=sigma+Boxs[1]
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                sigma_[x:xx]=sigma[ix]
              }

            }
            if(SF==0){
              sigma_=rep(sigma,n)
            }
            if(SB==1){
              beta_=numeric(n)
              beta=((param[(start_position+1):(start_position+Klink)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
              start_position=start_position+(Klink)
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                beta_[x:xx]=beta[ix]

              }
            }
            if(SB==2){
              beta_=numeric(n)
              BoxB_s=get('BoxB_s', envir=test.env)
              #t_b=min(ceiling(param[(start_position+1)]*Klink),Klink)
              t_b=get('t_b', envir=test.env)
              if(t_b>Klink){
                beta=rep(BoxB_s[1],Klink)
              }else{
                if(t_b>1){
                  beta=c(rep(BoxB_s[1],(t_b-1)),rep(BoxB_s[2],(Klink-t_b+1)))
                }else{
                  beta=rep(BoxB_s[2],Klink)
                }
              }

              beta=((beta*(BoxB[2]-BoxB[1]))+BoxB[1])^2
              # start_position=start_position+1
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                beta_[x:xx]=beta[ix]

              }
            }
            if(SB==0){
              beta_=rep(beta,n)
            }
            if(!Pop){
              Xi=numeric(n)
              Xi_=param[(start_position+1):(start_position+Klink)]
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                Xi[x:xx]=Xi_[ix]
              }
              Xi=Xi*sum(BoxP)
              Xi=Xi-(BoxP[1])
              Xi=10^Xi
            }else{
              Xi=rep(1,n)
            }

            MLH=0


            for(chr in 1:NC){
              builder=build_HMM_matrix_t(k,(rho[[chr]]),beta=beta,L=L[chr],Pop=Pop,Xi_,Beta=Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
              Q = builder[[1]]
              nu= builder[[2]]
              Tc=builder[[3]]
              g=build_emission_matrix(mu[chr],mu_b,Tc=builder[[4]],t=builder[[3]],beta,FS)




              q_=rep(0,length(Tc))
              test=Build_zip_Matrix_mailund(Q,g,Os[[chr]][[1]][[2]],nu,do_all=F)

              for(i in 1:length(Os[[chr]])){
                fo=forward_zip_mailund(Os[[chr]][[i]][[1]],g,nu,test[[1]])
                MLH=MLH-fo[[3]]


              }
            }
            return(MLH)
          }

          param=c()
          if(ER==1){
            for(rr in 1:NC){
              param=c(param,oldrho[[rr]])
            }
          }

          if(SF==1){
            param=c(param,oldsigma)
          }

          if(SB==1){
            param=c(param,oldbeta)
          }

          if(!Popfix){
            param=c(param,oldXi_)
          }

          LH_temp=0


            if(ER==2){
              for(t_r in 1:(1+Klink)){
                test.env$t_r <- t_r
                if(SB==2){
                  for( t_b in 1:(1+Klink)){
                    test.env$t_b <- t_b
                    if(SF==2){

                      for(t_s in 1:(1+Klink)){
                        test.env$t_s <- t_s

                        sol_temp=function_to_minimize(param)
                        if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                          LH_temp=as.numeric(sol_temp)
                          oldtr=t_r
                          oldtb=t_b
                          oldts=t_s

                        }

                      }

                    }else{
                      sol_temp=function_to_minimize(param)
                      if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                        LH_temp=as.numeric(sol_temp)
                        oldtr=t_r
                        oldtb=t_b

                      }
                    }
                  }

                }else{ # NO  SB
                  if(SF==2){
                    for(t_s in 1:(1+Klink)){
                      test.env$t_s <- t_s
                      sol_temp=function_to_minimize(param)
                      if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                        LH_temp=as.numeric(sol_temp)
                        oldtr=t_r
                        oldts=t_s

                      }
                    }
                  }else{
                    sol_temp=function_to_minimize(param)
                    if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                      LH_temp=as.numeric(sol_temp)
                      oldtr=t_r

                    }
                  }
                }
              }
            }else{ # No ER
              if(SB==2){
                for( t_b in 1:(1+Klink)){
                  test.env$t_b <- t_b
                  if(SF==2){

                    for(t_s in 1:(1+Klink)){
                      test.env$t_s <- t_s
                      sol_temp=function_to_minimize(param)
                      if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                        LH_temp=as.numeric(sol_temp)
                        oldtb=t_b
                        oldts=t_s

                      }
                    }
                  }else{
                    sol_temp=function_to_minimize(param)
                    if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                      LH_temp=as.numeric(sol_temp)
                      oldtb=t_b

                    }
                  }
                }
              }else{
                if(SF==2){

                  for(t_s in 1:(1+Klink)){
                    test.env$t_s <- t_s
                    sol_temp=function_to_minimize(param)
                    print(sol_temp)
                    if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                      LH_temp=as.numeric(sol_temp)
                      oldts=t_s


                    }
                  }
                }else{

                  stop("How did you get here ?")

                }
              }
            }


          if(ER==2){
            test.env$t_r <- oldtr

            if(oldtr>Klink){
              oldrho=rep(Boxr_s[1],(Klink))
            }else{
              if(oldtr>1){
                oldrho=c(rep(Boxr_s[1],(oldtr-1)),rep(Boxr_s[2],(Klink+1-oldtr)))
              }else{
                oldrho=rep(Boxr_s[2],(Klink))
              }
            }



          }


          if(SF==2){
            # oldts=ceiling(sol[(start_position+1)]*Klink)
            #   start_position=start_position+1
            test.env$t_s <- oldts

            if(oldts>Klink){
              oldsigma=rep(Boxs_s[1],(Klink))
            }else{
              if(oldts>1){
                oldsigma=c(rep(Boxs_s[1],(oldts-1)),rep(Boxs_s[2],(Klink+1-oldts)))
              }else{
                oldsigma=rep(Boxs_s[2],(Klink))
              }
            }
          }



          if(SB==2){
            #    oldtb=ceiling(sol[(start_position+1)]*Klink)
            #   start_position=start_position+1
            test.env$t_b <- oldtb

            if(oldts>Klink){
              oldbeta=rep(BoxB_s[1],(Klink))
            }else{
              if(oldtb>1){
                oldbeta=c(rep(BoxB_s[1],(oldtb-1)),rep(BoxB_s[2],(Klink+1-oldtb)))
              }else{
                oldbeta=rep(BoxB_s[2],(Klink))
              }
            }


          }

          if(Popfix){
            if(!is.list(oldrho)){
              rho_=oldrho*sum(Boxr)
              rho_=rho_-(Boxr[1])
              rho_=10^(rho_)
              rho_=rho_*Rho
              rho=vector()
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                rho[x:xx]= rho_[ix]
              }
            }else{
              rho_=list()
              rho=list()
              for(rr in 1:NC){
                rho_[[rr]]=oldrho[[rr]]*sum(Boxr)
                rho_[[rr]]=rho_[[rr]]-(Boxr[1])
                rho_[[rr]]=10^(rho_[[rr]])
                rho_[[rr]]=rho_[[rr]]*Rho[rr]

                xx=0
                rho[[rr]]=vector()
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  rho[[rr]][x:xx]= rho_[[rr]][ix]
                }
              }

            }

            if(SB>0){
              beta_=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1] )^2
              beta=vector()
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                beta[x:xx]=beta_[ix]
              }
            }
            if(SF>0){
              sigma_=oldsigma*(Boxs[2]-Boxs[1])
              sigma_=sigma_+Boxs[1]
              sigma=vector()
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                sigma[x:xx]= sigma_[ix]
              }
            }
            print(c("sigma:",sigma,"beta :",beta))
            if(is.list(rho_)){
              print(c("rho/theta:",rho_[[1]]/theta))
            }else{
              print(c("rho/theta:",rho_/theta))
            }
            Keep_going=F
            if(it==1){
              diff_o=0
            }
            if(it>1){
              if(SF==1){
                diff_o=mean(abs(sigma_o-sigma))
              }
              if(SF==2){
                diff_o=0.0001
              }
              if(SB==1){
                diff_o=max(diff_o,mean(abs(beta_o-beta)))
              }
              if(SB==2){
                diff_o=max(diff_o,0.0001)
              }
              count_diff_o=0
              if(diff_o>=0.005){
                if(it==maxIt){
                  count_diff_o=count_diff_o+1
                  maxIt=maxIt+1
                  if(count_diff_o>10){
                    maxBit=maxBit-1
                  }
                }
              }
            }
            sigma_o=sigma
            beta_o=beta



            if(NC==1){
              builder=build_HMM_matrix_t(k,(rho),beta=beta,L=L,Pop=Pop,Xi=NA,Beta=Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
            }
            if(NC>1){
              builder=list()
              for(chr in 1:NC){
                builder[[chr]]=build_HMM_matrix_t(k,(rho[[chr]]),beta=beta,L=L[chr],Pop=Pop,Xi=NA,Beta=Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
              }
            }
          }
          if(!Popfix){
            xx=0
            for(ix in 1:Klink){
              x=xx+1
              xx = xx + pop_vect[ix]
              oldXi[x:xx]=oldXi_[ix]
            }
            Xi_=oldXi*sum(BoxP)
            Xi_=Xi_-(BoxP[1])
            Xi_=10^Xi_
            if(!is.list(oldrho)){
              rho_=oldrho*sum(Boxr)
              rho_=rho_-(Boxr[1])
              rho_=10^(rho_)
              rho_=rho_*Rho
              rho=vector()
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                rho[x:xx]= rho_[ix]
              }
            }else{
              rho_=list()
              rho=list()
              for(rr in 1:NC){
                rho_[[rr]]=oldrho[[rr]]*sum(Boxr)
                rho_[[rr]]=rho_[[rr]]-(Boxr[1])
                rho_[[rr]]=10^(rho_[[rr]])
                rho_[[rr]]=rho_[[rr]]*Rho[rr]
                rho[[rr]]=vector()
                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  rho[[rr]][x:xx]= rho_[[rr]][ix]
                }
              }

            }
            if(SB>0){
              beta_=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1] )^2
              beta=vector()
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                beta[x:xx]=beta_[ix]
              }
            }
            if(SF>0){
              sigma_=oldsigma*(Boxs[2]-Boxs[1])
              sigma_=sigma_+Boxs[1]
              sigma=vector()
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                sigma[x:xx]= sigma_[ix]
              }
            }
            print(c("sigma:",sigma,"beta :",beta))
            Keep_going=F
            if(it==1){
              diff_o=0
            }
            if(it>1){
              if(SF==1){
                diff_o=mean(abs(sigma_o-sigma))
              }
              if(SF==2){
                diff_o=0.0001
              }
              if(SB==1){
                diff_o=max(diff_o,mean(abs(beta_o-beta)))
              }
              if(SB==2){
                diff_o=max(diff_o,0.0001)
              }
              count_diff_o=0
              if(diff_o>=0.005){
                if(it==maxIt){
                  count_diff_o=count_diff_o+1
                  maxIt=maxIt+1
                  if(count_diff_o>10){
                    maxBit=maxBit-1
                  }
                }
              }
            }
            sigma_o=sigma
            beta_o=beta
            #
            if(NC==1){
              builder=build_HMM_matrix_t(k,(rho),beta=beta,L=L,Pop=Pop,Xi_,Beta=Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
            }
            if(NC>1){
              builder=list()
              for(chr in 1:NC){
                builder[[chr]]=build_HMM_matrix_t(k,(rho[[chr]]),beta=beta,L=L[chr],Pop=Pop,Xi_,Beta=Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
              }
            }
          }

          if(NC>1){



            test.env$ER <- ER
            test.env$SF <- SF
            test.env$SB <- SB
            test.env$Os <- Os



            function_to_minimize<-function(param){
              Boxr=get('Boxr', envir=test.env)
              mu=get('mu', envir=test.env)
              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)
              mu_b=get('mu_b', envir=test.env)
              FS=get('FS', envir=test.env)
              Klink=get('Klink', envir=test.env)
              Rho=get('Rho', envir=test.env)
              BoxB=get('BoxB', envir=test.env)
              Boxs=get('Boxs', envir=test.env)
              BoxP=get('BoxP', envir=test.env)
              pop_vect=get('pop_vect', envir=test.env)
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Beta=get('Beta', envir=test.env)
              Self=get('Self', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)
              Pop=get('Pop', envir=test.env)
              ER=get('ER', envir=test.env)
              SF=get('SF', envir=test.env)
              SB=get('SB', envir=test.env)
              Os=get('Os', envir=test.env)
              start_position=0
              if(ER==1){

                rho=list()
                rho_=list()
                oldrho_param=param[(start_position+1):(start_position+(Klink*NC))]
                for(rr in 1:NC){
                  rho[[rr]]= oldrho_param[(1+((rr-1)*Klink)):(rr*Klink)]*sum(Boxr)
                  rho[[rr]]=rho[[rr]]-(Boxr[1])
                  rho[[rr]]=10^(rho[[rr]])
                  rho[[rr]]=rho[[rr]]*Rho[rr]

                  xx=0
                  rho_[[rr]]=vector()
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    rho_[[rr]][x:xx]= rho[[rr]][ix]
                  }
                }
                start_position=start_position+(Klink*NC)
              }
              if(ER==2){

                Boxr_s=get('Boxr_s', envir=test.env)

                #t_r=min(ceiling(param[(start_position+1)]*Klink),Klink)
                t_r=get('t_r', envir=test.env)

                rho=list()
                rho_=list()

                for(rr in 1:NC){

                  if(t_r>Klink){
                    oldrho_param=rep(Boxr_s[1],Klink)
                  }else{
                    if(t_r>1){
                      oldrho_param=c(rep(Boxr_s[1],(t_r-1)),rep(Boxr_s[2],(Klink-t_r+1)))
                    }else{
                      oldrho_param=rep(Boxr_s[2],Klink)
                    }
                  }


                  rho[[rr]]= oldrho_param[(1+((rr-1)*Klink)):(rr*Klink)]*sum(Boxr)
                  rho[[rr]]=rho[[rr]]-(Boxr[1])
                  rho[[rr]]=10^(rho[[rr]])
                  rho[[rr]]=rho[[rr]]*Rho[rr]

                  xx=0
                  rho_[[rr]]=vector()
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    rho_[[rr]][x:xx]= rho[[rr]][ix]
                  }
                }
              }
              if(ER==0){
                rho_=list()
                for(rr in 1:NC){
                  rho_[[rr]]=rep(Rho[rr],n)
                }
              }
              if(SF==1){
                sigma_=numeric(n)
                sigma=param[(start_position+1):(start_position+Klink)]
                start_position=start_position+Klink
                sigma=sigma*(Boxs[2]-Boxs[1])
                sigma=sigma+Boxs[1]
                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  sigma_[x:xx]=sigma[ix]
                }
              }
              if(SF==2){
                Boxs_s=get('Boxs_s', envir=test.env)
                sigma_=numeric(n)
                t_s=get('t_s', envir=test.env)
                if(t_s>1){
                  sigma=c(rep(Boxs_s[1],(t_s-1)),rep(Boxs_s[2],(Klink-t_s+1)))
                }else{
                  sigma=rep(Boxs_s[2],Klink)
                }
                start_position=start_position+1
                sigma=sigma*(Boxs[2]-Boxs[1])
                sigma=sigma+Boxs[1]
                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  sigma_[x:xx]=sigma[ix]
                }
              }
              if(SF==0){
                sigma_=rep(sigma,n)
              }
              if(SB==1){
                beta_=numeric(n)
                beta=((param[(start_position+1):(start_position+Klink)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
                start_position=start_position+(Klink)
                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  beta_[x:xx]=beta[ix]

                }
              }
              if(SB==2){
                beta_=numeric(n)
                BoxB_s=get('BoxB_s', envir=test.env)
                t_b=get('t_b', envir=test.env)
                if(t_b>1){
                  beta=c(rep(BoxB_s[1],(t_b-1)),rep(BoxB_s[2],(Klink-t_b+1)))
                }else{
                  beta=rep(BoxB_s[2],Klink)
                }

                beta=((beta*(BoxB[2]-BoxB[1]))+BoxB[1])^2
                start_position=start_position+1
                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  beta_[x:xx]=beta[ix]

                }
              }
              if(SB==0){
                beta_=rep(beta,n)
              }
              if(!Pop){
                Xi=numeric(n)
                Xi_=param[(start_position+1):(start_position+Klink)]
                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  Xi[x:xx]=Xi_[ix]
                }
                Xi=Xi*sum(BoxP)
                Xi=Xi-(BoxP[1])
                Xi=10^Xi
              }else{
                Xi=rep(1,n)
              }
              MLH=0


              for(chr in 1:NC){
                builder=build_HMM_matrix_t(k,(rho[[chr]]),beta=beta,L=L[chr],Pop=Pop,Xi_,Beta=Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
                Q = builder[[1]]
                nu= builder[[2]]
                Tc=builder[[3]]
                g=build_emission_matrix(mu[chr],mu_b,Tc=builder[[4]],t=builder[[3]],beta,FS)




                q_=rep(0,length(Tc))
                test=Build_zip_Matrix_mailund(Q,g,Os[[chr]][[1]][[2]],nu,do_all=F)

                for(i in 1:length(Os[[chr]])){
                  fo=forward_zip_mailund(Os[[chr]][[i]][[1]],g,nu,test[[1]])
                  MLH=MLH-fo[[3]]


                }
              }
              return(MLH)
            }



            param=c()
            if(ER==1){
              for(rr in 1:NC){
                param=c(param,oldrho[[rr]])
              }
            }
            if(SF==1){
              param=c(param,oldsigma)
            }
            if(SB==1){
              param=c(param,oldbeta)
            }
            if(!Popfix){
              param=c(param,oldXi_)
            }

            sol= BB::BBoptim(param,function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=length(param),M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            start_position=0


            sol=as.numeric(sol[1:length(param),1])
            if(ER==1){
              rho=sol[(start_position+1):(start_position+Klink)]
              start_position=start_position+Klink
              if(ER==1){
                for(rr in 1:NC){
                  oldrho[[rr]]=rho[(1+((1-rr)*Klink)):(rr*Klink)]
                }
              }
            }
            if(SF==1){
              sigma_=sol[(start_position+1):(start_position+Klink)]
              start_position=start_position+Klink
              oldsigma=sigma_
            }
            if(SB==1){
              beta_=sol[(start_position+1):(start_position+Klink)]
              start_position=start_position+Klink
              oldbeta=beta_
            }
            if(!Popfix){
              Xi_=sol[(start_position+1):(start_position+Klink)]
              start_position=start_position+Klink
              oldXi_=Xi_
            }

          }

        }
      }
    }

    if(Popfix){
      if(ER<3){
        if(!is.list(oldrho)){
          rho_=oldrho*sum(Boxr)
          rho_=rho_-(Boxr[1])
          rho_=10^(rho_)
          rho_=rho_*Rho
          rho=vector()
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            rho[x:xx]= rho_[ix]
          }
        }else{
          rho_=list()
          rho=list()
          for(rr in 1:NC){
            rho_[[rr]]=oldrho[[rr]]*sum(Boxr)
            rho_[[rr]]=rho_[[rr]]-(Boxr[1])
            rho_[[rr]]=10^(rho_[[rr]])
            rho_[[rr]]=rho_[[rr]]*Rho[rr]

            xx=0
            rho[[rr]]=vector()
            for(ix in 1:Klink){
              x=xx+1
              xx = xx + pop_vect[ix]
              rho[[rr]][x:xx]= rho_[[rr]][ix]
            }
          }

        }
      }else{
        if(!is.list(oldrho)){
          rho=vector()
          if(oldtr==1){
            rho_=oldrho*sum(Boxr_2)
            rho_=rho_-(Boxr_2[1])
            rho_=10^(rho_)
            rho_=rho_*Rho
          }
          if(oldtr>Klink){
            rho_=oldrho*sum(Boxr_1)
            rho_=rho_-(Boxr_1[1])
            rho_=10^(rho_)
            rho_=rho_*Rho*correct_R
          }
          if(oldtr>1&oldtr<=Klink){
            rho_=c(oldrho[1:(oldtr-1)]*sum(Boxr_1),oldrho[oldtr:Klink]*sum(Boxr_2))
            rho_=c(rho_[1:(oldtr-1)]-(Boxr_1[1]),rho_[oldtr:Klink]-(Boxr_2[1]))
            rho_=10^(rho_)
            rho_=c(rho_[1:(oldtr-1)]*Rho,rho_[oldtr:Klink]*Rho*correct_R)

          }




          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            rho[x:xx]= rho_[ix]
          }
        }else{
          rho_=list()
          rho=list()
          for(rr in 1:NC){


            if(oldtr==1){
              rho_[[rr]]=oldrho[[rr]]*sum(Boxr_2)
              rho_[[rr]]=rho_[[rr]]-(Boxr_2[1])
              rho_[[rr]]=10^(rho_[[rr]])
              rho_[[rr]]=rho_[[rr]]*Rho[rr]
            }
            if(oldtr>Klink){
              rho_[[rr]]=oldrho[[rr]]*sum(Boxr_1)
              rho_[[rr]]=rho_[[rr]]-(Boxr_1[1])
              rho_[[rr]]=10^(rho_[[rr]])
              rho_[[rr]]=rho_[[rr]]*Rho[rr]*correct_R
            }
            if(oldtr>1&oldtr<=Klink){


              rho_[[rr]]=c(oldrho[[rr]][1:(oldtr-1)]*sum(Boxr_1),oldrho[[rr]][oldtr:Klink]*sum(Boxr_2))
              rho_[[rr]]=c(rho_[[rr]][1:(oldtr-1)]-(Boxr_1[1]),rho_[[rr]][oldtr:Klink]-(Boxr_2[1]))
              rho_[[rr]]=10^(rho_[[rr]])
              rho_[[rr]]=c(rho_[[rr]][1:(oldtr-1)]*Rho[rr],rho_[[rr]][oldtr:Klink]*Rho[rr]*correct_R)
            }


            xx=0
            rho[[rr]]=vector()
            for(ix in 1:Klink){
              x=xx+1
              xx = xx + pop_vect[ix]
              rho[[rr]][x:xx]= rho_[[rr]][ix]
            }
          }

        }
      }


      if(SB>0){
        if(SB<3){
          beta_=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1] )^2
        }else{
          if(oldtb==1){
            beta_=((oldbeta*(BoxB_2[2]-BoxB_2[1]))+BoxB_2[1] )^2
          }else{
            if(oldtb>Klink){
              beta_=((oldbeta*(BoxB_1[2]-BoxB_1[1]))+BoxB_1[1] )^2
            }else{
              beta_= c( ((oldbeta[1:(oldtb-1)]*(BoxB_1[2]-BoxB_1[1]))+BoxB_1[1] )^2 , ((oldbeta[oldtb:Klink]*(BoxB_2[2]-BoxB_2[1]))+BoxB_2[1] )^2 )
            }
          }


        }

        beta=vector()
        xx=0
        for(ix in 1:Klink){
          x=xx+1
          xx = xx + pop_vect[ix]
          beta[x:xx]=beta_[ix]
        }
      }
      if(SF>0){
        if(SF<3){
          sigma_=oldsigma*(Boxs[2]-Boxs[1])
          sigma_=sigma_+Boxs[1]
        }else{
          if(oldts==1){
            sigma_=oldsigma*(Boxs_2[2]-Boxs_2[1])
            sigma_=sigma_+Boxs_2[1]
          }else{
            if(oldts>Klink){
              sigma_=oldsigma*(Boxs_1[2]-Boxs_1[1])
              sigma_=sigma_+Boxs_1[1]
            }else{

              sigma_= c(oldsigma[1:(oldts-1)]*(Boxs_1[2]-Boxs_1[1]) ,oldsigma[oldts:Klink]*(Boxs_2[2]-Boxs_2[1]) )
              sigma_= c( (sigma_[1:(oldts-1)]+Boxs_1[1]) , (sigma_[oldts:Klink]+Boxs_2[1]))
            }
          }
        }


        sigma=vector()
        xx=0
        for(ix in 1:Klink){
          x=xx+1
          xx = xx + pop_vect[ix]
          sigma[x:xx]= sigma_[ix]
        }
      }
      print(c("sigma:",sigma,"beta :",beta))
      if(is.list(rho_)){
        print(c("rho/theta:",rho_[[1]]/theta))
      }else{
        print(c("rho/theta:",rho_/theta))
      }
      Keep_going=F
      if(it==1){
        diff_o=0
      }
      if(it>1){
        if(SF==1){
          diff_o=mean(abs(sigma_o-sigma))
        }
        if(SF>1){
          diff_o=0.0001
        }
        if(SB==1){
          diff_o=max(diff_o,mean(abs(beta_o-beta)))
        }
        if(SB>1){
          diff_o=max(diff_o,0.0001)
        }
        count_diff_o=0
        if(diff_o>=0.005){
          if(it==maxIt){
            count_diff_o=count_diff_o+1
            maxIt=maxIt+1
            if(count_diff_o>10){
              maxBit=maxBit-1
            }
          }
        }
      }
      sigma_o=sigma
      beta_o=beta



      if(NC==1){
        builder=build_HMM_matrix_t(k,(rho),beta=beta,L=L,Pop=Pop,Xi=NA,Beta=Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
      }
      if(NC>1){
        builder=list()
        for(chr in 1:NC){
          builder[[chr]]=build_HMM_matrix_t(k,(rho[[chr]]),beta=beta,L=L[chr],Pop=Pop,Xi=NA,Beta=Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
        }
      }
    }
    if(!Popfix){
      xx=0
      for(ix in 1:Klink){
        x=xx+1
        xx = xx + pop_vect[ix]
        oldXi[x:xx]=oldXi_[ix]
      }
      Xi_=oldXi*sum(BoxP)
      Xi_=Xi_-(BoxP[1])
      Xi_=10^Xi_
      if(ER<3){
        if(!is.list(oldrho)){
          rho_=oldrho*sum(Boxr)
          rho_=rho_-(Boxr[1])
          rho_=10^(rho_)
          rho_=rho_*Rho
          rho=vector()
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            rho[x:xx]= rho_[ix]
          }
        }else{
          rho_=list()
          rho=list()
          for(rr in 1:NC){
            rho_[[rr]]=oldrho[[rr]]*sum(Boxr)
            rho_[[rr]]=rho_[[rr]]-(Boxr[1])
            rho_[[rr]]=10^(rho_[[rr]])
            rho_[[rr]]=rho_[[rr]]*Rho[rr]

            xx=0
            rho[[rr]]=vector()
            for(ix in 1:Klink){
              x=xx+1
              xx = xx + pop_vect[ix]
              rho[[rr]][x:xx]= rho_[[rr]][ix]
            }
          }

        }
      }else{
        if(!is.list(oldrho)){
          rho=vector()
          if(oldtr==1){
            rho_=oldrho*sum(Boxr_2)
            rho_=rho_-(Boxr_2[1])
            rho_=10^(rho_)
            rho_=rho_*Rho
          }
          if(oldtr>Klink){
            rho_=oldrho*sum(Boxr_1)
            rho_=rho_-(Boxr_1[1])
            rho_=10^(rho_)
            rho_=rho_*Rho*correct_R
          }
          if((oldtr>1)&oldtr<=Klink){
            for(t_r in 1:2){

              rho_=c(oldrho[1:(oldtr-1)]*sum(Boxr_1),oldrho[oldtr:Klink]*sum(Boxr_2))
              rho_=c(rho_[1:(oldtr-1)]-(Boxr_1[1]),rho_[oldtr:Klink]-(Boxr_2[1]))
              rho_=10^(rho_)
              rho_=c(rho_[1:(oldtr-1)]*Rho,rho_[oldtr:Klink]*Rho*correct_R)
            }
          }




          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            rho[x:xx]= rho_[ix]
          }
        }else{
          rho_=list()
          rho=list()
          for(rr in 1:NC){


            if(oldtr==1){
              rho_[[rr]]=oldrho[[rr]]*sum(Boxr_2)
              rho_[[rr]]=rho_[[rr]]-(Boxr_2[1])
              rho_[[rr]]=10^(rho_[[rr]])
              rho_[[rr]]=rho_[[rr]]*Rho[rr]
            }
            if(oldtr>Klink){
              rho_[[rr]]=oldrho[[rr]]*sum(Boxr_1)
              rho_[[rr]]=rho_[[rr]]-(Boxr_1[1])
              rho_[[rr]]=10^(rho_[[rr]])
              rho_[[rr]]=rho_[[rr]]*Rho[rr]*correct_R
            }
            if((oldtr>1)&oldtr<=Klink){
              for(t_r in 1:2){

                rho_[[rr]]=c(oldrho[[rr]][1:(oldtr-1)]*sum(Boxr_1),oldrho[[rr]][oldtr:Klink]*sum(Boxr_2))
                rho_[[rr]]=c(rho_[[rr]][1:(oldtr-1)]-(Boxr_1[1]),rho_[[rr]][oldtr:Klink]-(Boxr_2[1]))
                rho_[[rr]]=10^(rho_[[rr]])
                rho_[[rr]]=c(rho_[[rr]][1:(oldtr-1)]*Rho[rr],rho_[[rr]][oldtr:Klink]*Rho[rr]*correct_R)
              }
            }


            xx=0
            rho[[rr]]=vector()
            for(ix in 1:Klink){
              x=xx+1
              xx = xx + pop_vect[ix]
              rho[[rr]][x:xx]= rho_[[rr]][ix]
            }
          }

        }
      }
      if(SB>0){
        if(SB<3){
          beta_=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1] )^2
        }else{
          if(oldtb==1){
            beta_=((oldbeta*(BoxB_2[2]-BoxB_2[1]))+BoxB_2[1] )^2
          }else{
            if(oldtb>Klink){
              beta_=((oldbeta*(BoxB_1[2]-BoxB_1[1]))+BoxB_1[1] )^2
            }else{
              beta_= c( ((oldbeta[1:(oldtb-1)]*(BoxB_1[2]-BoxB_1[1]))+BoxB_1[1] )^2 , ((oldbeta[oldtb:Klink]*(BoxB_2[2]-BoxB_2[1]))+BoxB_2[1] )^2 )
            }
          }


        }

        beta=vector()
        xx=0
        for(ix in 1:Klink){
          x=xx+1
          xx = xx + pop_vect[ix]
          beta[x:xx]=beta_[ix]
        }
      }
      if(SF>0){
        if(SF<3){
          sigma_=oldsigma*(Boxs[2]-Boxs[1])
          sigma_=sigma_+Boxs[1]
        }else{
          if(oldts==1){
            sigma_=oldsigma*(Boxs_2[2]-Boxs_2[1])
            sigma_=sigma_+Boxs_2[1]
          }else{
            if(oldts>Klink){
              sigma_=oldsigma*(Boxs_1[2]-Boxs_1[1])
              sigma_=sigma_+Boxs_1[1]
            }else{

              sigma_= c(oldsigma[1:(oldts-1)]*(Boxs_1[2]-Boxs_1[1]) ,oldsigma[oldts:Klink]*(Boxs_2[2]-Boxs_2[1]) )
              sigma_= c( (sigma_[1:(oldts-1)]+Boxs_1[1]) , (sigma_[oldts:Klink]+Boxs_2[1]))
            }
          }
        }


        sigma=vector()
        xx=0
        for(ix in 1:Klink){
          x=xx+1
          xx = xx + pop_vect[ix]
          sigma[x:xx]= sigma_[ix]
        }
      }
      print(c("sigma:",sigma,"beta :",beta))

      Keep_going=F
      if(it==1){
        diff_o=0
      }
      if(it>1){
        if(SF>1){
          diff_o=mean(abs(sigma_o-sigma))
        }
        if(SF==2){
          diff_o=0.0001
        }
        if(SB==1){
          diff_o=max(diff_o,mean(abs(beta_o-beta)))
        }
        if(SB>1){
          diff_o=max(diff_o,0.0001)
        }
        count_diff_o=0
        if(diff_o>=0.005){
          if(it==maxIt){
            count_diff_o=count_diff_o+1
            maxIt=maxIt+1
            if(count_diff_o>10){
              maxBit=maxBit-1
            }
          }
        }
      }
      sigma_o=sigma
      beta_o=beta
      # browser()
      if(NC==1){
        builder=build_HMM_matrix_t(k,(rho),beta=beta,L=L,Pop=Pop,Xi_,Beta=Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
      }
      if(NC>1){
        builder=list()
        for(chr in 1:NC){
          builder[[chr]]=build_HMM_matrix_t(k,(rho[[chr]]),beta=beta,L=L[chr],Pop=Pop,Xi_,Beta=Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
        }
      }
    }

    if(NC==1){
      Q = builder[[1]]
      nu= builder[[2]]
      Tc=builder[[3]]
      g=build_emission_matrix(mu,mu_b,Tc=builder[[4]],t=builder[[3]],beta,FS)

      Tc_r=builder[[4]]
    }
    if(NC>1){
      Q=list()
      nu=list()
      Tc=list()
      Tc_r=list()
      g=list()
      for(chr in 1:NC){
        Q[[chr]] = builder[[chr]][[1]]
        nu[[chr]]= builder[[chr]][[2]]
        Tc[[chr]]=builder[[chr]][[3]]
        Tc_r[[chr]]=builder[[chr]][[4]]
        g[[chr]]=build_emission_matrix(mu[chr],mu_b,Tc=builder[[chr]][[4]],t=builder[[chr]][[3]],beta,FS)
      }
    }
    if(SB==0){
      oldBeta=Beta
    }
    if(SB>0){
      oldBeta=Beta
      Beta=beta[1]
    }
    if(SF>0){
      oldSelf=Self
      Self=sigma[1]
    }
    if(SF==0){
      oldSelf=Self
    }
    if(Beta==oldBeta&Self==oldSelf){
      mb=maxBit
      print("no need  for more iteration")
    }
    if(NC==1){
      gamma_t=mean(rho)/mu
    }
    if(NC>1){
      gamma_t=vector()
      for(chr in 1:NC){
        gamma_t[chr]=mean(rho[[chr]])/mu[chr]
      }
    }
    print(gamma_t)
    print(gamma)
    if(any(gamma_t<=0.5*gamma|gamma_t>=2*gamma)&redo_R){
      maxBit=maxBit+1
      gamma=gamma_t
    }

  }
  if(NC==1){
    res <- list();

      LH=0
      if(!LH_opt){
      test=Build_zip_Matrix_mailund(Q,g,Os[[1]][[2]],nu,do_all=F)
      }else{
        test=Build_zip_Matrix_LH_mailund(Q,g,Os[[1]][[2]],nu)
      }
      for(i in 1:length(Os)){
        fo=forward_zip_mailund(Os[[i]][[1]],g,nu,test[[1]])
        LH=LH+(sum(fo[[2]]))
      }

      res<-list()
      res$LH=LH
      res$Tc=builder[[4]]

      if(NC==1){
        rho_=oldrho*sum(Boxr)
        rho_=rho_-(Boxr[1])
        rho_=10^(rho_)
        rho_=rho_*Rho
        rho=vector()
        xx=0
        for(ix in 1:Klink){
          x=xx+1
          xx = xx + pop_vect[ix]
          rho[x:xx]=rho_[ix]/(2*L)
        }

      }
      if(SB>0){
        if(SB<3){
          beta_=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1] )^2
        }else{
          if(oldtb==1){
            beta_=((oldbeta*(BoxB_2[2]-BoxB_2[1]))+BoxB_2[1] )^2
          }else{
            if(oldtb>Klink){
              beta_=((oldbeta*(BoxB_1[2]-BoxB_1[1]))+BoxB_1[1] )^2
            }else{
              beta_= c( ((oldbeta[1:(oldtb-1)]*(BoxB_1[2]-BoxB_1[1]))+BoxB_1[1] )^2 , ((oldbeta[oldtb:Klink]*(BoxB_2[2]-BoxB_2[1]))+BoxB_2[1] )^2 )
            }
          }


        }

        beta=vector()
        xx=0
        for(ix in 1:Klink){
          x=xx+1
          xx = xx + pop_vect[ix]
          beta[x:xx]=beta_[ix]
        }
      }


      if(SF>0){
        if(SF<3){
          sigma_=oldsigma*(Boxs[2]-Boxs[1])
          sigma_=sigma_+Boxs[1]
        }else{
          if(oldts==1){
            sigma_=oldsigma*(Boxs_2[2]-Boxs_2[1])
            sigma_=sigma_+Boxs_2[1]
          }else{
            if(oldts>Klink){
              sigma_=oldsigma*(Boxs_1[2]-Boxs_1[1])
              sigma_=sigma_+Boxs_1[1]
            }else{

              sigma_= c(oldsigma[1:(oldts-1)]*(Boxs_1[2]-Boxs_1[1]) ,oldsigma[oldts:Klink]*(Boxs_2[2]-Boxs_2[1]) )
              sigma_= c( (sigma_[1:(oldts-1)]+Boxs_1[1]) , (sigma_[oldts:Klink]+Boxs_2[1]))
            }
          }
        }


        sigma=vector()
        xx=0
        for(ix in 1:Klink){
          x=xx+1
          xx = xx + pop_vect[ix]
          sigma[x:xx]= sigma_[ix]
        }
      }
      if(!Popfix){
        res$Xi=Xi_
      }else{
        res$Xi=rep(1,k)
      }

      if(FS){
        mu=4*mu/3
      }
      res$mu=mu
      res$L<-L
      res$beta=beta
      res$sigma=sigma
      res$rho=rho
      if(!LH_opt){
      res$N<-get('Big_Xi', envir=test.env)
      }

  }
  if(NC>1){
    res <- list();
    LH=0



    for(chr in 1:NC){


      if(!LH_opt){
        test=Build_zip_Matrix_mailund(Q[[chr]],g[[chr]],Os[[chr]][[1]][[2]],nu[[chr]],do_all=F)
      }else{
        test=Build_zip_Matrix_LH_mailund(Q[[chr]],g[[chr]],Os[[chr]][[1]][[2]],nu[[chr]])
      }

      for(i in 1:length(Os[[chr]])){
        fo=forward_zip_mailund(Os[[chr]][[i]][[1]],g[[chr]],nu[[chr]],test[[1]])
        LH=LH+(sum(fo[[2]]))
      }
      Q[[chr]]=t(Q[[chr]])
    }
    res <- list();
    res$LH=LH
    res$Tc=builder[[1]][[4]]

    res$L<-L


    rho_=list()
    rho=list()
    for(chr in 1:NC){
      rho_[[chr]]=oldrho[[chr]]*sum(Boxr)
      rho_[[chr]]=rho_[[chr]]-(Boxr[1])
      rho_[[chr]]=10^(rho_[[chr]])
      rho_[[chr]]=rho_[[chr]]*Rho[chr]
      rho[[chr]]=vector()
      xx=0
      for(ix in 1:Klink){
        x=xx+1
        xx = xx + pop_vect[ix]
        rho[[chr]][x:xx]=rho_[[chr]][ix]/(2*L[chr])
      }
    }


    if(SB>0){
      if(SB<3){
        beta_=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1] )^2
      }else{
        if(oldtb==1){
          beta_=((oldbeta*(BoxB_2[2]-BoxB_2[1]))+BoxB_2[1] )^2
        }else{
          if(oldtb>Klink){
            beta_=((oldbeta*(BoxB_1[2]-BoxB_1[1]))+BoxB_1[1] )^2
          }else{
            beta_= c( ((oldbeta[1:(oldtb-1)]*(BoxB_1[2]-BoxB_1[1]))+BoxB_1[1] )^2 , ((oldbeta[oldtb:Klink]*(BoxB_2[2]-BoxB_2[1]))+BoxB_2[1] )^2 )
          }
        }


      }

      beta=vector()
      xx=0
      for(ix in 1:Klink){
        x=xx+1
        xx = xx + pop_vect[ix]
        beta[x:xx]=beta_[ix]
      }
    }
    if(SF>0){
      if(SF<3){
        sigma_=oldsigma*(Boxs[2]-Boxs[1])
        sigma_=sigma_+Boxs[1]
      }else{
        if(oldts==1){
          sigma_=oldsigma*(Boxs_2[2]-Boxs_2[1])
          sigma_=sigma_+Boxs_2[1]
        }else{
          if(oldts>Klink){
            sigma_=oldsigma*(Boxs_1[2]-Boxs_1[1])
            sigma_=sigma_+Boxs_1[1]
          }else{

            sigma_= c(oldsigma[1:(oldts-1)]*(Boxs_1[2]-Boxs_1[1]) ,oldsigma[oldts:Klink]*(Boxs_2[2]-Boxs_2[1]) )
            sigma_= c( (sigma_[1:(oldts-1)]+Boxs_1[1]) , (sigma_[oldts:Klink]+Boxs_2[1]))
          }
        }
      }


      sigma=vector()
      xx=0
      for(ix in 1:Klink){
        x=xx+1
        xx = xx + pop_vect[ix]
        sigma[x:xx]= sigma_[ix]
      }
    }
    if(!Popfix){
      res$Xi=Xi_
    }else{
      res$Xi=rep(1,k)
    }
    res$beta=beta
    res$sigma=sigma
    res$rho=rho

    if(FS){
      mu=4*mu/3
    }
    res$mu=mu
    if(!LH_opt){
    res$N<-get('Big_Xi', envir=test.env)
    }
  }
  return(res)
}
