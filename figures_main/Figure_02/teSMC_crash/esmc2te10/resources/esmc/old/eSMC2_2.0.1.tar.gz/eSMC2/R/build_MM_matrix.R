#' Build requirement to define the hidden markov model
#'
#' Build the hidden states, expected coalescent times, equilibrium propabilities,and transition matrices for MSMC
#' @param n : number of  hidden states
#' @param rho : recombination rate per sequence
#' @param L : sequence length
#' @param Pop : True if population size is assumed constant
#' @param Xi : vector of scaling value for population size
#' @param scale : vector containing as first value a numeric value to rescale hidden states and as second a numeric value to shift the time windows of hidden states
#' @param M_a : number of haplotype used for the model
#' @param beta : germination rate
#' @param Beta : germination rate to build hidden states
#' @param sigma : self-fertilization rate
#' @param Sigma : self-fertilization rate to build hidden states
#' @return List of size four containing respectively, transition matrix, equilibrium probabilities, expected coalescent time and hidden states.
build_MM_matrix<-function(n=20,rho,L,Pop=T,Xi=NA,scale=c(1,0),M_a=3,beta=1,Beta=1,sigma=0,Sigma=0){
  Vect=0:(n-1)
  if(Pop){
    Xi=rep(1,n)
  }
  extra_l=M_a*(M_a-1)*0.5
  Tc= scale[2] -(0.5*(2-Sigma)*log(1-(Vect/n))/(extra_l*(Beta^2)*scale[1]))
  t=numeric(n)
  q=numeric(extra_l*n)
  r=rho/(2*(L-1))
  D=Tc[2:n]-Tc[1:(n-1)]
  first_pos=seq(1,(n*extra_l),n)
  last_pos=seq(n,(n*extra_l),n)
  t[1:(n-1)]=(Xi[1:(n-1)]*(2-sigma)/(beta*beta*2*extra_l))+ (Tc[1:(n-1)]-(Tc[2:n]*(exp(-beta*beta*extra_l*(D[1:(n-1)]/Xi[1:(n-1)])*2/(2-sigma)))))/(1-exp(-beta*beta*extra_l*((D[1:(n-1)])/Xi[1:(n-1)])*2/(2-sigma)))
  t[n]=(Xi[n]*(2-sigma)/(beta*beta*2*extra_l))+Tc[n]
   q[first_pos]=(1-exp(-D[1]*2*beta*beta*extra_l/(Xi[1]*(2-sigma))))/extra_l
  for(alpha in 2:(n-1)){q[seq(alpha,(n*extra_l),n)]=exp(-(2*beta*beta*extra_l/(2-sigma))*sum(D[1:(alpha-1)]/Xi[1:(alpha-1)]))*(1-exp(-D[alpha]*2*beta*beta*extra_l/(Xi[alpha]*(2-sigma))))/extra_l}
  q[last_pos]=exp(-(2*beta*beta*extra_l/(2-sigma))*sum(D[1:(n-1)]/Xi[1:(n-1)]))/extra_l
  Q=matrix(0,ncol =(extra_l*n), nrow = (extra_l*n))
  for(i in 1:(n-1)){
    if(i==1){
      for(ii in first_pos){
        for(jj in 1:extra_l){
        yy=(2:n)+(n*(jj-1))
        Q[ii,yy]=(1-exp(-M_a*r*t[(2:n)]*beta*2*(1-sigma)/(2-sigma)))*(2/(M_a*M_a*t[(2:n)]))*( D[1]-((1-exp(-D[1]*beta*beta*2*M_a/(Xi[1]*(2-sigma))))/(2*M_a*beta*beta/(Xi[1]*(2-sigma)))))
        }
      }
    }
    if(i==2){
      eta=1
      truc= ((1-exp(-D[eta]*beta*beta*2*M_a/(Xi[eta]*(2-sigma))))/((2*M_a*beta*beta)/(Xi[eta]*(2-sigma))))
      truc=truc*(1-exp(-D[i]*beta*beta*2*M_a/(Xi[i]*(2-sigma))))
      for(ii in seq(i,(n*extra_l),n)){
        for(jj in 1:extra_l){
          yy=((i+1):n)+(n*(jj-1))
          Q[ii,yy]=(1-exp(-M_a*r*t[((i+1):n)]*beta*2*(1-sigma)/(2-sigma)))*(2/(M_a*M_a*t[((i+1):n)]))*( truc + (D[i]-((1-exp(-D[i]*beta*beta*2*M_a/(Xi[i]*(2-sigma))))/(2*M_a*beta*beta/(Xi[i]*(2-sigma))))))
          Q[ii,first_pos]=(1-exp(-M_a*r*t[1]*beta*2*(1-sigma)/(2-sigma)))*(2/(M_a*extra_l*t[1]))*exp((t[1]-Tc[2])*beta*beta*2*extra_l/(Xi[1]*(2-sigma)))*(1-exp(-D[2]*beta*beta*2*extra_l/(Xi[2]*(2-sigma))))*(((1-exp(-t[1]*2*M_a*beta*beta/(Xi[1]*(2-sigma))))/(2*M_a*beta*beta/(Xi[1]*(2-sigma)))))
        }
      }
    }
    if( i>2){
      truc=0
      for(eta in 1:(i-2)){
        truc= truc+ ((( exp(-2*M_a*beta*beta*sum(D[(eta+1):(i-1)]/(Xi[(eta+1):(i-1)]*(2-sigma))))*(1-exp(-D[eta]*beta*beta*2*M_a/(Xi[eta]*(2-sigma))))/((2*M_a*beta*beta)/(Xi[eta]*(2-sigma))))))
      }
      eta=i-1
      truc= truc+ ((((1-exp(-D[eta]*beta*beta*2*M_a/(Xi[eta]*(2-sigma))))/((2*M_a*beta*beta)/(Xi[eta]*(2-sigma))))))
      truc=truc*(1-exp(-D[i]*beta*beta*2*M_a/(Xi[i]*(2-sigma))))
      for(ii in seq(i,(n*extra_l),n)){
        for(jj in 1:extra_l){
          yy=((i+1):n)+(n*(jj-1))
          Q[ii,yy]=(1-exp(-M_a*r*t[((i+1):n)]*beta*2*(1-sigma)/(2-sigma)))*(2/(M_a*M_a*t[((i+1):n)]))*( truc + ((D[i]-((1-exp(-D[i]*beta*beta*2*M_a/(Xi[i]*(2-sigma))))/(2*M_a*beta*beta/(Xi[i]*(2-sigma)))))))
        }
      }
      truc=rep(0,length(1:(i-1)))
      exp_truc=rep(0,length(1:(i-1)))
      for(gamma in 1:(i-1)){
        if(gamma<(i-1)){
          exp_truc[gamma]=exp(-beta*beta*2*extra_l*(sum(D[(gamma+1):(i-1)]/(Xi[(gamma+1):(i-1)]*(2-sigma)))+((Tc[gamma+1]-t[gamma])/(Xi[gamma]*(2-sigma)))))
        }
        if(gamma==(i-1)){
          exp_truc[gamma]=exp(-beta*beta*2*extra_l*(((Tc[gamma+1]-t[gamma])/(Xi[gamma]*(2-sigma)))))
        }
        if(gamma>2){
          sub_truc=0
          for(eta in 1:(gamma-2)){
            sub_truc=sub_truc+(((1-exp(-D[eta]*2*M_a*beta*beta/(Xi[eta]*(2-sigma))))/(2*M_a*beta*beta/(Xi[eta]*(2-sigma))))*exp(-2*M_a*beta*beta*(sum(D[(eta+1):(gamma-1)]/(Xi[(eta+1):(gamma-1)]*(2-sigma)))+((t[gamma]-Tc[gamma])/(Xi[gamma]*(2-sigma))))))
          }
          eta=gamma-1
          sub_truc=sub_truc+(((1-exp(-D[eta]*2*M_a*beta*beta/(Xi[eta]*(2-sigma))))/(2*M_a*beta*beta/(Xi[eta]*(2-sigma))))*exp(-2*M_a*beta*beta*(((t[gamma]-Tc[gamma])/(Xi[gamma]*(2-sigma))))))
          truc[gamma]=sub_truc+( (1-exp((Tc[gamma]-t[gamma])*2*M_a*beta*beta/(Xi[gamma]*(2-sigma))))/(2*M_a*beta*beta/(Xi[gamma]*(2-sigma))))
        }
        if(gamma==2){
          sub_truc=0
          eta=1
          sub_truc=sub_truc+(((1-exp(-D[eta]*2*M_a*beta*beta/(Xi[eta]*(2-sigma))))/(2*M_a*beta*beta/(Xi[eta]*(2-sigma))))*exp(-2*M_a*beta*beta*((t[gamma]-Tc[gamma])/(Xi[gamma]*(2-sigma)))))
          truc[gamma]=sub_truc+( (1-exp((Tc[gamma]-t[gamma])*2*M_a*beta*beta/(Xi[gamma]*(2-sigma))))/(2*M_a*beta*beta/(Xi[gamma]*(2-sigma))))
        }
        if(gamma==1){
          truc[gamma]=((1-exp((Tc[gamma]-t[gamma])*2*M_a*beta*beta/(Xi[gamma]*(2-sigma))))/(2*M_a*beta*beta/(Xi[gamma]*(2-sigma))))
        }
      }
      for(ii in seq(i,(n*extra_l),n)){
        for(jj in 1:extra_l){
          yy=(1:(i-1))+(n*(jj-1))
          Q[ii,yy]=(1-exp(-M_a*r*t[(1:(i-1))]*beta*2*(1-sigma)/(2-sigma)))*(2/(M_a*extra_l*t[(1:(i-1))]))*(1-exp(-D[i]*beta*beta*2*extra_l/(Xi[i]*(2-sigma))))*exp_truc*truc
        }
      }
      

    }
  }
  truc=rep(0,length(1:(n-1)))
  exp_truc=rep(0,length(1:(n-1)))
  for(gamma in 1:(n-1)){
    if(gamma<(n-1)){
      exp_truc[gamma]=exp(-beta*beta*2*extra_l*( sum(D[(gamma+1):(n-1)]/(Xi[(gamma+1):(n-1)]*(2-sigma)) ) + ((Tc[gamma+1]-t[gamma])/(Xi[gamma]*(2-sigma)))))
    }
    if(gamma==(n-1)){
      exp_truc[gamma]=exp(-beta*beta*2*extra_l*(((Tc[gamma+1]-t[gamma])/(Xi[gamma]*(2-sigma)))))
    }
    if(gamma>2){
      sub_truc=0
      for(eta in 1:(gamma-2)){
        sub_truc=sub_truc+(((1-exp(-D[eta]*2*M_a*beta*beta/(Xi[eta]*(2-sigma))))/(2*M_a*beta*beta/(Xi[eta]*(2-sigma))))*exp(-2*M_a*beta*beta*(sum(D[(eta+1):(gamma-1)]/(Xi[(eta+1):(gamma-1)]*(2-sigma))) + ((t[gamma]-Tc[gamma])/(Xi[gamma]*(2-sigma))))))
      }
      eta=gamma-1
      sub_truc=sub_truc+(((1-exp(-D[eta]*2*M_a*beta*beta/(Xi[eta]*(2-sigma))))/(2*M_a*beta*beta/(Xi[eta]*(2-sigma))))*exp(-2*M_a*beta*beta*(((t[gamma]-Tc[gamma])/(Xi[gamma]*(2-sigma))))))
      truc[gamma]=sub_truc+( (1-exp((Tc[gamma]-t[gamma])*2*M_a*beta*beta/(Xi[gamma]*(2-sigma))))/(2*M_a*beta*beta/(Xi[gamma]*(2-sigma))))
    }
    if(gamma==2){
      sub_truc=0
      eta=1
      sub_truc=sub_truc+(( (1-exp(-D[eta]*2*M_a*beta*beta/(Xi[eta]*(2-sigma))))/(2*M_a*beta*beta/(Xi[eta]*(2-sigma))))*exp(-2*M_a*beta*beta*(((t[gamma]-Tc[gamma])/(Xi[gamma]*(2-sigma))))))
      truc[gamma]=sub_truc+( (1-exp((Tc[gamma]-t[gamma])*2*M_a*beta*beta/(Xi[gamma]*(2-sigma))))/(2*M_a*beta*beta/(Xi[gamma]*(2-sigma))))
    }
    if(gamma==1){
      truc[gamma]=((1-exp((Tc[gamma]-t[gamma])*2*M_a*beta*beta/(Xi[gamma]*(2-sigma))))/(2*M_a*beta*beta/(Xi[gamma]*(2-sigma))))
    }
  }
  
  for(ii in last_pos){
    for(jj in 1:extra_l){
      yy=(1:(n-1))+(n*(jj-1))
      Q[ii,yy]=(1-exp(-M_a*r*t[(1:(n-1))]*beta*2*(1-sigma)/(2-sigma)))*(2/(M_a*extra_l*t[(1:(n-1))]))*exp_truc*truc
    }
  }
  diag(Q)=rep(1,(n*extra_l))-apply(Q,2,sum)
  output=list()
  output[[1]]=Q
  output[[2]]=q
  output[[3]]=t
  output[[4]]=Tc
  return(output)
}
