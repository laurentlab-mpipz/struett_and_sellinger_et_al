#' Check the distribution of SNPs along the genome. The less percentage of genome is masked, the more relevant the test is.
#'
#' @param data : Segregating matrix (output of Get_real_data)
#' @param window : Size of scaffold to analyze. We recommand to define a windown size large enough to have in average more than 50 SNPs expected per window but small enough to represent the SNPs density.^
#' @export
#' @return A list of size 2 containing the proportions of scaffolds of size time window with more SNPs than {0.2,0.5,1,2,5} times than what expected. The second list contains the positions of those regions (in bp unit of the window).
check_distri_data<-function(data,window=10^4){
  output=list()
  mu=dim(data)[2]/(sum(as.numeric(data[3,])))
  seq=seqSNP2_MH(data,as.numeric(data[4,dim(data)[2]]),10^6)
  rm(data)
  seq=seq$seq
  seq[which(seq==2)]=0

  d=numeric(floor(length(seq)/window))
  for(kk in 1:length(d)){
    d[kk]=sum(seq[(((kk-1)*window)+1):min(kk*window,length(seq))])
  }
  rm(seq)

  p=c()
  pos=list()
  for(scale in c(0.2,0.5,1,2,5)){
    truc=which(d>(mu*scale*window))
    p=c(p,length(truc))
    pos[[(length(pos)+1)]]=truc
  }
  p=p/(length(d))
  output$p=p
  output$pos=pos
  return(output)
}
