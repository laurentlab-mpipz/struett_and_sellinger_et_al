#' get the genealogy of a simulation in the newick format
#'
#' @param file : path to the .txt file
#' @param M : number of simulated sequences
#' @param mut : TRUE if mutation were simulated
#' @export
#' @return list of size 3 containing matrices describing genealogy. First and second list object contain index of coalescing individual, first coalescent event being in last line and  each column is a different genealogy. Last object sequence length of genealogy on last line and coalescent times on others lines (starting at line M-1)
get_genealogy<-function(file,M,mut=F){
  data=Get_data(file,heavy = T)

  Output=list()
  coal_time=matrix(0,nrow = (M), ncol= (length(data)))
  id_split=matrix(0,nrow = (M-1), ncol= (length(data)))
  id_create=matrix(0,nrow = (M-1), ncol= (length(data)))
  start=F
  end=F
  bonus=0
  for(i in 1:length(data)){

    if(length(substr(data[[i]],1,3))>0){
      if(start&mut&substr(data[[i]],1,3)[1]=="seg"){
        end=T
        coal_time=coal_time[,-c((i-start_i):(length(data)))]
        id_split=id_split[,-c((i-start_i):(length(data)))]
        id_create=id_create[,-c((i-start_i):(length(data)))]
      }
    }
    if(!end){
      if(start){
        genealogy=data[[i]]
        if(length(which(strsplit(genealogy,split = "")[[1]]=="]"))==1 & length(which(strsplit(genealogy,split = "")[[1]]=="["))==1){
          coal_time[M,(i-start_i+bonus)]=as.numeric(substr(genealogy,2,(gregexpr(genealogy,pattern = "]")[[1]][1]-1)))
          for(j in 1:(M-1)){
            for(xx in 1:length(as.numeric(gregexpr(genealogy,pattern = ")")[[1]]))){
              id1=max(as.numeric(gregexpr(genealogy,pattern = ",")[[1]])[which(as.numeric(gregexpr(genealogy,pattern = ",")[[1]])<as.numeric(gregexpr(genealogy,pattern = ")")[[1]][xx]))])
              if(xx==1){
                id_split[(M-j),(i-start_i+bonus)]=min(c(as.numeric(substr(genealogy,(gregexpr(genealogy,pattern = ":")[[1]][min(which(as.numeric(gregexpr(genealogy,pattern = ":")[[1]])>id1))]-1),(gregexpr(genealogy,pattern = ":")[[1]][min(which(as.numeric(gregexpr(genealogy,pattern = ":")[[1]])>id1))]-1))),as.numeric(substr(genealogy,(gregexpr(genealogy,pattern = ":")[[1]][max(which(as.numeric(gregexpr(genealogy,pattern = ":")[[1]])<id1))]-1),(gregexpr(genealogy,pattern = ":")[[1]][max(which(as.numeric(gregexpr(genealogy,pattern = ":")[[1]])<id1))]-1)))))
                id_create[(M-j),(i-start_i+bonus)]=max(c(as.numeric(substr(genealogy,(gregexpr(genealogy,pattern = ":")[[1]][min(which(as.numeric(gregexpr(genealogy,pattern = ":")[[1]])>id1))]-1),(gregexpr(genealogy,pattern = ":")[[1]][min(which(as.numeric(gregexpr(genealogy,pattern = ":")[[1]])>id1))]-1))),as.numeric(substr(genealogy,(gregexpr(genealogy,pattern = ":")[[1]][max(which(as.numeric(gregexpr(genealogy,pattern = ":")[[1]])<id1))]-1),(gregexpr(genealogy,pattern = ":")[[1]][max(which(as.numeric(gregexpr(genealogy,pattern = ":")[[1]])<id1))]-1)))))
                coal_time[(M-j),(i-start_i+bonus)]=2*as.numeric(substr(genealogy,(gregexpr(genealogy,pattern = ":")[[1]][max(which(as.numeric(gregexpr(genealogy,pattern = ":")[[1]])<id1))]+1),(id1-1)))
                x_k=xx
                id1_s=id1
              }
              if(xx>1){
                if(id1>as.numeric(gregexpr(genealogy,pattern = ")")[[1]][(xx-1)])){
                  if(substr(genealogy,(gregexpr(genealogy,pattern = ":")[[1]][max(which(as.numeric(gregexpr(genealogy,pattern = ":")[[1]])<id1))]-1),(gregexpr(genealogy,pattern = ":")[[1]][max(which(as.numeric(gregexpr(genealogy,pattern = ":")[[1]])<id1))]-1))!=")"){
                    if(as.numeric(substr(genealogy,(gregexpr(genealogy,pattern = ":")[[1]][max(which(as.numeric(gregexpr(genealogy,pattern = ":")[[1]])<id1))]+1),(id1-1)))<(0.5*coal_time[(M-j),(i-start_i+bonus)])){
                      id_split[(M-j),(i-start_i+bonus)]=min(c(as.numeric(substr(genealogy,(gregexpr(genealogy,pattern = ":")[[1]][min(which(as.numeric(gregexpr(genealogy,pattern = ":")[[1]])>id1))]-1),(gregexpr(genealogy,pattern = ":")[[1]][min(which(as.numeric(gregexpr(genealogy,pattern = ":")[[1]])>id1))]-1))),as.numeric(substr(genealogy,(gregexpr(genealogy,pattern = ":")[[1]][max(which(as.numeric(gregexpr(genealogy,pattern = ":")[[1]])<id1))]-1),(gregexpr(genealogy,pattern = ":")[[1]][max(which(as.numeric(gregexpr(genealogy,pattern = ":")[[1]])<id1))]-1)))))
                      id_create[(M-j),(i-start_i+bonus)]=max(c(as.numeric(substr(genealogy,(gregexpr(genealogy,pattern = ":")[[1]][min(which(as.numeric(gregexpr(genealogy,pattern = ":")[[1]])>id1))]-1),(gregexpr(genealogy,pattern = ":")[[1]][min(which(as.numeric(gregexpr(genealogy,pattern = ":")[[1]])>id1))]-1))),as.numeric(substr(genealogy,(gregexpr(genealogy,pattern = ":")[[1]][max(which(as.numeric(gregexpr(genealogy,pattern = ":")[[1]])<id1))]-1),(gregexpr(genealogy,pattern = ":")[[1]][max(which(as.numeric(gregexpr(genealogy,pattern = ":")[[1]])<id1))]-1)))))
                      coal_time[(M-j),(i-start_i+bonus)]=2*as.numeric(substr(genealogy,(gregexpr(genealogy,pattern = ":")[[1]][max(which(as.numeric(gregexpr(genealogy,pattern = ":")[[1]])<id1))]+1),(id1-1)))
                      x_k=xx
                      id1_s=id1
                    }
                  }

                }
              }

            }
            if(j<(M-1)){
              pos_e=c()
              if(x_k<xx){
                pos_e=c(pos_e,as.numeric((gregexpr(genealogy,pattern = ")")[[1]][x_k+1]-1)))
              }

              if(!is.na(as.numeric((gregexpr(genealogy,pattern = ",")[[1]][min(na.rm =T,which(as.numeric(gregexpr(genealogy,pattern = ",")[[1]])>as.numeric(gregexpr(genealogy,pattern = ")")[[1]][x_k])))])))){
                pos_e=c(pos_e,(as.numeric((gregexpr(genealogy,pattern = ",")[[1]][min(na.rm =T,which(as.numeric(gregexpr(genealogy,pattern = ",")[[1]])>as.numeric(gregexpr(genealogy,pattern = ")")[[1]][x_k])))]))-1))
              }
              pos_e=min(pos_e)
              time=(0.5*coal_time[(M-j),(i-start_i+bonus)])+as.numeric(substr(genealogy,(gregexpr(genealogy,pattern = ")")[[1]][x_k]+2),pos_e))
              new_ind=paste(id_split[(M-j),(i-start_i+bonus)],":",time,sep="")
              genealogy=paste(substr(genealogy,1,as.numeric(gregexpr(genealogy,pattern = ":")[[1]][max(which(as.numeric(gregexpr(genealogy,pattern = ":")[[1]])<id1_s))]-3)),new_ind,substr(genealogy,(pos_e+1),nchar(genealogy)),sep = "")
            }

          }
        }else{
          stop('Problem in data')
        }



      }
      if(length(data[[i]])>0){
        if(data[[i]]=="//"){
          start=TRUE
          start_i=i
        }
      }
    }



  }
  Output$Coal_time=coal_time
  Output$id_split=id_split
  Output$id_create=id_create
  return(Output)
}
