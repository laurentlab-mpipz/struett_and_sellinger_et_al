#' Build the exact transition matrix from sequence of genealogy 
#'
#' Runs the eSMC to estimate demographic history and ecological parameters
#' @param genealogy : Matrix of sequence of genealogy (output of get_first_coal_time)
#' @param Tc : numerical vector containing the discretization of time
#' @param M_a : number of haplotype used for model
#' @export
#' @return a square matrix of size TC counting the transition event
build_N_MM<-function(genealogy,Tc,M_a=3){
  Output=matrix(0,ncol=(length(Tc)*M_a*(M_a-1)*0.5),nrow=(length(Tc)*M_a*(M_a-1)*0.5))

  count_L=0
  for(i in 1:dim(genealogy)[2]){
    id=genealogy[1:2,i]
    index=find_index(id,M=M_a)
    state=max(which(Tc<genealogy[3,i]))+((length(Tc)*(index-1)))
    if(i==1){
      former_state=state
      length_seq=genealogy[4,i]
      if(length_seq>1){
       # Output[former_state,state]=Output[former_state,state]+1
        #count_L=count_L+1
        former_state=state
        Output[former_state,state]=Output[former_state,state]+(length_seq-1)
        count_L=count_L+(length_seq-1)
      }
    }else{
      length_seq=genealogy[4,i]
      if(length_seq>1){
        Output[former_state,state]=Output[former_state,state]+1
        count_L=count_L+1
        former_state=state
        Output[former_state,state]=Output[former_state,state]+(length_seq-1)
        count_L=count_L+(length_seq-1)
      }else{ 
        Output[former_state,state]=Output[former_state,state]+1
        former_state=state
        count_L=count_L+1
      }
    }
  }
  return(Output)
}
