#' Build signal for the model
#'
#' @param DNA : matrix of segregating sites for the whole sample
#' @param n : sequence length
#' @param position_removed : list containingvectors of size 2 indicating begining and end positions to remove from the sequence.
#' @param mask_island : number of masked position in a row, 1 will give best results but slow algorithm, 0 to put all missing position in a row (fast).
#' @return : sequence of 0 and 1 (1 mutation, 0 no mutation)
seqSNP2_MH<-function(DNA,n,position_removed=NA,mask_island=0){
  output=list()
  DNA=as.matrix(DNA)
  pos=which(DNA[1,]!=DNA[2,])

  theta=length(pos)

  if(!is.na(position_removed)){
    position_to_be_removed=numeric()
    for(ii in 1:length(position_removed)){
      position_to_be_removed=c( position_to_be_removed,c(position_removed[[ii]][1]:position_removed[[ii]][2]))
    }
    position_removed=position_to_be_removed
    rm(position_to_be_removed)
  }

  if(mask_island>0){
  seq=rep(0,n)
  seq[as.numeric(DNA[4,pos])]=1
  mask_vector=(as.numeric(DNA[4,-1])-as.numeric(DNA[4,-dim(DNA)[2]]))-as.numeric(DNA[3,-1])
  masked_pos=which(mask_vector>0)+1
  if(length(masked_pos)>0){
    for(cc in c(1,masked_pos)){
      if(cc==1){
        if(as.numeric(DNA[3,cc])<(as.numeric(DNA[4,cc])-1)){
          masked_number=as.numeric(DNA[4,cc])-as.numeric(DNA[3,cc])
          if(mask_island==1){
            seq[sample(c(1:(as.numeric(DNA[4,1])-1)),masked_number)]=2
          }else{

            if(masked_number>mask_island){
              nb_island=floor(masked_number/mask_island)
              pos_island=sample(1:floor((as.numeric(DNA[4,1])-1)/mask_island),nb_island)
              for(ppp in pos_island){
                seq[(1+((ppp-1)*mask_island)):(ppp*mask_island)]=2
              }

            }else{
              seq[1:masked_number]=2
            }

          }


        }
        if(any(is.na(seq))){
          browser()
        }
      }else{
        masked_number=mask_vector[(cc-1)]
        if(mask_island==1){
          seq[sample(c((as.numeric(DNA[4,(cc-1)])+1):(as.numeric(DNA[4,(cc)])-1)),masked_number)]=2
        }else{
          if(masked_number>mask_island){
            nb_island=floor(masked_number/mask_island)
            pos_island=sample(1:floor(((as.numeric(DNA[4,cc])-1)-(as.numeric(DNA[4,(cc-1)])+1))/mask_island),nb_island)
            for(ppp in pos_island){
              seq[((as.numeric(DNA[4,(cc-1)])+1)+((ppp-1)*mask_island)):((as.numeric(DNA[4,(cc-1)]))+(ppp*mask_island))]=2
            }
          }else{
            seq[(as.numeric(DNA[4,(cc-1)])+1):(as.numeric(DNA[4,(cc-1)])+masked_number)]=2
          }

        }




        if(any(is.na(seq))){
          browser()
        }
      }

    }
  }
  }else{
    seq=rep(2,n)
    seq[as.numeric(DNA[4,pos])]=1
    for(cc in 1:dim(DNA)[2]){
      if(cc==1){
        if(as.numeric(DNA[3,cc])>1){
          # seq[1:(as.numeric(DNA[3,cc])-1)]=0
          seq[as.numeric(sample(c(1:(as.numeric(DNA[4,cc])-1)),(as.numeric(DNA[3,cc])-1)))]=0
        }
      }else{
        if(as.numeric(DNA[3,(cc)])>1){
          # seq[(as.numeric(DNA[4,(cc-1)])+1):(as.numeric(DNA[4,(cc-1)])+(as.numeric(DNA[3,cc])-1))]=0
          seq[as.numeric(sample(c((as.numeric(DNA[4,(cc-1)])+1):(as.numeric(DNA[4,cc])-1)),(as.numeric(DNA[3,cc])-1)))]=0
        }
      }
    }
    seq=as.numeric(seq)
  }


  if(!is.na(position_removed)){
    seq[c(position_removed)]=2
    rm(position_removed)
  }

  n=length(which(as.numeric(seq)<2))
  theta=length(which(seq==1))/(n/length(seq))

  output$seq=as.numeric(seq)
  output$theta=as.numeric(theta)
  return(output)
}
