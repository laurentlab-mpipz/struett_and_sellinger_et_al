#' Build signal for SMCm
#'
#' @param file_methylation : VCF file with epimuation information information
#' @param position_masked :  list containing vectors of size 2 indicating begining and end positions to mask from the sequence (positions have to be sorted).
#' @param hap : TRUE if species/data is haploid
#' @export
#' @return : input data for SMCm
Merge_methylation_data<-function(file_methylation,position_masked=NA ,hap=F){
  epi_mat=list()
  check_methy_data<-function(data){
    M=dim(data)[1]-1
    for(ii in 1:M){
      pos_0=which(as.character(data[ii,])=="0")
      if(length(pos_0)>0){
       data[ii,pos_0]="C"
      }
    }
    return(data)
  }
  for(name in 1:length(file_methylation)){
    epi_mat[[name]]=Process_methylome_data(file_methylation[name],hap)
  }


  if(hap){
    output=list()
    if(is.list(epi_mat[[1]])){
      nchr=length(epi_mat[[1]])
    }else{
      nchr=1
    }
    print("nb chr:")
    print(nchr)
    if(nchr==1){
      for(name in 1:length(file_methylation)){
       epi_mat[[name]]=list(epi_mat[[name]])
      }
    }
    for(chr in 1:nchr){
      print("chr:")
      print(chr)
      for (name in 1:length(file_methylation)){

        if(name==1){

            new_mat=matrix(0,ncol=length(epi_mat[[name]][[chr]][2,]),nrow=(length(file_methylation)+1))
            new_mat[dim(new_mat)[1],]=epi_mat[[name]][[chr]][2,]

            new_mat[name,]=epi_mat[[name]][[chr]][1,]
            output[[chr]]=new_mat

            output[[chr]]= output[[chr]][,order(as.numeric(output[[chr]][dim( output[[chr]])[1],]))]

        }else{



          #putting epimutations
          old_pos=which(epi_mat[[name]][[chr]][2,]%in%output[[chr]][dim(output[[chr]])[1],])
          old_pos_r=which(output[[chr]][dim(output[[chr]])[1],]%in%epi_mat[[name]][[chr]][2,])
          DO=F
          if(length(old_pos)>0){
            output[[chr]][name,old_pos_r]=epi_mat[[name]][[chr]][1,old_pos]
            if(length(old_pos)<(dim(epi_mat[[name]][[chr]])[2]-1)){
              DO=T
            }
            epi_mat[[name]][[chr]]=epi_mat[[name]][[chr]][,-old_pos]

          }
          if(DO){
            new_mat=matrix(0,ncol=dim(epi_mat[[name]][[chr]])[2],nrow=dim(output[[chr]])[1])
            new_mat[dim(new_mat)[1],]=epi_mat[[name]][[chr]][2,]
            new_mat[name,]=epi_mat[[name]][[chr]][1,]
            output[[chr]]=cbind(output[[chr]],new_mat)
          }
          output[[chr]]= output[[chr]][,order(as.numeric(output[[chr]][dim( output[[chr]])[1],]))]

        }
      }
      output[[chr]]=check_methy_data(output[[chr]])
      output[[chr]]=rbind(output[[chr]][-dim(output[[chr]])[1],], as.numeric(output[[chr]][dim(output[[chr]])[1],])-c(1,as.numeric(output[[chr]][dim(output[[chr]])[1],-dim(output[[chr]])[2]])),as.numeric(output[[chr]][dim(output[[chr]])[1],]))
    }


  }else{

  }


  if(!is.na(position_masked)){
    for(ccc in 1:length(position_masked)){
      if(as.numeric(position_masked[[ccc]][1])<as.numeric(output[[chr]][dim(output[[chr]])[1],1])){

        if(as.numeric(position_masked[[ccc]][2])>as.numeric(output[[chr]][dim(output[[chr]])[1],dim(output[[chr]])[2]])){
          stop('All sequence is masked :/')
        }else{
          p_2=min(which(output[[chr]][dim(output[[chr]])[1],]>position_masked[[ccc]][2]))
          output[[chr]][(dim(output[[chr]])[1]-1),p_2]=as.numeric(output[[chr]][(dim(output[[chr]])[1]),p_2])-as.numeric(position_masked[[ccc]][2])
          if(p_2>1){
            output[[chr]]=output[[chr]][,-c(1:(p_2-1))]
          }
        }
      }else{
        p_1=max(which(output[[chr]][dim(output[[chr]])[1],]<position_masked[[ccc]][1]))
        if(as.numeric(position_masked[[ccc]][2])>as.numeric(output[[chr]][dim(output[[chr]])[1],dim(output[[chr]])[2]])){
          output[[chr]]=output[[chr]][,-c(p_1:(dim(output[[chr]])[2]))]
        }else{
          p_2=min(which(output[[chr]][dim(output[[chr]])[1],]>position_masked[[ccc]][2]))
          output[[chr]][(dim(output[[chr]])[1]-1),p_2]=as.numeric(output[[chr]][(dim(output[[chr]])[1]),p_2])-as.numeric(position_masked[[ccc]][2])+as.numeric(position_masked[[ccc]][1])-as.numeric(output[[chr]][(dim(output[[chr]])[1]),p_1])
          if(p_2==(p_1+1)){
            output[[chr]]=output[[chr]][,-(p_1+1)]
          }else{
            if(p_2>(p_1+2)){
              output[[chr]]=output[[chr]][,-c((p_1+1):(p_2-1))]
            }
          }

        }

      }



    }
  }


  return(output)
}
