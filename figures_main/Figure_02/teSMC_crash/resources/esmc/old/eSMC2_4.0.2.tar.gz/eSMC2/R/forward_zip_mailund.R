#'  Forward alagorithm
#'
#'Runs the forward alagorithm on a zipped sequences
#' @param Os : zip signal
#' @param E : emission matrix
#' @param q : equilibrium probability
#' @param  C : matrix for the zip signal
#' @return A 3 object list. First object is the result from the forward algorithm. Second is the vector containing used values for the rescaling of the forward algorithm. Third is the sum this vector.
forward_zip_mailund <- function(Os,E,q,C){
  Os=as.numeric(as.vector(Os))
  T_prime=length(Os)
  output=list()
  alpha=matrix(0,ncol=T_prime,nrow=length(q))
  d=numeric(length = T_prime)
  alpha[,1]=diag(x=E[,(1+as.numeric(Os[1]))])%*%q
  d_n=sum(alpha[,1])
  alpha[,1]=alpha[,1]/sum(alpha[,1])
  d[1]=log(d_n)
  explore=2:T_prime
  for(i in explore){
    if(as.numeric(Os[i])<10){
      truc=C[[(1+as.numeric(Os[i]))]]%*%alpha[,(i-1)]
    }else{
      truc=C[[(as.numeric(Os[i]))]]%*%alpha[,(i-1)]
    }
    dn=sum(truc)
    alpha[,i]=truc/dn
    d[i]=log(dn)

  }

  output[[1]]=alpha
  output[[2]]=d
  output[[3]]=(sum(d))

  return(output)
}
