#'  Unzip a zipped sequence
#'
#' @param Os : Zipped signal
#' @return numeric vector of the original zipped sequence
Unzip_2seq<-function(Os){
  mat_symbol=Os[[2]]
  Os=Os[[1]]
  for(i in seq(dim(mat_symbol)[1],1,-1)){
    symbol=mat_symbol[i,1]
    pos=which(Os%in%symbol)
    Os[pos]=mat_symbol[i,2]
    Os=paste(Os,collapse = "")
    Os=strsplit(Os,"")
    Os=as.matrix(Os[[1]])
  }
  return(Os)
}
