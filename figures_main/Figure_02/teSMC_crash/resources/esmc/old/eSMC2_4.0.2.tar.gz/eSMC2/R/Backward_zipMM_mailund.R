#' Backward alagorithm
#'
#'Runs the Backward alagorithm of SMBC on a zipped sequences
#' @param y : zip signal
#' @param TO : matrix for the zip signal
#' @param n : number of  hidden states
#' @param c : vector of rescaling outputed by the forward algorihtm
#' @param TS_SNP : Vector of SNPs
#' @param max_count : max number of zipped symbol
#' @param M_a : Number of simultaneously analyzed sequences
#' @return Matrix result from the Backward algorithm.
Backward_zipMM_mailund<-function(y,TO,n,c,TS_SNP,max_count,M_a){
  dims <- dim(TO[[1]][[1]])[1];
  n<- length(y);
  count_SNP=length(TS_SNP)
  beta <- matrix(1, nrow=dims[1], ncol=n);
  if(M_a==3){
    yy=5
  }
  if(M_a==4){
    yy=9
  }
  if(length(y)>1){
    for (t in seq(n-1, 1, -1)){

      if(as.numeric(y[(t+1)])>9){
        beta[,t] = (TO[[(ceiling((as.numeric(y[(t+1)])-9)/max_count))]][[(-9+yy+as.numeric(y[(t+1)])-((ceiling((as.numeric(y[(t+1)])-9)/max_count)-1)*max_count))]]%*% beta[, (t+1)] )/ c[t+1];
      }

      if(as.numeric(y[(t+1)])<0){
        beta[,t] = (TO[[abs(as.numeric(y[(t+1)]))]][[1]] %*% beta[, (t+1)] )/ c[t+1];
      }

      if(as.numeric(y[(t+1)])>0&as.numeric(y[(t+1)])<9){
        beta[,t] = (TO[[TS_SNP[(count_SNP)]]][[(1+as.numeric(y[(t+1)]))]] %*% beta[, (t+1)] )/ c[t+1];
        count_SNP=count_SNP-1
      }
    }
  }
  if(length(y)==1){
    t=1
    if(as.numeric(y[(t+1)])>9){
      beta[,t] = (TO[[(ceiling((as.numeric(y[(t+1)])-9)/max_count))]][[(-9+yy+as.numeric(y[(t+1)])-((ceiling((as.numeric(y[(t+1)])-9)/max_count)-1)*max_count))]]%*% beta[, (t+1)] )/ c[t+1];
    }

    if(as.numeric(y[(t+1)])<0){
      beta[,t] = (TO[[abs(as.numeric(y[(t+1)]))]][[1]] %*% beta[, (t+1)] )/ c[t+1];
    }

    if(as.numeric(y[(t+1)])>0&as.numeric(y[(t+1)])<9){
      beta[,t] = (TO[[TS_SNP[(count_SNP)]]][[(1+as.numeric(y[(t+1)]))]] %*% beta[, (t+1)] )/ c[t+1];
      count_SNP=count_SNP-1
    }

  }
  return(beta);

}
