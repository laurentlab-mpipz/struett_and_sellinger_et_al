#' Reads a vcf file
#'
#' @param path : location of the vcf file
#' @return A list containing all lines of the vcf file
Get_vcf_data<-function(path){
  DNAseqfile=list()
  count_DNA=0
  con = file(path, "r")
  while ( TRUE ) {
    count_DNA= count_DNA+1
    line = readLines(con, n = 1)
    if ( length(line) == 0 ){
      break
    }
    DNAseqfile[[count_DNA]]=as.vector(unlist(strsplit(as.vector(line),"\t")))
  }
  close(con)
  return(DNAseqfile)
}
