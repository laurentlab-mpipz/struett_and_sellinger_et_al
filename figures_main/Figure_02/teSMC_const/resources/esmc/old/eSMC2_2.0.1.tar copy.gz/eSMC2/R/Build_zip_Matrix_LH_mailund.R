#'  Builds the HMM matrices of the new symbol
#'
#' Builds the HMM matrices to analysed the zip signal and calculate likelihood
#' @param A : Transition matrix
#' @param E : emission matrix
#' @param Mat_symbol : Symbol matrix with the zipping pattern
#' @param q : equilibrium probability
#' @return A : 4 object list with matrices to calculate likelihood of zipped sequences
Build_zip_Matrix_LH_mailund<-function(A,E,Mat_symbol,q){
C=list()
TO=list()
l=vector(length =(2+(dim(Mat_symbol)[1])))
Q=list()
Q_=list()
k=length(q)

for(i in 1:dim(E)[2]){
  B=diag(x=E[,i])
  C[[i]]=B%*%A
}
x=length(C)
for(i in 1:dim(Mat_symbol)[1]){
  sx=strsplit(Mat_symbol[i,2]," ")
  sx=as.numeric(as.matrix(sx[[1]]))
  a=sx[1]
  b=sx[2]

  C[[(x+i)]]=as.matrix(C[[(b+1)]])%*%as.matrix(C[[(a+1)]])
}
output=list()
output[[1]]=C


return(output)
}
