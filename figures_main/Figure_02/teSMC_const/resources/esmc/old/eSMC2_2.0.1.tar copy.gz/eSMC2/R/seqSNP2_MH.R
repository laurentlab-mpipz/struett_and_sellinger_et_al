#' Build signal for the model
#'
#' @param DNA : matrix of segregating sites for the whole sample
#' @param n : sequence length
#' @param mask_threshold : interger indicating the maximum size of continuous masked sequence, longer masked sequence will be removed.
#' @param position_removed : list containingvectors of size 2 indicating begining and end positions to remove from the sequence.
#' @param mask_island : number of masked position in a row, 1 will give best results but slow algorithm
#' @return : sequence of 0 and 1 (1 mutation, 0 no mutation)
seqSNP2_MH<-function(DNA,n,mask_threshold=NA,position_removed=NA,mask_island=10){
  output=list()
  if(is.na(mask_threshold)){
    mask_threshold=as.numeric(n)
  }
  DNA=as.matrix(DNA)
  pos=which(DNA[1,]!=DNA[2,])
  seq=rep(2,n)
  seq[as.numeric(DNA[4,pos])]=1
  theta=length(pos)
  remove_pos=c()
  if(!is.na(position_removed)){
    for(ii in 1:length(position_removed)){
      position_removed=c( position_removed,c(position_removed[[ii]][1]:position_removed[[ii]][2]))
    }

  }
  for(cc in 1:dim(DNA)[2]){
    if(cc==1){
      if(as.numeric(DNA[3,cc])>1){
       # seq[1:(as.numeric(DNA[3,cc])-1)]=0
        if(mask_island>1){
          if(floor((as.numeric(DNA[3,cc])-1)/mask_island)>2){
            x=as.numeric(sample(c(0:(floor((as.numeric(DNA[4,cc])-1)/mask_island)-1)),(floor((as.numeric(DNA[3,cc])-1)/mask_island)-1)))
            x=as.numeric(sapply(x,function(x){(1+(x*mask_island)):(((x+1)*mask_island))}))
            if(length(as.numeric(unique(x)))<length(x)){
              browser()
            }
            if((floor((as.numeric(DNA[3,cc])-1)/mask_island)-1)*mask_island<(as.numeric(DNA[3,cc])-1)){
              y=c(1:(as.numeric(DNA[4,cc])-1))[-c(x)]
              if(length(y)>((as.numeric(DNA[3,cc])-1)-(floor((as.numeric(DNA[3,cc])-1)/mask_island)-1)*mask_island)){
                x=c(x,sample(y,((as.numeric(DNA[3,cc])-1)-(floor((as.numeric(DNA[3,cc])-1)/mask_island)-1)*mask_island)))
              }else{
                x=c(x,y)
              }

            }
            seq[as.numeric(unique(x))]=0
            if(length(as.numeric(unique(x)))<(as.numeric(DNA[3,cc])-1)){
              browser()
            }
          }else{
            seq[as.numeric(sample(c(1:(as.numeric(DNA[4,cc])-1)),(as.numeric(DNA[3,cc])-1)))]=0
            if(length(as.numeric(sample(c(1:(as.numeric(DNA[4,cc])-1)),(as.numeric(DNA[3,cc])-1))))<(as.numeric(DNA[3,cc])-1)){
              browser()
            }
          }

      }else{
        seq[as.numeric(sample(c(1:(as.numeric(DNA[4,cc])-1)),(as.numeric(DNA[3,cc])-1)))]=0
      }
      }
      if(length(seq[1:(as.numeric(DNA[4,(cc)]))])>mask_threshold){
        pos_mask=which(as.character(seq[1:(as.numeric(DNA[4,(cc)]))])=="2")
        if(length(pos_mask)>mask_threshold){
          remove_pos=c(remove_pos,pos_mask)
        }
      }
    }else{
      if(as.numeric(DNA[3,(cc)])>1){
        if(mask_island>1){
          if(floor((as.numeric(DNA[3,cc])-1)/mask_island)>2){
            x=as.numeric(sample(c(ceiling((as.numeric(DNA[4,(cc-1)])+1)/mask_island):(floor((as.numeric(DNA[4,cc])-1)/mask_island)-1)),(floor((as.numeric(DNA[3,cc])-1)/mask_island)-1)))
            x=as.numeric(sapply(x,function(x){((x*mask_island)):(((x+1)*mask_island)-1)}))
            if(length(as.numeric(unique(x)))<length(x)){
              browser()
            }
            if((floor((as.numeric(DNA[3,cc])-1)/mask_island)-1)*mask_island<(as.numeric(DNA[3,cc])-1)){
              ret=which(c((as.numeric(DNA[4,(cc-1)])+1):(as.numeric(DNA[4,cc])-1))%in%x)
              if(length(ret)>0){
                y=c((as.numeric(DNA[4,(cc-1)])+1):(as.numeric(DNA[4,cc])-1))[-ret]
              }else{
                y=c((as.numeric(DNA[4,(cc-1)])+1):(as.numeric(DNA[4,cc])-1))
              }

              if(length(y)>max(1,((as.numeric(DNA[3,cc])-1)-(floor((as.numeric(DNA[3,cc])-1)/mask_island)-1)*mask_island))){
              x=c(x,sample(y,((as.numeric(DNA[3,cc])-1)-(floor((as.numeric(DNA[3,cc])-1)/mask_island)-1)*mask_island)))
              }else{
                x=c(x,y)
              }
            }
            seq[as.numeric(unique(x))]=0
            if(length(as.numeric(unique(x)))<(as.numeric(DNA[3,cc])-1)){
              browser()
            }
          }else{
            seq[as.numeric(sample(c((as.numeric(DNA[4,(cc-1)])+1):(as.numeric(DNA[4,cc])-1)),(as.numeric(DNA[3,cc])-1)))]=0
            if(length(as.numeric(sample(c((as.numeric(DNA[4,(cc-1)])+1):(as.numeric(DNA[4,cc])-1)),(as.numeric(DNA[3,cc])-1))))<(as.numeric(DNA[3,cc])-1)){
              browser()
            }
          }
        }else{
          seq[as.numeric(sample(c((as.numeric(DNA[4,(cc-1)])+1):(as.numeric(DNA[4,cc])-1)),(as.numeric(DNA[3,cc])-1)))]=0
          if(length(as.numeric(sample(c((as.numeric(DNA[4,(cc-1)])+1):(as.numeric(DNA[4,cc])-1)),(as.numeric(DNA[3,cc])-1))))<(as.numeric(DNA[3,cc])-1)){
            browser()
          }
        }

      }
      pos_mask=which(as.character(seq[(as.numeric(DNA[4,(cc-1)])):(as.numeric(DNA[4,(cc)]))])=="2")
      if(length(pos_mask)>mask_threshold){
        pos_mask=pos_mask+as.numeric(DNA[4,(cc-1)])
        remove_pos=c(remove_pos,pos_mask)
      }
    }
  #  if(any(which(as.character(seq)=="0")%in%as.numeric(DNA[4,pos]))){
  #    browser()
  #  }
  }
  if(length(remove_pos)>1){
    if(!is.na(position_removed)){
      position_removed=sort(unique(c(position_removed,remove_pos)))
    }else{
      position_removed=sort(unique(remove_pos))
    }
  }
  rm(remove_pos)
  if(!is.na(position_removed)){
    seq=seq[-c(position_removed)]
    print('Length of removed sequence:')
    print(length(position_removed))
  rm(position_removed)
  }

  n=length(which(as.numeric(seq)<2))
  #print(length(which(seq==1)))
  #print(n)
  #print(length(seq))
  theta=length(which(seq==1))/(n/length(seq))

  output$seq=as.numeric(seq)
  output$theta=as.numeric(theta)
  return(output)
}
