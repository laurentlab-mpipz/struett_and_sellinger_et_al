#' Read text file
#'
#' Read a text file
#' @param path : location of the file
#' @param heavy : TRUE to read simulated sequence
#' @return A ms output file
Get_data<-function(path, heavy=F){
  DNAseqfile=list()
  count_DNA=0
  con = file(path, "r")
  while ( TRUE ) {
    count_DNA= count_DNA+1
    line = readLines(con, n = 1)
    if ( length(line) == 0  ){
      break
    }
    DNAseqfile[[count_DNA]]=as.vector(unlist(strsplit(as.vector(line)," ")))
    if (heavy&substr(line,1,3)=="seg"){
      break
    }
  }
  close(con)
  return(DNAseqfile)
}
