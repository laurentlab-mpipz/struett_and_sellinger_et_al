#' build baum-welch matrices from simulated genealogy
#'
#' @param file : path to the simulated data
#' @param Rho : rho used for simulation (i.e Rho=1000 if command line is : scrm  -r 1000 10000000)
#' @param theta : theta used for simulation (i.e theta=1000 if command line is scrm :  -t 1000 )
#' @param L : length of simulated sequence
#' @param n : Number of hidden states
#' @param window_scaling : numerical vector of size 2. Time window is divided by first value, and second value is added to time window to shift it in past or present
#' @param sigma : initial value for self-fertilization rate
#' @param beta : initial value for germination rate
#' @param SCALED : TRUE to scale estimated matrices
#' @param Big_Window : TRUE to use MSMC2 time window (bigger), user can also put numerical value if a window has been defined in Build_HMM_matrix.R
#' @param NC : Number of scaffold
#' @param mut : True if mutation were simulated
#' @param Correct_window : True to adapt window to scenario
#' @param build_M : TRUE or FALSE to build emission matrix
#' @export
#' @return A list of size 3 containing all 3 matrices build from genealogy (emission M , transition N  and initial q_)
get_Mat<-function(file,Rho,theta=NA,L,n=40,window_scaling=c(1,0),sigma=0,beta=1,SCALED=F,Big_Window=F,NC=1,mut=F,Correct_window=F,build_M=F){
  output=list()
  npair=NC
  cut_edge=F
  mu=theta/(2*L)
  b=get_first_coal_time(file,mut=mut)
  scale_T=1
  if(Correct_window){
    theta_=get_theta(file)
    scale_T=theta_/theta
    mu=theta_/(2*L)
  }
  if(is.na(mu)){
    stop()
  }
  if(as.numeric(Big_Window)==0){
    Vect=0:(n-1)
    Tc= window_scaling[2] -(0.5*(2-sigma)*log(1-(Vect/n))/((beta^2)*window_scaling[1]))
  }
  if(as.numeric(Big_Window)==1){
    alpha_t=0.1
    tmax=15
    Vect=1:(n-1)
    alpha_t=alpha_t/(npair)
    Tc= c(0,window_scaling[2] + (0.5*(2-sigma)*(alpha_t*exp((Vect/n)*log(1+(tmax/alpha_t))-1))/((beta^2)*window_scaling[1])))
  }
  if(as.numeric(Big_Window)==2){
    tmax=100
    alpha_t=0.1
    Vect=1:(n-1)
    npair=10
    alpha_t=alpha_t/npair
    Tc= c(0,window_scaling[2] + (0.5*(2-sigma)*(alpha_t*exp((Vect/n)*log(1+(tmax/alpha_t))-1))/((beta^2)*window_scaling[1])))
  }

  Tc=Tc*scale_T
  N=build_N(b,Tc)

  print("N is built")
  if(build_M){
  a=Get_sim_data(file,L,2,1)
    res=build_M(a[[1]],b,Tc)
    print("M is built")
    M=res$M
    print(sum(M))
    q_=res$q
  }
  if(SCALED){
    corrector_N=rowSums(N)
    N=diag(1/corrector_N)%*%N
    if(build_M){
      corrector_M=rowSums(M)
      M=diag(1/corrector_M)%*%M
    }
  }
  output$N=N
  if(build_M){
  output$M=M
  output$q=q_
  }else{
    output$M=0
    output$q=0
  }
  return(output)

}

